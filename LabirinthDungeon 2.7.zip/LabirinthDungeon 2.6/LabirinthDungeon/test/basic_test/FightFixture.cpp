//
// Created by daino on 01/07/18.
//

#include <gtest/gtest.h>
#include "../../Hero.h"
#include "../../Enemy.h"

class FightSuite : public ::testing::Test {

protected:
    virtual void SetUp() {
        h->setHp(100);
        h->setDexterity(45);
        h->setAttack(45);
        h->setDefense(50);

        e->setHp(1000);
        e->setDexterity(1000);
        e->setAttack(1000);
        e->setDefense(1000);
    }
    unique_ptr<Hero> h;
    unique_ptr<Enemy> e;

};


TEST_F(FightSuite, TestFight) {
    h->setAliveOrNot(h->isFighting());

    ASSERT_FALSE(h->getAliveOrNot());
}
