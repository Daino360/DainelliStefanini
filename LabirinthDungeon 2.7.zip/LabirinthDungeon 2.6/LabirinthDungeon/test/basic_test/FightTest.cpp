//
// Created by daino on 01/07/18.
//

#include <gtest/gtest.h>
#include "../../Hero.h"
#include "../../Enemy.h"
#include "../../Factory.h"
/*
TEST(Fight, FightHero) {
    unique_ptr<GameCharacter> h = Factory::Create(archer);
    unique_ptr<GameCharacter> e = Factory::Create(goblin);
    //Enemy e (goblin, 1000, 1000, 1000, 1000);
    int heroLife;
    heroLife = (e->getAttack() - h->getDefense());
    if ( heroLife<0){
        h->setAliveOrNot(false);
    }
    ASSERT_FALSE(h->getAliveOrNot());

}*/

/*
TEST(Hero, DefaultConstructor) {
    Hero h("TestHero", archer, 34, 45, 56, 67);
    //Enemy e (goblin, 1000, 1000, 1000, 1000);
    ASSERT_EQ(34, h.getHp());
    ASSERT_EQ(45, h.getDexterity());
    ASSERT_EQ(56, h.getAttack());
    ASSERT_EQ(67, h.getDefense());
}*/

TEST(Fight, FightHero) {
    unique_ptr<Hero> h;
    unique_ptr<Enemy> e;
    //Hero h("TestHero", archer, 100, 45, 45, 50);
    //Enemy e (goblin, 1000, 1000, 1000, 1000);
    int heroLife;
    heroLife = (e->getAttack() - h->getDefense());
    if ( heroLife<0){
        h->setAliveOrNot(false);
    }
    ASSERT_FALSE(h->getAliveOrNot());

}
