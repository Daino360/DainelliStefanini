#include "gtest/gtest.h"

#include "../../GameCharacter.h"
/*
TEST(GameCharacter, DefaultConstructor) {
    unique_ptr<GameCharacter> c;
    ASSERT_EQ(0, c->getPosX());
    ASSERT_EQ(0, c->getPosY());
    ASSERT_FALSE(c->isFighting());
}


TEST(GameCharacter, TestFightingMove) {
    unique_ptr<GameCharacter> c;
    c->setFighting(true);
    c->move(1, 1);

    ASSERT_FALSE(c->isFighting());
}*/

