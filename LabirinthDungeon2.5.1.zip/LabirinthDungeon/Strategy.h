//
// Created by Stefano on 22/11/2017.
//

#ifndef PLATFORMDUNGEON_STRATEGY_H
#define PLATFORMDUNGEON_STRATEGY_H

#include <SFML/Graphics.hpp>
#include "GameCharacter.h"

using namespace std;

class GameCharacter;

class Strategy {
public:

    virtual ~Strategy()=0; //distruttore puramente virtuale che mi rende la classe astratta

    virtual void updateMoveEnemy (GameCharacter* whoMove, int levelEnemy [], int tileEnemy, sf::Sprite *enemySprite, sf::RectangleShape *eRect, float movementSpeedEnemy, int *dirE) =0;

    //Strategy();
    float getComponentX() const;
    void setComponentX(float componentX);
    float getComponentY() const;
    void setComponentY(float componentY);
protected:
    int counterMoveEnemy;
    int counterWalkingEnemy;
    int movementLengthMax = 32; //32 se si usa il dado per la direction casuale
    float componentX; //componenti dell'Hero //potrebbe servire per il movimento del nemico verso l'eroe
    float componentY; //componenti dell'Hero //potrebbe servire per il movimento del nemico verso l'eroe
    float ipotenusa;//potrebbe servire per il movimento del nemico verso l'eroe
    float XEmenoXH; //potrebbe servire per il movimento del nemico verso l'eroe
    float YEmenoYH; //potrebbe servire per il movimento del nemico verso l'eroe

    double xPosEnemy,yPosEnemy;
    int newXEnemy, newYEnemy;

    sf::Sprite tmpSprite;
    GameCharacter* gamecharacter;
};

class NormalMove : public Strategy {
public:
    void updateMoveEnemy (GameCharacter* whoMove, int levelEnemy [], int tileEnemy, sf::Sprite *enemySprite, sf::RectangleShape *eRect, float movementSpeedEnemy, int *dirE) override;
};

class ToHeroMove : public Strategy {
public:
    void updateMoveEnemy (GameCharacter* whoMove, int levelEnemy [], int tileEnemy, sf::Sprite *enemySprite, sf::RectangleShape *eRect, float movementSpeedEnemy, int *dirE) override;
};

#endif //PLATFORMDUNGEON_STRATEGY_H
