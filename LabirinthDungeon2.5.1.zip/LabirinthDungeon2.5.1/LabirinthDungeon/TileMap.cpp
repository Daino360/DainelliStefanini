//
// Created by Stefano on 24/11/2017.
//

#include "TileMap.h"
#include "Hero.h"
#include "Die.h"
#include "Menu.h"
#include "ChooseHero.h"
#include "Factory.h"
#include "AttackStrategy.h"
#include "Strategy.h"
#include "memory" //serve per usare gli smart pointer unique_ptr, shared_ptr, weak_ptr
#include "MovementStrategy.h"
#include <fstream>
#include <list>
#include <tgmath.h>
#include <iostream>

bool TileMap::load(const std::string& tileset, sf::Vector2u tileSize, const int* tiles, unsigned int width, unsigned int height){
    // load the tileset texture
    if (!m_tileset.loadFromFile(tileset))
        return false;

    // resize the vertex array to fit the level size
    m_vertices.setPrimitiveType(sf::Quads);
    m_vertices.resize(width * height * 4);

    // populate the vertex array, with one quad per tile
    for (unsigned int i = 0; i < width; ++i)
        for (unsigned int j = 0; j < height; ++j)
        {
            // get the current tile number
            int tileNumber = tiles[i + j * width];

            // find its position in the tileset texture
            int tu = tileNumber % (m_tileset.getSize().x / tileSize.x);
            int tv = tileNumber / (m_tileset.getSize().x / tileSize.x);

            // get a pointer to the current tile's quad
            sf::Vertex* quad = &m_vertices[(i + j * width) * 4];

            // define its 4 corners
            quad[0].position = sf::Vector2f(i * tileSize.x, j * tileSize.y);
            quad[1].position = sf::Vector2f((i + 1) * tileSize.x, j * tileSize.y);
            quad[2].position = sf::Vector2f((i + 1) * tileSize.x, (j + 1) * tileSize.y);
            quad[3].position = sf::Vector2f(i * tileSize.x, (j + 1) * tileSize.y);

            // define its 4 texture coordinates
            quad[0].texCoords = sf::Vector2f(tu * tileSize.x, tv * tileSize.y);
            quad[1].texCoords = sf::Vector2f((tu + 1) * tileSize.x, tv * tileSize.y);
            quad[2].texCoords = sf::Vector2f((tu + 1) * tileSize.x, (tv + 1) * tileSize.y);
            quad[3].texCoords = sf::Vector2f(tu * tileSize.x, (tv + 1) * tileSize.y);
        }

    return true;
}


//int TileMap::renderMap( sf::Sprite characterSE, GameCharacter* uEnemy){
int TileMap::renderMap( ){//sf::Sprite characterSE){

    GameCharacter *yourHero = NULL;

    GameCharacter *arrayOfEnemy[MAX_NUMBER_OF_ENEMIES];
    for(iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){
        if (iEnemy < 4)
            arrayOfEnemy[iEnemy] = Enemy::GetEnemy(iEnemy);
        else
            arrayOfEnemy[iEnemy] = Enemy::GetEnemy(-1);
        enemySprite[iEnemy] = arrayOfEnemy[iEnemy]->getCharacterSprite();
        enemySprite[iEnemy].setTextureRect(IntRect(32,64,32,32));
    }

    // print the content of a text file.
    std::ifstream ifs;
    ifs.open("Mappetta.txt", std::ifstream::in); //open Mappetta.txt where is Map set
    char v = ifs.get();
    std::list<int> list = std::list<int>(); //list where will be insered all 0,1,2 of Mappetta.txt

    while (ifs.good()) {
        //std::cout << v;
        v = ifs.get();
        if(v=='0' || v=='1' || v=='2')
        {
            list.push_back((int)v);
        }
    }
    ifs.close();

    int tile;
    int tileEnemy;
    int levelEnemy[list.size()]; //array of the map for the enemy
    int level[list.size()]; //final array to create the Map
    int myarray[list.size()]; //Transiction array that change: 48 = 0, 49 = 1, 50 = 2 from ASCII tabels
// define the level with an array of tile indices
    for(int i=0;i<list.size()*list.size();i++)
    {
        myarray[i] = list.front();
        if (myarray[i] == 48) {
            level[i] = 0;
        } else if (myarray[i] == 49) {
            level[i] = 1;
        } else if (myarray[i] == 50) {
            level[i] = 2;
        } else {
            std::cout << "Texture Error" << std::endl;
        }
        list.pop_front();
    }
    //int tile = (int)level;


// Keep track of the frametime
    sf::Clock clock;
    bool updateFrame=true;
    float frameCounter = 0, switchFrame = 100, frameSpeed = 500;

// create the tilemap from the level definition
    TileMap map;
    Die die(5);
    int result = die.roll(1);
    if (result == 0) {
        if (!map.load("Tileset/Tileset1.png", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 1) {
        if (!map.load("Tileset/Tileset2.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 2) {
        if (!map.load("Tileset/Tileset3.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 3) {
        if (!map.load("Tileset/Tileset4.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 4) {
        if (!map.load("Tileset/Tileset5.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    }

    //Characters Movements
    enum Direction {Down,Left,Right,Up};
    sf::Vector2i source(1, Down);

    //servono per il movimento dell'immagine mentre cammina
    sf::IntRect rectSourceSprite(32, 32, 32, 32); //for move dx sx
    sf::IntRect rectSourceSpriteup(32, 0, 32, 32); //per move up
    sf::IntRect rectSourceSpritedown(32, 64, 32, 32); //per move down
    sf::IntRect rectSourceSpriteAttack(160, 32, 32,32);//per move attack dx sx
    sf::IntRect rectSourceSpriteAttackup(160, 0, 32,32);//per move attack up
    sf::IntRect rectSourceSpriteAttackdown(160, 64, 32,32);//per move attack down
    sf::Clock exclock;

    characterS.setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell'hero

    int lastBottomPush=0; //serve per vedere l'ultima direzione dell'omino per farlo attaccare

    // Contatori che servono per il movimento della freccia e della fire ball
    int counter = 0;
    int counter2 = 0;
    int counter3 = 0;
    sf::Clock clock1;
    sf::Clock clock2;
    sf::Clock clock3;

    sf::Texture textureFireBall;
    if (!textureFireBall.loadFromFile("fireball.png")){
        std::cout << "Texture Error" << std::endl;
    }

    // Projectile Vector Array
    vector<AttackStrategy>::const_iterator iter;
    vector<AttackStrategy> projectileArray;

    // Projectile Object (serve per la palla di fuoco)
    AttackStrategy AttackStrategyWA;//crea un oggetto attack strategy del wizzard e dell'archer
    AttackStrategyWA.spriteAttack.setTexture(textureFireBall);

    //class movementstrategy create an object
    //MovementStrategy mover;

    /*int numberOfFireBall=1;
    int counterOfFireBall =0;*/

    //sf::Sprite arrayFireballSprite [numberOfFireBall];


    // Load a music to play
    sf::Music music1;
    if (!music1.openFromFile("nice_music.ogg")) {
        return EXIT_FAILURE;
    }
    // Play the music
    music1.play();

// create the window
    sf::RenderWindow window(sf::VideoMode(1920, 1080), "Labirinth Dungeon"); //sf::Style::Fullscreen for fullscreen
    window.setVerticalSyncEnabled(true); // call it once, after creating the window
    window.setFramerateLimit(60); // call it once, after creating the window

    Menu menu(window.getSize().x, window.getSize().y);
    //run the MainMenu loop
    while (window.isOpen()) {
        // Get delta time for frame-rate depended movement
        //float dt = frametime.restart().asSeconds();

        //handle events
        sf::Event event;
        while (window.pollEvent(event)) {
            switch (event.type) {
                case sf::Event::KeyPressed:
                    switch (event.key.code)
                    {
                        case sf::Keyboard::Up:
                            menu.MoveUp();
                            break;

                        case sf::Keyboard::Down:
                            menu.MoveDown();
                            break;

                        case sf::Keyboard::Return:
                            switch (menu.GetPressedItem())
                            {
                                case 0:
                                    chooseMenu=1;
                                    std::cout << "Play button has been pressed" << std::endl;
                                    window.close();
                                    break;
                                case 1:
                                    std::cout << "Option button has been pressed" << std::endl;
                                    break;
                                case 2:
                                    window.close();
                                    break;
                            }
                            break;
                    }
                    /*case sf::Event::Closed:
                        window.close();
                        break;*/
            }
        }

// draw the map
        window.clear();
        menu.draw(window);
        window.display();
    }

    sf::RenderWindow windowHero(sf::VideoMode(1920, 1080), "Labirinth Dungeon"); //sf::Style::Fullscreen for fullscreen
    windowHero.setVerticalSyncEnabled(true); // call it once, after creating the window
    windowHero.setFramerateLimit(60); // call it once, after creating the window

    ChooseHero choose(windowHero.getSize().x, windowHero.getSize().y);

    if (chooseMenu==1){
        while (windowHero.isOpen()) {
            // Get delta time for frame-rate depended movement
            //float dt = frametime.restart().asSeconds();

            //handle events
            sf::Event event;
            while (windowHero.pollEvent(event)) {
                /*if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                    chooseMenu=1;
                    std::cout << "Play button has been pressed" << std::endl;
                    // get global mouse position
                    //sf::Vector2i position = sf::Mouse::getPosition();
                    // set mouse position relative to a window
                    //sf::Mouse::setPosition(sf::Vector2i(100, 200), window);
                }*/

                switch (event.type) {
                    case sf::Event::KeyPressed:
                        switch (event.key.code) {
                            case sf::Keyboard::Up:
                                choose.MoveUp();
                                break;

                            case sf::Keyboard::Down:
                                choose.MoveDown();
                                break;

                            case sf::Keyboard::Return:
                                switch (choose.GetPressedHero()) {
                                    case 0:
                                        yourHero=Factory::Create(archer);
                                        break;
                                    case 1:
                                        yourHero=Factory::Create(warrior);
                                        break;
                                    case 2:
                                        yourHero=Factory::Create(wizard);
                                        break;
                                }
                                windowHero.close();
                                break;
                        }
                        break;
                }
            }

// draw the map
            windowHero.clear();
            if (chooseMenu == 1)
                choose.draw(windowHero);
            windowHero.display();
        }
    }
    sf::RenderWindow game(sf::VideoMode(1920, 1080), "Labirinth Dungeon"); //sf::Style::Fullscreen for fullscreen
    game.setVerticalSyncEnabled(true); // call it once, after creating the window
    game.setFramerateLimit(60); // call it once, after creating the window
    game.setFramerateLimit(999999999);
    characterS = yourHero->getCharacterSprite();


//carica la texture larghezza e altezza per i vari nemici
    widthEnemy=game.getSize().x;
    heightEnemy=game.getSize().y;

//setta la posizione dei nemici
    //devono essere multipli di 32
    enemySprite[0].setPosition(1504, 32); // initial position of Enemy
    enemySprite[1].setPosition(448, 672); // initial position of Enemy
    enemySprite[2].setPosition(992, 256); // initial position of Enemy
    enemySprite[3].setPosition(608, 960); // initial position of Enemy
    enemySprite[4].setPosition(32, 896); // initial position of Enemy
    enemySprite[5].setPosition(1536, 256); // initial position of Enemy
    enemySprite[6].setPosition(1344, 672); // initial position of Enemy
    enemySprite[7].setPosition(32, 736); // initial position of Enemy
    enemySprite[8].setPosition(1536, 896); // initial position of Enemy
    enemySprite[9].setPosition(480, 64); // initial position of Enemy

    for (iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){ //inizializzazione a zero del contatore del massimo movimento dei nemici
        counterMoveEnemy[iEnemy]=0;
    }
//servono per la previsione del muro per i nemici
    tileEnemy =tile;
    for(int i=0;i<list.size()*list.size();i++)
    {
        levelEnemy[i] = level[i];
    }


//carica la texture della fireball
    int counterOfFireball=0;
    sf::Sprite arrayOfFireball[MAX_NUMBER_OF_FIREBALLS];
    for (iFireball=0; iFireball<MAX_NUMBER_OF_ENEMIES; iFireball++){
        if (!textureAttackFireball[iFireball].loadFromFile("fireball.png")){
            std::cout << "Texture Error" << std::endl;
        }
        spriteAttackFireball[iFireball].setTexture(textureAttackFireball[iFireball]);
        spriteAttackFireball[iFireball].scale(1.0f, 1.0f); // reduce dimensions of fireball (right dimensions: 0.5f)
        spriteAttackFireball[iFireball].setTextureRect(sf::IntRect(0, 0, 32, 32)); //imposta la grandezza dello sprite del fireball
    }

    AttackStrategyWA.spriteAttack.setPosition(30000, 30000);

    sf::Time time = clock.getElapsedTime();
    float playerMovementSpeed = 96/(2*time.asSeconds());

    // run the main loop (GAME LOOP)

    while (game.isOpen()) {
        //handle events
        sf::Event eventGame;
        while (game.pollEvent(eventGame)) {


            switch (eventGame.type) {

                case sf::Event::KeyPressed:
                    switch (eventGame.key.code) {

                        case sf::Keyboard::Up:
                            source.y = Up;

                            xPos = round((characterS.getPosition().x/32));
                            yPos = round((characterS.getPosition().y/32));
                            newX = xPos;
                            newY = yPos-1;
                            tile = level[newX + newY*58];
                            if (tile!=0) {
                                characterS.move(sf::Vector2f(0, -playerMovementSpeed));
                            }
                            if (exclock.getElapsedTime().asSeconds() > 1.0f){ //per il movimento dell'immagine mentre cammina
                                if (rectSourceSpriteup.left==64)
                                    rectSourceSpriteup.left=0;
                                else
                                    rectSourceSpriteup.left += 32;
                                characterS.setTextureRect(rectSourceSpriteup);
                                clock.restart();
                            }
                            if (eventGame.type == sf::Event::KeyReleased){
                                characterS.setTextureRect(sf::IntRect(32,32,32,32)); //imposta la grandezza dello sprite dell'hero
                            }
                            lastBottomPush=0; //0 = up
                            break;

                        case sf::Keyboard::Down:
                            source.y = Down;

                            xPos = round((characterS.getPosition().x/32));
                            yPos = round((characterS.getPosition().y/32));
                            newX = xPos;
                            newY = yPos+1;
                            tile = level[newX + newY*58];
                            if (tile!=0) {
                                characterS.move(sf::Vector2f(0, playerMovementSpeed));
                            }
                            //per il movimento dell'immagine mentre cammina
                            if (exclock.getElapsedTime().asSeconds() > 1.0f){
                                if (rectSourceSpritedown.left==64)
                                    rectSourceSpritedown.left=0;
                                else
                                    rectSourceSpritedown.left += 32;
                                characterS.setTextureRect(rectSourceSpritedown);
                                clock.restart();
                            }
                            if (eventGame.type == sf::Event::KeyReleased){
                                characterS.setTextureRect(sf::IntRect(32,32,32,32)); //imposta la grandezza dello sprite dell'hero
                            }
                            lastBottomPush=1; //1 = down
                            break;

                        case sf::Keyboard::Right:
                            source.x = Right;
                            //servono per la rotazione dell'immagine che passa da right a left
                            characterS.setOrigin({ 0, 0 });
                            characterS.setScale({ 1.0f, 1.0f });

                            xPos = round((characterS.getPosition().x/32));
                            yPos = round((characterS.getPosition().y/32));
                            newX = xPos+1;
                            newY = yPos;
                            tile = level[newX + newY*58];
                            if (tile!=0){ //per il movimento
                                characterS.move(sf::Vector2f(playerMovementSpeed, 0));
                            }
                            //per il movimento dell'immagine mentre cammina
                            if (exclock.getElapsedTime().asSeconds() > 1.0f){
                                if (rectSourceSprite.left==64)
                                    rectSourceSprite.left=0;
                                else
                                    rectSourceSprite.left += 32;
                                characterS.setTextureRect(rectSourceSprite);
                                clock.restart();
                            }
                            if (eventGame.type == sf::Event::KeyReleased){
                                characterS.setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell'hero
                            }
                            lastBottomPush=2; //2 = right
                            break;

                        case sf::Keyboard::Left:
                            source.x = Left;
                            //servono per la rotazione dell'immagine che passa da right a left
                            characterS.setOrigin({ characterS.getLocalBounds().width, 0 });
                            characterS.setScale({ -1.0f, 1.0f });

                            xPos = round((characterS.getPosition().x/32));
                            yPos = round((characterS.getPosition().y/32));
                            newX = xPos-1;
                            newY = yPos;
                            tile = level[newX + newY*58];
                            if (tile!=0) {
                                characterS.move(sf::Vector2f(-playerMovementSpeed, 0));
                            }
                            //per il movimento dell'immagine mentre cammina
                            if (exclock.getElapsedTime().asSeconds() > 1.0f){
                                if (rectSourceSprite.left==64)
                                    rectSourceSprite.left=0;
                                else
                                    rectSourceSprite.left += 32;
                                characterS.setTextureRect(rectSourceSprite);
                                clock.restart();
                            }
                            /*if (event.type == sf::Event::KeyReleased){
                                characterS.setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell'hero
                            }*/
                            lastBottomPush=3; //3 = left
                            break;

                        case sf::Keyboard::Escape:
                            game.close();
                            break;

                    }
                    break;
            }
            // Clock
            sf::Time elapsed1 = clock1.getElapsedTime();
            sf::Time elapsed2 = clock2.getElapsedTime();
            sf::Time elapsed3 = clock3.getElapsedTime();

            if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {

                counterOfFireball ++;
                //fire fireball

                AttackStrategyWA.spriteAttack.setPosition(characterS.getPosition().x, characterS.getPosition().y);
                AttackStrategyWA.direction = lastBottomPush;
                projectileArray.push_back(AttackStrategyWA);

                /*counterOfFireball++;
                spriteAttackFireball[counterOfFireball].setPosition(characterS.getPosition().x, characterS.getPosition().y);
                directionAttack = lastBottomPush; //serve per prendere la direzione dell'omino per sparare la fireball nella direzione corretta
                updateAttackMove(); // Update Attack Fireball
                 */
                //numberOfFireBall++;
                std::cout << "fire" << endl;

                //per il movimento dell'immagine mentre attacca
                if(lastBottomPush==2 or lastBottomPush==3) { //riconosce quale è l'ultimo tasto direzionale pigiato (dx e sx)
                    if (exclock.getElapsedTime().asSeconds() > 1.0f) {
                        if (rectSourceSpriteAttack.left == 224) //fino a dove arriva l'animazione nell'immagine
                            rectSourceSpriteAttack.left = 128; //da dove deve partire
                        else {
                            rectSourceSpriteAttack.left += 32;
                        }
                        characterS.setTextureRect(rectSourceSpriteAttack);
                        clock.restart();
                    }
                } else if(lastBottomPush==0){ //riconosce quale è l'ultimo tasto direzionale pigiato (up)
                    if (exclock.getElapsedTime().asSeconds() > 1.0f) {
                        if (rectSourceSpriteAttackup.left == 224) //fino a dove arriva l'animazione nell'immagine
                            rectSourceSpriteAttackup.left = 128; //da dove deve partire
                        else {
                            rectSourceSpriteAttackup.left += 32;
                        }
                        characterS.setTextureRect(rectSourceSpriteAttackup);
                        clock.restart();
                    }
                } else if(lastBottomPush==1) { //riconosce quale è l'ultimo tasto direzionale pigiato (down)
                    if (exclock.getElapsedTime().asSeconds() > 1.0f) {
                        if (rectSourceSpriteAttackdown.left == 224) //fino a dove arriva l'animazione nell'immagine
                            rectSourceSpriteAttackdown.left = 128; //da dove deve partire
                        else {
                            rectSourceSpriteAttackdown.left += 32;
                        }
                        characterS.setTextureRect(rectSourceSpriteAttackdown);
                        clock.restart();
                    }
                }
            }

        }

        // Draw AttackStrategy del mago e dell'archer in movimento
        counter = 0;
        for (iter = projectileArray.begin(); iter != projectileArray.end(); iter++) {
            projectileArray[counter].updateAttackMove(); // Update Attack

            AttackStrategyWA.spriteAttack.setPosition(projectileArray[counter].spriteAttack.getPosition()); //prende la posizione dello sprite mentre si muove (disegna il movimento)
            game.draw(projectileArray[counter].rectA);

            game.draw(projectileArray[counter].spriteAttack);
            // game.draw(AttackStrategyWA.spriteAttack);

            counter++;
        }
        for (iEnemy = 0; iEnemy < MAX_NUMBER_OF_ENEMIES; iEnemy++)
        {
            updateMoveEnemy(tileEnemy, levelEnemy); //se levi il commento gli omini iniziano andare per i fatti loro
        }
/*
        counter = 0;
        for (iFireball = 0; iFireball < MAX_NUMBER_OF_FIREBALLS; iFireball++) {
            arrayOfFireball[iFireball] = spriteAttackFireball[iFireball];
            updateAttackMove(); // Update Attack Fireball

            arrayOfFireball[iFireball].setPosition(spriteAttackFireball[iFireball].getPosition()); //prende la posizione dello sprite mentre si muove (disegna il movimento)

            game.draw(spriteAttackFireball[iFireball]);
            game.draw(arrayOfFireball[iFireball]);

            counter++;
        }
*/
// Projectile Collides (cioè la palla di fuoco) with Enemy e gli toglie vita
        counter = 0;
        for (iter = projectileArray.begin(); iter != projectileArray.end(); iter++)
        {
            counter2 = 0;
            int counterE2;
            for (counterE2 = 0; counterE2 < MAX_NUMBER_OF_ENEMIES; counterE2++)
            {
                if (projectileArray[counter].spriteAttack.getGlobalBounds().intersects(enemySprite[counter2].getGlobalBounds()))
                {
                    projectileArray[counter].destroy = true;
                    arrayOfEnemy[counter2]->setHp(arrayOfEnemy[counter2]->getHp()-projectileArray[counter].attackDamage); //ciò che toglie vite al nemico effettivamente
                    if (arrayOfEnemy[counter2]->getHp() <= 0)
                    {
                        //cancella lo sprite solo finchè non si muove
                        enemySprite[counter2].setTextureRect(sf::IntRect(0,0,0,0)); // (provvisorio) imposta la texture del nemico a (0,0,0,0) in modo che non si veda
                    }
                    cout << "colpito! nemico n*" << counter2 <<endl;
                }
                counter2++;
            }
            counter++;
        }
// Delete Projectile (cioè le palle di fuoco)
        counter = 0;
        for (iter = projectileArray.begin(); iter != projectileArray.end(); iter++)
        {
            if (projectileArray[counter].destroy == true)
            {
                projectileArray.erase(iter);
                projectileArray[counter].rectA.setTextureRect(sf::IntRect(0,0,0,0));//ritaglio della texture diventa 0
                break;
            }
            counter++;
        }

        yourHero->updateRect(); //sposta il rect dell'eroe sullo sprite dell'eroe

// draw the map and his elements
        game.clear();
        game.draw(map);
        game.draw(characterS);// create a Texture of Character
        drawEnemies(game);
        game.draw(AttackStrategyWA.spriteAttack);
        //drawFireball(game);
        game.display();

    }
};

//draw Enemy array
void TileMap::drawEnemies(sf::RenderWindow &window)
{
    for (iEnemy = 0; iEnemy < MAX_NUMBER_OF_ENEMIES; iEnemy++)
    {
        window.draw(enemySprite[iEnemy]);
    }
}

//move the sprite of Enemys
void TileMap::updateMoveEnemy(int tileEnemy, int levelEnemy [])
{
    rectEnemy[iEnemy].setPosition(enemySprite[iEnemy].getPosition()); //imposta il rect dove si trova il nemico

    if (directionEnemy[iEnemy] == 0) //& iEnemy==0 or iEnemy==1 or iEnemy==2) // Up funziona
    {

        xPosEnemy[iEnemy] = round((rectEnemy[iEnemy].getPosition().x/32));
        yPosEnemy[iEnemy] = round((rectEnemy[iEnemy].getPosition().y/32));
        newXEnemy[iEnemy] = xPosEnemy[iEnemy];
        newYEnemy[iEnemy] = yPosEnemy[iEnemy]-1;
        tileEnemy = levelEnemy[newXEnemy[iEnemy] + newYEnemy[iEnemy]*58];
        if (tileEnemy!=0) {
            rectEnemy[iEnemy].move(0, -movementSpeedEnemy);
            enemySprite[iEnemy].setTextureRect(sf::IntRect((32* counterWalkingEnemy[iEnemy]), 0, 32 , 32));
        } else {
            counterMoveEnemy[iEnemy]=movementLengthMax;
        }
        //rectEnemy[iEnemy].move(0, -movementSpeedEnemy);
    }
    else if (directionEnemy[iEnemy] == 1) //& iEnemy==3 or iEnemy==4 or iEnemy==5) // Down funziona
    {

        xPosEnemy[iEnemy] = round((rectEnemy[iEnemy].getPosition().x/32));
        yPosEnemy[iEnemy] = round((rectEnemy[iEnemy].getPosition().y/32));
        newXEnemy[iEnemy] = xPosEnemy[iEnemy];
        newYEnemy[iEnemy] = yPosEnemy[iEnemy]+1;
        tileEnemy = levelEnemy[newXEnemy[iEnemy] + newYEnemy[iEnemy]*58];
        if (tileEnemy!=0) {
            rectEnemy[iEnemy].move(0, movementSpeedEnemy);
            enemySprite[iEnemy].setTextureRect(sf::IntRect((32 * counterWalkingEnemy[iEnemy]), 64, 32, 32));
        } else {
            counterMoveEnemy[iEnemy]=movementLengthMax;
        }
        //rectEnemy[iEnemy].move(0, movementSpeedEnemy);
    }
    else if (directionEnemy[iEnemy] == 3) //& iEnemy==6 or iEnemy==7 or iEnemy==8) // Left
    {
        //servono per la rotazione dell'immagine che passa da right a left
        enemySprite[iEnemy].setOrigin({ enemySprite[iEnemy].getLocalBounds().width, 0 });
        enemySprite[iEnemy].setScale({ -1.0f, 1.0f });
        xPosEnemy[iEnemy] = round((rectEnemy[iEnemy].getPosition().x/32));
        yPosEnemy[iEnemy] = round((rectEnemy[iEnemy].getPosition().y/32));

        newXEnemy[iEnemy] = xPos-1;
        newYEnemy[iEnemy] = yPos;
        tileEnemy = levelEnemy[newXEnemy[iEnemy] + newYEnemy[iEnemy]*58];
        if (tileEnemy!=0) {
            rectEnemy[iEnemy].move(-movementSpeedEnemy, 0);
            enemySprite[iEnemy].setTextureRect(sf::IntRect((32 * counterWalkingEnemy[iEnemy]), 32, 32, 32));
        } else {
            counterMoveEnemy[iEnemy]=movementLengthMax;
        }
        //rectEnemy[iEnemy].move(-movementSpeedEnemy, 0);
    }
    else if (directionEnemy[iEnemy] == 2) //& iEnemy==9 or iEnemy==10) // Right
    {
        //servono per la rotazione dell'immagine che passa da right a left
        enemySprite[iEnemy].setOrigin({ 0, 0 });
        enemySprite[iEnemy].setScale({ 1.0f, 1.0f });

        xPosEnemy[iEnemy] = round((rectEnemy[iEnemy].getPosition().x/32));
        yPosEnemy[iEnemy] = round((rectEnemy[iEnemy].getPosition().y/32));
        newXEnemy[iEnemy] = xPosEnemy[iEnemy]+1;
        newYEnemy[iEnemy] = yPosEnemy[iEnemy];
        tileEnemy = levelEnemy[newXEnemy[iEnemy] + newYEnemy[iEnemy]*58];
        if (tileEnemy!=0){ //per il movimento
            rectEnemy[iEnemy].move(movementSpeedEnemy, 0);
            enemySprite[iEnemy].setTextureRect(sf::IntRect((32 * counterWalkingEnemy[iEnemy]), 32, 32, 32));
        } else {
            counterMoveEnemy[iEnemy]=movementLengthMax;
        }
        //rectEnemy[iEnemy].move(movementSpeedEnemy, 0);
    }
    else {
        //non si muove
    }

    // Sprite set at Rect
    enemySprite[iEnemy].setPosition(rectEnemy[iEnemy].getPosition());

    counterWalkingEnemy[iEnemy]++;
    if (counterWalkingEnemy[iEnemy] == 3)
    {
        counterWalkingEnemy[iEnemy] = 0;
    }

    counterMoveEnemy[iEnemy]++;
    if (counterMoveEnemy[iEnemy] >= movementLengthMax)
    {
        //for (int i=0; i<199999999; i++); //per allungare il tempo poichè l'inizializzazione a caso prende come seme il tempo
        //Die dieMoveEnemy(7); //lancia un dado a 8 facce per la casualita del nemico
        //directionEnemy[iEnemy] = dieMoveEnemy.roll(1); //(probabilità che si muova 4/8 che NON si muova 4/8
        directionEnemy[iEnemy] = Die::generateRandom(8)-1;
        counterMoveEnemy[iEnemy] = 0;
    }

}
/*
//move the sprite of the attack fireball
void TileMap::updateAttackMove()
{
    if (directionAttack == 0) {// Up
        spriteAttackFireball[iFireball].move(0, -movementSpeedAttack);
    }
    if (directionAttack == 1) {// Down
        spriteAttackFireball[iFireball].move(0, movementSpeedAttack);
    }
    if (directionAttack == 3) {// Left
        spriteAttackFireball[iFireball].move(-movementSpeedAttack, 0);
    }
    if (directionAttack == 2) { // Right
        spriteAttackFireball[iFireball].move(movementSpeedAttack, 0);
    }
    // Rect set at Sprite
    rectAttack.setPosition(spriteAttackFireball[iFireball].getPosition());

    //counterLifetime++;
    //if (counterLifetime >= lifeTime)
    //{destroy = true;}

}*/
/*
void TileMap::drawFireball(sf::RenderWindow &window){
    for (iFireball = 0; iFireball < MAX_NUMBER_OF_FIREBALLS; iFireball++) {
       // arrayOfFireball[iFireball] = spriteAttackFireball[iFireball];
        updateAttackMove(); // Update Attack Fireball

        //arrayOfFireball[iFireball].setPosition(spriteAttackFireball[iFireball].getPosition()); //prende la posizione dello sprite mentre si muove (disegna il movimento)

        window.draw(spriteAttackFireball[iFireball]);
       // window.draw(arrayOfFireball[iFireball]);

        //counter++;
    }
}*/
