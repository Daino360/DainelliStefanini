//
// Created by Stefano on 22/11/2017.
//

#include "MovementStrategy.h"
#include "Die.h"

//MovementStrategy::~MovementStrategy() {}

void MovementStrategy::update()
{
    characterSprite.setPosition(rect.getPosition());
}


void MovementStrategy::updateMovement(sf::Sprite characterSprite)
{
    /*int counterWalking = 0;
    int counter=0;
    int movementLength = 100;
    int direction = Die::generateRandom(10);*/
    if (direction == 0) // Up
    {
        //rect.move(0,-movementSpeed);
        characterSprite.move(0,-8);
        characterSprite.setTextureRect(sf::IntRect((32* counterWalking), 0, 32 , 32));
    }
    else if (direction == 1) // Down
    {
        //rect.move(0,movementSpeed);
        characterSprite.move(0,8);
        characterSprite.setTextureRect(sf::IntRect((32 * counterWalking), 64, 32, 32));
    }
    else if (direction == 3) // Left
    {
        //rect.move(-movementSpeed,0);
        characterSprite.move(-8, 0);
        characterSprite.setTextureRect(sf::IntRect((32 * counterWalking), 32, 32, 32));
    }
    else if (direction == 2) // Right
    {
        //rect.move(movementSpeed,0);
        characterSprite.move(0, 8);
        characterSprite.setTextureRect(sf::IntRect((32 * counterWalking), 32, 32, 32));
    }
    else
    {
        // No movement
    }

    counterWalking++;
    if (counterWalking == 3)
    {
        counterWalking = 0;
    }

    counter++;
    if (counter >= movementLength)
    {
        direction = Die::generateRandom(10);
        counter = 0;
    }
}
