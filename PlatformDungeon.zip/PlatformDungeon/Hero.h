//
// Created by Stefano on 15/11/2017.
//

#ifndef PLATFORMDUNGEON_HERO_H
#define PLATFORMDUNGEON_HERO_H

#include "GameCharacter.h"
#include "Equipment.h"
#include <string>

class Hero : public GameCharacter {
public:
    explicit Hero(std::string n,int th, int e, int h, int d, int a, int df) : GameCharacter(h, d, a, df), name(n), typeHero(th), element(e) {}
    virtual void move(int x, int y) override;//Mettiamo L override perchè stiamo usando un metodo di Gamecharacter
    int takeEquipment();
    int buy();
    Equipment *getEquipment() const {
        return equipment;
    }

    void setEquipment(Equipment *equipment) {
        Hero::equipment = equipment;
    }

protected: // va messo private se si elimina warrior mage ecc...
    std::string name;
    int typeHero;
    int element;
    Equipment* equipment; //Puntatore che serve per composizione
};


#endif //PLATFORMDUNGEON_HERO_H
