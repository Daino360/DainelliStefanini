//
// Created by Stefano on 15/11/2017.
//

#include "Weapon.h"

int Weapon::attack() {// attack si intende il danno effettivo


}
int Weapon::damage() {// damage ci fa capire quale arma stiamo usando

}
