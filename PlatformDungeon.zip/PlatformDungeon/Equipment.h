//
// Created by Stefano on 22/11/2017.
//

#ifndef PLATFORMDUNGEON_EQUIPMENT_H
#define PLATFORMDUNGEON_EQUIPMENT_H

//Equipaggiamento di armature
class Equipment {
public:
    Equipment(int m, int st); //m-material, st-strenght
    int dress();

private:
    int material;//Materiale dell' armatura : Legno, Ferro, Acciaio e Valyria
    int strenght;// diversa a seconda del materiale

};


#endif //PLATFORMDUNGEON_EQUIPMENT_H
