//
// Created by Stefano on 22/11/2017.
//

#include "Warrior.h"

//Warrior::Warrior(int sword, int element, int typeHero, std::string n) : Hero(name, typeHero, element), sword(1){
    // load bitmaps...
    // more stuff...
    // ... more work
//}