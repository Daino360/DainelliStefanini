//
// Created by daino on 13/12/17.
//

#ifndef PLATFORMDUNGEON_ENUMFILE_H
#define PLATFORMDUNGEON_ENUMFILE_H

enum enumMaterial:int{
    wood,
    iron,
    steel,
    valyria

};

enum enumTypeWeapon : int {
    bow,
    sword,
    stick
};

enum enumTypeHero : int {
    archer,
    warrior,
    wizard
};

enum enumTypeEnemy : int {
    goblin,
    ghoul,
    orc,
    troll
};

#endif //PLATFORMDUNGEON_ENUMFILE_H
