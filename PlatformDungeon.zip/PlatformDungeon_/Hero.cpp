//
// Created by Stefano on 15/11/2017.
//

#include "Hero.h"

void Hero::move(int x, int y) { //movimento dell' eroe
    // TODO complete
}