//
// Created by Stefano on 22/11/2017.
//

#ifndef PLATFORMDUNGEON_ATTACKSTRATEGY_H
#define PLATFORMDUNGEON_ATTACKSTRATEGY_H

#include "Strategy.h"
#include "Enemy.h"

class AttackStrategy  {//: public Strategy da errore per rifermento no definito a stategy
public:
    //virtual ~AttackStrategy()=0; //distruttore puramente virtuale che mi rende la classe astratta
    int slowAttack(); //slow per Orc e Troll
    int rapidAttack();//rapid per Goblin e Ghoul
    //metodi di questa classe devono essere tutti virtuali
    virtual Enemy *getEnemy() const {
        return enemy;
    }

    virtual void setEnemy(Enemy *enemy) {
        AttackStrategy::enemy = enemy;
    }

    sf::RectangleShape rectA;
    int movementSpeed = 16;
    int attackDamage = 5;
    int direction = 4; // 0 - up, 1 - down, 3 - left, 2 - right
    int lifeTime = 10;
    //sf::Sprite heroImageS[numberOfFireBall];
    sf::Sprite spriteAttack;
    AttackStrategy();
    void AttackStrategyWizard();
    void updateAttackMove();
    //void updateMovement();
    bool destroy = false;
    int counterLifetime = 0;
private:
    Enemy* enemy;

};

#endif //PLATFORMDUNGEON_ATTACKSTRATEGY_H
