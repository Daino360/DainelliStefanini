//
// Created by Stefano on 24/11/2017.
//

#ifndef PLATFORMDUNGEON_MAP_H
#define PLATFORMDUNGEON_MAP_H


#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <SFML/Network.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Config.hpp>
#include <SFML/OpenGL.hpp>
#include <SFML/Main.hpp>
#include <string>
#include "GameCharacter.h"
#include "Store.h"
using namespace std;

#define MAX_NUMBER_OF_ENEMIES 10

class TileMap : public sf::Drawable, public sf::Transformable{
public:
    TileMap(){}; // here we leave constructor because Map doesn't derive from any classes
    int removeCharacter();
    bool load(const std::string& tileset, sf::Vector2u tileSize, const int* tiles, unsigned int width, unsigned int height);
    //int renderMap(sf::Sprite, GameCharacter*);
    int renderMap();//sf::Sprite);

    //DrawnEnemy(float widthE, float heightE);
    //~DrawnEnemy();
    //DrawnEnemy();
    int iEnemy;

    void drawEnemies(sf::RenderWindow &window);
    sf::Sprite enemySprite[MAX_NUMBER_OF_ENEMIES];
    sf::Texture enemyTexture[MAX_NUMBER_OF_ENEMIES];
protected:
    int chooseMenu;
    double xPos,yPos;
    int newX, newY;
    sf::Sprite characterS;
    //sf::Sprite characterS;
    //sf::Texture characterTx;

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const
    {
        // apply the transform
        states.transform *= getTransform();

        // apply the tileset texture
        states.texture = &m_tileset;

        // draw the vertex array
        target.draw(m_vertices, states);
    }
    sf::VertexArray m_vertices;
    sf::Texture m_tileset;
private:
    float widthEnemy;
    float heightEnemy;
};

/*
class MyTileMap : public  TileMap{
public:
    MyTileMap(){};

};*/

#endif //PLATFORMDUNGEON_MAP_H
