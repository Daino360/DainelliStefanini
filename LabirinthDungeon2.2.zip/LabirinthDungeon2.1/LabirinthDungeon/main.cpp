#include "Hero.h"
#include "Enemy.h"
#include "memory" //serve per usare gli smart pointer unique_ptr, shared_ptr, weak_ptr


int main() {
    unique_ptr<TileMap> window(new TileMap());
    //TileMap *window = new TileMap();
    window->renderMap();
    return 0;
}