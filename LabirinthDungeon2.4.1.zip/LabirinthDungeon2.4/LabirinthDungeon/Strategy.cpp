//
// Created by Stefano on 22/11/2017.
//

#include <iostream>
#include "Strategy.h"
/*
Strategy::Strategy(float widthE, float heightE){
    widthEnemy=widthE;
    heightEnemy=heightE;
    for (iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){
        if (!enemyTexture[iEnemy].loadFromFile("Sprites/EnemySprite/goblins.png")){
            std::cout << "Texture Error" << std::endl;
        }
        enemySprite[iEnemy].setTexture(enemyTexture[iEnemy]);
        enemySprite[iEnemy].scale(1.0f, 1.0f); // reduce dimensions of Character (right dimensions: 0.5f)
        enemySprite[iEnemy].setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell' enemy
    }
}

void Strategy::drawEnemies(sf::RenderWindow &window)
{
    enemySprite[0].setPosition(1500, 35); // initial position of Character
    enemySprite[1].setPosition(450, 670); // initial position of Character
    enemySprite[2].setPosition(1000, 153); // initial position of Character
    enemySprite[3].setPosition(600, 980); // initial position of Character
    enemySprite[4].setPosition(35, 870); // initial position of Character
    enemySprite[5].setPosition(1546, 313); // initial position of Character
    enemySprite[6].setPosition(1350, 678); // initial position of Character
    enemySprite[7].setPosition(45, 789); // initial position of Character
    enemySprite[8].setPosition(1534, 900); // initial position of Character
    enemySprite[9].setPosition(464, 67); // initial position of Character

    for (iEnemy = 0; iEnemy < MAX_NUMBER_OF_ENEMIES; iEnemy++)
    {
        //enemySprite[iEnemy].setPosition(100+iEnemy*100/(iEnemy+1), 300+iEnemy*100); // initial position of Character
        window.draw(enemySprite[iEnemy]);

    }

}
*/
Strategy::~Strategy() {}