//
// Created by daino on 01/07/18.
//

#include <gtest/gtest.h>
#include <cmath>
#include "../../TileMap.h"

//Qui NON c'è il muro quindi si muove
TEST (Wall, GameCharacterNoWall){
    sf::Sprite g;
    g.setPosition(1000,0);
    int levelTest[0];
    bool moved = false;
    double xPosGamaCharacterTest = round((g.getPosition().x/32));
    double yPosGamaCharacterTest = round((g.getPosition().y/32));
    int newXGamaCharacterTest = xPosGamaCharacterTest;
    int newYGamaCharacterTest = yPosGamaCharacterTest-1;
    int tile = levelTest[newXGamaCharacterTest + newYGamaCharacterTest*58];
    if (tile!=0) {
        g.move(0, -8);
        moved = false;
    }
    ASSERT_FALSE(moved);
}

//Qui c'è il muro e quindi NON si muove
TEST (Wall, GameCharacterWall){
    sf::Sprite g;
    g.setPosition(0,0);
    int levelTest[999999];
    bool moved = false;
    double xPosGamaCharacterTest = round((g.getPosition().x/32));
    double yPosGamaCharacterTest = round((g.getPosition().y/32));
    int newXGamaCharacterTest = xPosGamaCharacterTest;
    int newYGamaCharacterTest = yPosGamaCharacterTest-1;
    int tile = levelTest[newXGamaCharacterTest + newYGamaCharacterTest*58];
    if (tile!=0) {
        g.move(0, -8);
        moved = true;
    }
    ASSERT_FALSE(moved);
}