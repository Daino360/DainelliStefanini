//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#include <sys/resource.h>

#include "Hero.h"

int main(int argc, char **argv) {
    //aumenta lo stack al runtime
    const rlim_t kStackSize = 64L * 1024L * 1024L;   // min stack size = 64 Mb
    struct rlimit rl;
    int result;

    result = getrlimit(RLIMIT_STACK, &rl);
    if (result == 0)
    {
        if (rl.rlim_cur < kStackSize)
        {
            rl.rlim_cur = kStackSize;
            result = setrlimit(RLIMIT_STACK, &rl);
            if (result != 0)
            {
                fprintf(stderr, "setrlimit returned result = %d\n", result);
            }
        }
    }

    unique_ptr <TileMap> window(new TileMap ());
    window->renderMap();
    return 0;
}