//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_HERO_H
#define PLATFORMDUNGEON_HERO_H

#include <string>
#include <map>
#include <iostream>

#include "GameCharacter.h"
#include "EnumFile.h"


using namespace std;

class Hero : public GameCharacter {
public:
    explicit Hero(std::string nameHero, enumTypeHero tHero, int health, int dex, int atk, int def) :
            GameCharacter(health, dex, atk, def), name(nameHero), typeHero(tHero) {
        typeHero = tHero;
    }

    string name;

private:
    enumTypeHero typeHero;
};


#endif //PLATFORMDUNGEON_HERO_H
