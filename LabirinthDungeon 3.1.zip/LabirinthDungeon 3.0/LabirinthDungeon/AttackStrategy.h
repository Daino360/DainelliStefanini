//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_ATTACKSTRATEGY_H
#define PLATFORMDUNGEON_ATTACKSTRATEGY_H

#include "Strategy.h"
#include "Enemy.h"


class AttackStrategy  {
public:
    AttackStrategy();

    sf::RectangleShape rectA;
    int movementSpeed;
    int attackDamage; //riviene settato nel tile.cpp all'attacco dell'eroe
    int direction = None; // 0 - up, 1 - down, 2 - right, 3 - left
    int lifeTime;
    int numberOfHit = 0; //colpi che ha a disposizione il mago o l'archer
    sf::Sprite spriteAttack;

    void updateAttackMove(int tile, int level[]);
    double xPosAttackStrategy,yPosAttackStrategy;
    int newXAttackStrategy, newYAttackStrategy;
    bool destroy = false;
    int counterLifetime = 0;
};

#endif //PLATFORMDUNGEON_ATTACKSTRATEGY_H
