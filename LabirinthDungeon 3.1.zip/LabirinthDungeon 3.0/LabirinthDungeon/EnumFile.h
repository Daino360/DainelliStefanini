//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_ENUMFILE_H
#define PLATFORMDUNGEON_ENUMFILE_H

enum enumTypeHero : int {
    archer,
    warrior,
    wizard
};

enum enumTypeEnemy : int {//10,11,12,13 per evitare collisione con enumerazione eroi.
    goblin = 10,
    ghoul = 11,
    orc = 12,
    troll = 13
};

enum enumDirection : int {
    Up = 0,
    Down = 1,
    Right = 2,
    Left = 3,
    None = 4
};

enum enumForAttackStrategy : int {
    lifeTimeDistance = 1000,
    lifeTimeNear = 6,
    hitArrow = 150,
    hitFireball = 100,
    speedSword =  8,
    speedArrow = 64,
    speedFireball = 32
};

enum enumForWindow : int {
    level1 = 1,
    level2 = 2,
    level3 = 3,
    Lost = 666,
    Win = 999,
    Close = 777
};

enum enumForAchievement : int {
    obb1 = 5,
    obb2 = 10,
    obb3 = 14,
    obb4 = 20,
    obb5 = 25,
    obb6 = 29,
    obb7 = 35,
    obb8 = 40,
    obb9 = 44
};


#endif //PLATFORMDUNGEON_ENUMFILE_H
