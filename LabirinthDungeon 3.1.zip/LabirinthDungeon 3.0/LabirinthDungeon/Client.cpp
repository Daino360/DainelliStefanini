//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#include "Client.h"
#include "TileMap.h"
#include "EnumFile.h"

void Client::update(int kill, std::string textAch ) {
// Stampa gli Achievement
    if(kill == obb1 || kill == obb2 || kill == obb3 || kill == obb4 || kill == obb5 || kill == obb6 || kill == obb7 || kill == obb8 || kill == obb9) {
        switch (kill) {
            case (obb1):
                textAch = ("Good! You killed 5 Enemies!");
                setTextAch(textAch);
                break;
            case (obb2):
                textAch = ("Fabulous! You killed 10 Enemies!");
                setTextAch(textAch);
                break;
            case (obb4):
                textAch = ("Good Hero! You killed 20 Enemies!");
                setTextAch(textAch);
                break;
            case (obb5):
                textAch = ("Great Hero! You killed 25 Enemies!");
                setTextAch(textAch);
                break;
            case (obb6):
                textAch = ("Hero! Remains only one enemy!");
                setTextAch(textAch);
                break;
            case (obb7):
                textAch = ("Good Legend! You killed 35 Enemies!");
                setTextAch(textAch);
                break;
            case (obb8):
                textAch = ("Great Legend! You killed 40 Enemies!");
                setTextAch(textAch);
                break;
            case (obb9):
                textAch = ("Legend! Remains only one enemy!");
                setTextAch(textAch);
                break;
            /*case (false):
                textAch = ("");
                setTextAch(textAch);
                break;*/
        }
    } else {
        textAch = ("");
        setTextAch(textAch);
    }
    /*
    if (kill==obb1){
        textAch=("Good! You killed 5 Enemies!");
        setTextAch(textAch);
    } else if (kill==obb2){
        textAch = ("Fabulous! You killed 10 Enemies!");
        setTextAch(textAch);
    } else if (kill==obb3){
        textAch = ("Great! Remains only one enemy!");
        setTextAch(textAch);
    } else if (kill==obb4){
        textAch = ("Good Hero! You killed 20 Enemies!");
        setTextAch(textAch);
    } else if (kill==obb5){
        textAch = ("Great Hero! You killed 25 Enemies!");
        setTextAch(textAch);
    } else if (kill==obb6){
        textAch = ("Hero! Remains only one enemy!");
        setTextAch(textAch);
    } else if (kill==obb7){
        textAch = ("Good Legend! You killed 35 Enemies!");
        setTextAch(textAch);
    } else if (kill==obb8){
        textAch = ("Great Legend! You killed 40 Enemies!");
        setTextAch(textAch);
    } else if (kill==obb9){
        textAch = ("Legend! Remains only one enemy!");
        setTextAch(textAch);
    } else {
        textAch = ("");
        setTextAch(textAch);
    }*/
}

Client::Client(int id) {
    this->id = id;
}

const string &Client::getTextAch() const {
    return textAch;
}

void Client::setTextAch(const string &textAch) {
    Client::textAch = textAch;
}

