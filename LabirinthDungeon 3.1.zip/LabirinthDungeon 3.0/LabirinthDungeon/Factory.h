//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_FACTORY_H
#define PLATFORMDUNGEON_FACTORY_H


#include "EnumFile.h"
#include "Hero.h"
#include "Enemy.h"

class Factory {
public:
    static unique_ptr <Hero>  Create(enumTypeHero type);
    static unique_ptr <Enemy> Create(enumTypeEnemy type);
};

#endif //PLATFORMDUNGEON_FACTORY_H
