//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#include "Factory.h"
#include "memory" //serve per usare gli smart pointer unique_ptr, shared_ptr, weak_ptr

unique_ptr <Hero> Factory::Create(enumTypeHero type) {
    switch (type) {
        case archer: {
            unique_ptr <Hero> h(new Hero ("Legolas", archer, 400, 192, 80, 10)); //healthpoint, dexterity (deve essere un multiplo di 32), attack, defense
            h->setUpSprite("Sprites/HeroSprite/archers.png");
            return h;
            break;
        }
        case warrior: {
            unique_ptr <Hero> h(new Hero ("Aragon", warrior, 550, 96, 100, 25));
            h->setUpSprite("Sprites/HeroSprite/warriors.png");
            return h;
            break;
        }
        case wizard: {
            unique_ptr <Hero> h(new Hero ("Gandalf", wizard, 390, 160, 200, 15));
            h->setUpSprite("Sprites/HeroSprite/wizards.png");
            return h;
            break;
        }
    }
}

unique_ptr <Enemy> Factory::Create(enumTypeEnemy type)
{
    switch (type) {
        case goblin: {
            unique_ptr <Enemy> h(new Enemy (goblin, 80, 128, 30, 10)); //healthpoint, dexterity (deve essere un multiplo di 32), attack, defense
            h->setUpSpriteEnemy("Sprites/EnemySprite/goblins.png");
            return h;
            break;
        }
        case ghoul: {
            unique_ptr <Enemy> h(new Enemy (ghoul, 50, 96, 40, 5));
            h->setUpSpriteEnemy("Sprites/EnemySprite/ghouls.png");
            return h;
            break;
        }
        case orc: {
            unique_ptr <Enemy> h(new Enemy (orc, 120, 64, 50, 20));
            h->setUpSpriteEnemy("Sprites/EnemySprite/orcs.png");
            return h;
            break;
        }
        case troll: {
            unique_ptr <Enemy> h(new Enemy (goblin, 200, 32, 70, 15));
            h->setUpSpriteEnemy("Sprites/EnemySprite/trolls.png");
            return h;
            break;
        }
    }
}
