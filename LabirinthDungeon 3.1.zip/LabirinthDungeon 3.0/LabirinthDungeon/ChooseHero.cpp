//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#include "ChooseHero.h"
ChooseHero::ChooseHero(float width, float height)
{
    if (!fontHero.loadFromFile("DungeonFont.ttf"))
    {
        std::cout << "Font Error" << std::endl;
    }
    if (!backgroundHero.loadFromFile("backgroundHero.jpeg")){
        std::cout << "Background Error" << std::endl;
    }
    backgroundHeroS.setTexture(backgroundHero);
    backgroundHeroS.scale(1.0f, 1.0);

    if (!heroImage[0].loadFromFile("archerStart.png")){
        std::cout << "Texture Error" << std::endl;
    }
    heroImageS[0].setTexture(heroImage[0]);
    heroImageS[0].scale(0.5f, 0.5f); // riduce dimensione
    heroImageS[0].setPosition(650,30);
    textHero[0].setFont(fontHero);
    textHero[0].setString("Archer");
    textHero[0].setPosition(50,150);
    textHero[0].setScale(2.0f, 2.0f);


    if (!heroImage[1].loadFromFile("warriorStart.png")){
        std::cout << "Texture Error" << std::endl;
    }
    heroImageS[1].setTexture(heroImage[1]);
    heroImageS[1].scale(0.25f, 0.25f); // riduce dimensione
    heroImageS[1].setPosition(775,380);
    textHero[1].setFont(fontHero);
    textHero[1].setString("Warrior");
    textHero[1].setPosition(50,470);
    textHero[1].setScale(2.0f,2.0f);


    if (!heroImage[2].loadFromFile("wizardStart.png")){
        std::cout << "Texture Error" << std::endl;
    }
    heroImageS[2].setTexture(heroImage[2]);
    heroImageS[2].scale(0.35f, 0.35f); // riduce dimensione
    heroImageS[2].setPosition(800,730);
    textHero[2].setFont(fontHero);
    textHero[2].setString("Wizard");
    textHero[2].setPosition(50,830);
    textHero[2].setScale(2.0f,2.0f);

    selectedHeroIndex = 0;
}

ChooseHero::~ChooseHero()
{
}

void ChooseHero::draw(sf::RenderWindow &window)
{
    window.draw(backgroundHeroS);
    for (int i = 0; i < MAX_NUMBER_OF_ITEMS; i++)
    {
        window.draw(heroImageS[i]);
        window.draw(textHero[i]);
    }

}

void ChooseHero::MoveUp()
{
    if (selectedHeroIndex - 1 >= 0)
    {
        heroImageS[selectedHeroIndex].setColor(sf::Color::White);
        selectedHeroIndex--;
        heroImageS[selectedHeroIndex].setColor(sf::Color::Red);
    }
}

void ChooseHero::MoveDown()
{
    if (selectedHeroIndex + 1 < MAX_NUMBER_OF_ITEMS)
    {
        heroImageS[selectedHeroIndex].setColor(sf::Color::White);
        selectedHeroIndex++;
        heroImageS[selectedHeroIndex].setColor(sf::Color::Red);
    }
}