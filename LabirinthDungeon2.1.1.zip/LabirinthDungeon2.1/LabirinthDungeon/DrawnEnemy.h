//
// Created by giovanni on 12/06/18.
//

#ifndef PLATFORMDUNGEON_DRAWNENEMY_H
#define PLATFORMDUNGEON_DRAWNENEMY_H

#include <SFML/Graphics.hpp>
using namespace std;

#define MAX_NUMBER_OF_ENEMIES 10

class DrawnEnemy {
public:
    DrawnEnemy(float widthE, float heightE);
    //~DrawnEnemy();
    //DrawnEnemy();
    int iEnemy;

    virtual void drawEnemies(sf::RenderWindow &window);
    sf::Sprite enemySprite[MAX_NUMBER_OF_ENEMIES];
    sf::Texture enemyTexture[MAX_NUMBER_OF_ENEMIES];
private:


    float widthEnemy;
    float heightEnemy;

};



#endif //PLATFORMDUNGEON_DRAWNENEMY_H
