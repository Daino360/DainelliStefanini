#include <iostream>
#include "Hero.h"
#include "Enemy.h"
#include "Factory.h"
#include "Die.h"
#include "EnumFile.h"

int main(int argc, char **argv) {
    //RenderWindow window(VideoMode(320, 480), "Platform Dungeon!");

    Hero *Giovanni = Hero::GetHero();//created by factoryH

    //crere un ciclo che crea nemici fincè non muore l'eroem

    Enemy *Stefano = Enemy::GetEnemy(); //created by factory

    cout << "\n" << "Your Hero fights against Enemy";
    int damoHero = 0;
    int damoEnemy = 0;

    int done = 0;
    int c = 0;


    for (int hit = 0; hit < Stefano->getHp() || hit < Giovanni->getHp(); hit++) {

        do {
            c = getchar();
            putchar(c);
        } while (c != ' ');

        damoHero = Giovanni->fight(*Stefano);
        damoEnemy = Stefano->fightHero(*Giovanni);

        if (damoHero)
            std::cout <<" Enemy hit: " << damoHero << std::endl;
        if (Stefano->getHp() > 0)
            std::cout << "Healty Point of Enemy"<< Stefano->getHp() << std::endl;
        else {
            std::cout << "Healty Point of Enemy"<<": "<< 0 << std::endl;
        }
        if (Stefano->getHp() <= 0) {
            std::cout << "\n"<<"Enemy is dead" << std::endl;
            return 0;
        }

        if (damoEnemy && done == 0)
            std::cout << "Hero hit: " << damoEnemy << std::endl;
        if (Giovanni->getHp() > 0 && done == 0)
            std::cout << "Healty Point of Your Hero " << Giovanni->getHp()<< std::endl;
        else if (done == 0) {
            std::cout << "Healty Point of Your Hero " << 0 << std::endl;
            std::cout << "\nYour Hero is dead" << std::endl;
            return 0;
        }
    }
    return 0;
}
