//
// Created by Stefano on 22/11/2017.
//

#include "Enemy.h"
#include "Factory.h"
#include "Die.h"

using namespace std;

Enemy *Enemy::GetEnemy() {

    Enemy *pEnemy = NULL;
    std::string enemyName;

    //Casualità nemico
    Die::initRandom();
    Die die(4);
    int result = die.roll(1);

    if (result == 0) {
        enemyName = "Goblin";
        pEnemy = Factory::Get()->CreateEnemy(enemyName);
    } else if (result == 1) {
        enemyName = "Ghoul";
        pEnemy = Factory::Get()->CreateEnemy(enemyName);
    } else if (result == 2) {
        enemyName = "Orc";
        pEnemy = Factory::Get()->CreateEnemy(enemyName);
    } else if (result == 3) {
        enemyName = "Troll";
        pEnemy = Factory::Get()->CreateEnemy(enemyName);
    }
    cout << "Your enemy is a " << enemyName;
    return pEnemy;
}

Enemy *Factory::CreateEnemy(string &enemyName){

    FactoryMap::iterator it = m_FactoryMap.find(enemyName);
    if( it != m_FactoryMap.end() )
        return it->second();
    return NULL;
}
