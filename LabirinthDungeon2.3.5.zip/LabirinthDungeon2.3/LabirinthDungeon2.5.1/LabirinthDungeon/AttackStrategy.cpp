//
// Created by Stefano on 22/11/2017.
//

#include "AttackStrategy.h"

//AttackStrategy::~AttackStrategy() {}

AttackStrategy::AttackStrategy()
{
    //rectA.setSize(sf::Vector2f(32, 32));
    rectA.setPosition(0, 0);
    rectA.setFillColor(sf::Color::Green);

    /* sf::Texture textureFireBall;
     if (!textureFireBall.loadFromFile("fireball.png")){
         std::cout << "Texture Error" << std::endl;
     }*/
    //spriteAttack.setTexture(textureFireBall);
    spriteAttack.setPosition(0, 0);
    spriteAttack.setTextureRect(sf::IntRect(0, 0, 32, 32));
}

void AttackStrategy::updateAttackMove()
{
    if (direction == 0) {// Up
        spriteAttack.move(0, -movementSpeed);
        spriteAttack.setRotation(90);
    }
    if (direction == 1) {// Down
        spriteAttack.move(0, movementSpeed);
        //spriteAttack.setTextureRect(sf::IntRect(counterAnimation * 32, 0, 32, 32));
        spriteAttack.setRotation(-90);
    }
    if (direction == 3) {// Left
        spriteAttack.move(-movementSpeed, 0);
        //spriteAttack.setTextureRect(sf::IntRect(counterAnimation * 32, 1 * 32, 32, 32));
        spriteAttack.setRotation(180);
    }
    if (direction == 2) { // Right
        spriteAttack.move(movementSpeed, 0);
        //spriteAttack.setTextureRect(sf::IntRect(counterAnimation * 32, 2 * 32, 32, 32));
    }
    counterLifetime++;
    if (counterLifetime >= lifeTime)
    {
        destroy = true;
    }
    // Rect set at Sprite
    rectA.setPosition(spriteAttack.getPosition());
}