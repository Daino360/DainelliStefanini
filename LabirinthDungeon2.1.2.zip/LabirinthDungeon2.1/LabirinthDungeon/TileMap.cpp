//
// Created by Stefano on 24/11/2017.
//

#include "TileMap.h"
#include "Hero.h"
#include "Die.h"
#include "Menu.h"
#include "ChooseHero.h"
#include "Factory.h"
#include "AttackStrategy.h"
#include "Strategy.h"
#include "memory" //serve per usare gli smart pointer unique_ptr, shared_ptr, weak_ptr
#include "MovementStrategy.h"
#include <fstream>
#include <list>
#include <tgmath.h>
#include <iostream>

bool TileMap::load(const std::string& tileset, sf::Vector2u tileSize, const int* tiles, unsigned int width, unsigned int height){
    // load the tileset texture
    if (!m_tileset.loadFromFile(tileset))
        return false;

    // resize the vertex array to fit the level size
    m_vertices.setPrimitiveType(sf::Quads);
    m_vertices.resize(width * height * 4);

    // populate the vertex array, with one quad per tile
    for (unsigned int i = 0; i < width; ++i)
        for (unsigned int j = 0; j < height; ++j)
        {
            // get the current tile number
            int tileNumber = tiles[i + j * width];

            // find its position in the tileset texture
            int tu = tileNumber % (m_tileset.getSize().x / tileSize.x);
            int tv = tileNumber / (m_tileset.getSize().x / tileSize.x);

            // get a pointer to the current tile's quad
            sf::Vertex* quad = &m_vertices[(i + j * width) * 4];

            // define its 4 corners
            quad[0].position = sf::Vector2f(i * tileSize.x, j * tileSize.y);
            quad[1].position = sf::Vector2f((i + 1) * tileSize.x, j * tileSize.y);
            quad[2].position = sf::Vector2f((i + 1) * tileSize.x, (j + 1) * tileSize.y);
            quad[3].position = sf::Vector2f(i * tileSize.x, (j + 1) * tileSize.y);

            // define its 4 texture coordinates
            quad[0].texCoords = sf::Vector2f(tu * tileSize.x, tv * tileSize.y);
            quad[1].texCoords = sf::Vector2f((tu + 1) * tileSize.x, tv * tileSize.y);
            quad[2].texCoords = sf::Vector2f((tu + 1) * tileSize.x, (tv + 1) * tileSize.y);
            quad[3].texCoords = sf::Vector2f(tu * tileSize.x, (tv + 1) * tileSize.y);
        }

    return true;
}


//int TileMap::renderMap( sf::Sprite characterSE, GameCharacter* uEnemy){
int TileMap::renderMap( ){//sf::Sprite characterSE){

    GameCharacter *yourHero = NULL;

    GameCharacter *arrayOfEnemy[MAX_NUMBER_OF_ENEMIES];
    for(iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){
        arrayOfEnemy[iEnemy] = Enemy::GetEnemy();
        //GameCharacter *yourEnemy = Enemy::GetEnemy();//created by factory
    }


    // print the content of a text file.
    std::ifstream ifs;
    ifs.open("Mappetta.txt", std::ifstream::in); //open Mappetta.txt where is Map set
    char v = ifs.get();
    std::list<int> list = std::list<int>(); //list where will be insered all 0,1,2 of Mappetta.txt

    while (ifs.good()) {
        //std::cout << v;
        v = ifs.get();
        if(v=='0' || v=='1' || v=='2')
        {
            list.push_back((int)v);
        }
    }
    ifs.close();

    int tile;
    int level[list.size()]; //final array to create the Map
    int myarray[list.size()]; //Transiction array that change: 48 = 0, 49 = 1, 50 = 2 from ASCII tabels
// define the level with an array of tile indices
    for(int i=0;i<list.size()*list.size();i++)
    {
        myarray[i] = list.front();
        if (myarray[i] == 48) {
            level[i] = 0;
        } else if (myarray[i] == 49) {
            level[i] = 1;
        } else if (myarray[i] == 50) {
            level[i] = 2;
        } else {
            std::cout << "Texture Error" << std::endl;
        }
        list.pop_front();
    }
    //int tile = (int)level;


// Keep track of the frametime
    sf::Clock clock;
    bool updateFrame=true;
    float frameCounter = 0, switchFrame = 100, frameSpeed = 500;

// create the tilemap from the level definition
    TileMap map;
    Die die(5);
    int result = die.roll(1);
    if (result == 0) {
        if (!map.load("Tileset/Tileset1.png", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 1) {
        if (!map.load("Tileset/Tileset2.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 2) {
        if (!map.load("Tileset/Tileset3.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 3) {
        if (!map.load("Tileset/Tileset4.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 4) {
        if (!map.load("Tileset/Tileset5.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    }

    //Characters Movements
    enum Direction {Down,Left,Right,Up};
    sf::Vector2i source(1, Down);

    //servono per il movimento dell'immagine mentre cammina
    sf::IntRect rectSourceSprite(32, 32, 32, 32); //for move dx sx
    sf::IntRect rectSourceSpriteup(32, 0, 32, 32); //per move up
    sf::IntRect rectSourceSpritedown(32, 64, 32, 32); //per move down
    sf::IntRect rectSourceSpriteAttack(160, 32, 32,32);//per move attack dx sx
    sf::IntRect rectSourceSpriteAttackup(160, 0, 32,32);//per move attack up
    sf::IntRect rectSourceSpriteAttackdown(160, 64, 32,32);//per move attack down
    sf::Clock exclock;

    characterS.setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell'hero

    int lastBottomPush; //serve per vedere l'ultima direzione dell'omino per farlo attaccare

    // Contatori che servono per il movimento della freccia e della fire ball
    int counter = 0;
    int counter2 = 0;
    int counter3 = 0;
    sf::Clock clock2;
    sf::Clock clock3;

    // Projectile Vector Array
    vector<AttackStrategy>::const_iterator iter;
    vector<AttackStrategy> projectileArray;

    // Projectile Object (serve per la palla di fuoco)
    class AttackStrategy AttackStrategyWA;//attack strategy del wizzard e dell'archer
    //sf::Texture textureFireBall;
    int numberOfFireBall=0;
    int counterOfFireBall =0;
    sf::Texture textureFireBall [numberOfFireBall];
    //sf::Sprite heroImageS[numberOfFireBall];
    if (!textureFireBall[counterOfFireBall].loadFromFile("fireball.png")){
        std::cout << "Texture Error" << std::endl;
    }
    //sf::Sprite spriteFireBall;
    //spriteFireBall.setTexture(textureFireBall);
    // Projectile Object
    AttackStrategyWA.spriteAttack.setTexture(textureFireBall[counterOfFireBall]);

    // Load a music to play
    sf::Music music1;
    if (!music1.openFromFile("nice_music.ogg")) {
        return EXIT_FAILURE;
    }
    // Play the music
    music1.play();

// create the window
    sf::RenderWindow window(sf::VideoMode(1920, 1080), "Labirinth Dungeon"); //sf::Style::Fullscreen for fullscreen
    window.setVerticalSyncEnabled(true); // call it once, after creating the window
    window.setFramerateLimit(60); // call it once, after creating the window

    Menu menu(window.getSize().x, window.getSize().y);
    //run the MainMenu loop
    while (window.isOpen()) {
        // Get delta time for frame-rate depended movement
        //float dt = frametime.restart().asSeconds();

        //handle events
        sf::Event event;
        while (window.pollEvent(event)) {
            switch (event.type) {
                case sf::Event::KeyPressed:
                    switch (event.key.code)
                    {
                        case sf::Keyboard::Up:
                            menu.MoveUp();
                            break;

                        case sf::Keyboard::Down:
                            menu.MoveDown();
                            break;

                        case sf::Keyboard::Return:
                            switch (menu.GetPressedItem())
                            {
                                case 0:
                                    chooseMenu=1;
                                    std::cout << "Play button has been pressed" << std::endl;
                                    window.close();
                                    break;
                                case 1:
                                    std::cout << "Option button has been pressed" << std::endl;
                                    break;
                                case 2:
                                    window.close();
                                    break;
                            }
                            break;
                    }
                /*case sf::Event::Closed:
                    window.close();
                    break;*/
            }
        }

// draw the map
        window.clear();
        menu.draw(window);
        window.display();
    }

    sf::RenderWindow windowHero(sf::VideoMode(1920, 1080), "Labirinth Dungeon"); //sf::Style::Fullscreen for fullscreen
    windowHero.setVerticalSyncEnabled(true); // call it once, after creating the window
    windowHero.setFramerateLimit(60); // call it once, after creating the window

    ChooseHero choose(windowHero.getSize().x, windowHero.getSize().y);

    if (chooseMenu==1){
    while (windowHero.isOpen()) {
        // Get delta time for frame-rate depended movement
        //float dt = frametime.restart().asSeconds();

        //handle events
        sf::Event event;
        while (windowHero.pollEvent(event)) {
            /*if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                chooseMenu=1;
                std::cout << "Play button has been pressed" << std::endl;
                // get global mouse position
                //sf::Vector2i position = sf::Mouse::getPosition();
                // set mouse position relative to a window
                //sf::Mouse::setPosition(sf::Vector2i(100, 200), window);
            }*/

            switch (event.type) {
                case sf::Event::KeyPressed:
                    switch (event.key.code) {
                        case sf::Keyboard::Up:
                            choose.MoveUp();
                            break;

                        case sf::Keyboard::Down:
                            choose.MoveDown();
                            break;

                        case sf::Keyboard::Return:
                            switch (choose.GetPressedHero()) {
                                case 0:
                                    yourHero=Factory::Create(archer);
                                    break;
                                case 1:
                                    yourHero=Factory::Create(warrior);
                                    break;
                                case 2:
                                    yourHero=Factory::Create(wizard);
                                    break;
                            }
                            windowHero.close();
                            break;
                    }
                break;
            }
        }

// draw the map
        windowHero.clear();
        if (chooseMenu == 1)
            choose.draw(windowHero);
        windowHero.display();
    }
}
    sf::RenderWindow game(sf::VideoMode(1920, 1080), "Labirinth Dungeon"); //sf::Style::Fullscreen for fullscreen
    game.setVerticalSyncEnabled(true); // call it once, after creating the window
    game.setFramerateLimit(60); // call it once, after creating the window
    characterS = yourHero->getCharacterSprite();
    game.setFramerateLimit(999999999);

//carica la texture per i vari nemici
    widthEnemy=game.getSize().x;
    heightEnemy=game.getSize().y;
    for (iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){
        if (!enemyTexture[iEnemy].loadFromFile("Sprites/EnemySprite/goblins.png")){
            std::cout << "Texture Error" << std::endl;
        }
        enemySprite[iEnemy].setTexture(enemyTexture[iEnemy]);
        //enemySprite[iEnemy].setTexture(arrayOfEnemy[iEnemy]->getCharacterTexture());
        //enemySprite[iEnemy] = arrayOfEnemy[iEnemy]->getCharacterSprite();
        /*if (!enemyTexture[iEnemy].loadFromFile(arrayOfEnemy[iEnemy]->getFileName())){
            std::cout << "Texture Error" << std::endl;
        }*/
        enemySprite[iEnemy].scale(1.0f, 1.0f); // reduce dimensions of Character (right dimensions: 0.5f)
        enemySprite[iEnemy].setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell' enemy
    }

    AttackStrategyWA.spriteAttack.setPosition(30000, 30000);

    sf::Time time = clock.getElapsedTime();
    float playerMovementSpeed = 8;//64*time.asSeconds();
    // run the main loop (GAME LOOP)
    while (game.isOpen()) {
        //handle events
        sf::Event eventGame;
        while (game.pollEvent(eventGame)) {


            switch (eventGame.type) {

                case sf::Event::KeyPressed:
                    switch (eventGame.key.code) {

                        case sf::Keyboard::Up:
                            source.y = Up;

                            xPos = round((characterS.getPosition().x/32));
                            yPos = round((characterS.getPosition().y/32));
                            newX = xPos;
                            newY = yPos-1;
                            tile = level[newX + newY*58];
                            if (tile!=0) {
                                characterS.move(sf::Vector2f(0, -playerMovementSpeed));
                            }
                            if (exclock.getElapsedTime().asSeconds() > 1.0f){ //per il movimento dell'immagine mentre cammina
                                if (rectSourceSpriteup.left==64)
                                    rectSourceSpriteup.left=0;
                                else
                                    rectSourceSpriteup.left += 32;
                                characterS.setTextureRect(rectSourceSpriteup);
                                clock.restart();
                            }
                            if (eventGame.type == sf::Event::KeyReleased){
                                characterS.setTextureRect(sf::IntRect(32,32,32,32)); //imposta la grandezza dello sprite dell'hero
                            }
                            lastBottomPush=0; //0 = up
                            break;

                        case sf::Keyboard::Down:
                            source.y = Down;

                            xPos = round((characterS.getPosition().x/32));
                            yPos = round((characterS.getPosition().y/32));
                            newX = xPos;
                            newY = yPos+1;
                            tile = level[newX + newY*58];
                            if (tile!=0) {
                                characterS.move(sf::Vector2f(0, playerMovementSpeed));
                            }
                            //per il movimento dell'immagine mentre cammina
                            if (exclock.getElapsedTime().asSeconds() > 1.0f){
                                if (rectSourceSpritedown.left==64)
                                    rectSourceSpritedown.left=0;
                                else
                                    rectSourceSpritedown.left += 32;
                                characterS.setTextureRect(rectSourceSpritedown);
                                clock.restart();
                            }
                            if (eventGame.type == sf::Event::KeyReleased){
                                characterS.setTextureRect(sf::IntRect(32,32,32,32)); //imposta la grandezza dello sprite dell'hero
                            }
                            lastBottomPush=1; //1 = down
                            break;

                        case sf::Keyboard::Right:
                            source.x = Right;
                            //servono per la rotazione dell'immagine che passa da right a left
                            characterS.setOrigin({ 0, 0 });
                            characterS.setScale({ 1.5f, 1.5f });

                            xPos = round((characterS.getPosition().x/32));
                            yPos = round((characterS.getPosition().y/32));
                            newX = xPos+1;
                            newY = yPos;
                            tile = level[newX + newY*58];
                            if (tile!=0){ //per il movimento
                                characterS.move(sf::Vector2f(playerMovementSpeed, 0));
                            }
                            //per il movimento dell'immagine mentre cammina
                            if (exclock.getElapsedTime().asSeconds() > 1.0f){
                                if (rectSourceSprite.left==64)
                                    rectSourceSprite.left=0;
                                else
                                    rectSourceSprite.left += 32;
                                characterS.setTextureRect(rectSourceSprite);
                                clock.restart();
                            }
                            if (eventGame.type == sf::Event::KeyReleased){
                                characterS.setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell'hero
                            }
                            lastBottomPush=2; //2 = right
                            break;

                        case sf::Keyboard::Left:
                            source.x = Left;
                            //servono per la rotazione dell'immagine che passa da right a left
                            characterS.setOrigin({ characterS.getLocalBounds().width, 0 });
                            characterS.setScale({ -1.5f, 1.5f });

                            xPos = round((characterS.getPosition().x/32));
                            yPos = round((characterS.getPosition().y/32));
                            newX = xPos-1;
                            newY = yPos;
                            tile = level[newX + newY*58];
                            if (tile!=0) {
                                characterS.move(sf::Vector2f(-playerMovementSpeed, 0));
                            }
                            //per il movimento dell'immagine mentre cammina
                            if (exclock.getElapsedTime().asSeconds() > 1.0f){
                                if (rectSourceSprite.left==64)
                                    rectSourceSprite.left=0;
                                else
                                    rectSourceSprite.left += 32;
                                characterS.setTextureRect(rectSourceSprite);
                                clock.restart();
                            }
                            /*if (event.type == sf::Event::KeyReleased){
                                characterS.setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell'hero
                            }*/
                            lastBottomPush=3; //3 = left
                            break;

                        case sf::Keyboard::Escape:
                            game.close();
                            break;

                    }
                    break;
            }
            if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {

                //fire fireball
                AttackStrategyWA.rectA.setPosition(characterS.getPosition().x, characterS.getPosition().y);
                //AttackStrategyWA.rectA.setPosition(yourHero->getCharacterRect().getPosition().x + yourHero->getCharacterRect().getSize().x/2 - AttackStrategyWA.rectA.getSize().x/2,yourHero->getCharacterRect().getPosition().y + yourHero->getCharacterRect().getSize().y/2 - AttackStrategyWA.rectA.getSize().y/2);
                //AttackStrategyWA.rectA.setPosition(yourHero->getCharacterRect().getPosition().x,yourHero->getCharacterRect().getPosition().y);
                AttackStrategyWA.direction = lastBottomPush;
                projectileArray.push_back(AttackStrategyWA);
                numberOfFireBall ++;
                std::cout << "fire" << endl;

                //per il movimento dell'immagine mentre attacca
                if(lastBottomPush==2 or lastBottomPush==3) { //riconosce quale è l'ultimo tasto direzionale pigiato (dx e sx)
                    if (exclock.getElapsedTime().asSeconds() > 1.0f) {
                        if (rectSourceSpriteAttack.left == 224) //fino a dove arriva l'animazione nell'immagine
                            rectSourceSpriteAttack.left = 128; //da dove deve partire
                        else {
                            rectSourceSpriteAttack.left += 32;
                        }
                        characterS.setTextureRect(rectSourceSpriteAttack);
                        clock.restart();
                    }
                } else if(lastBottomPush==0){ //riconosce quale è l'ultimo tasto direzionale pigiato (up)
                    if (exclock.getElapsedTime().asSeconds() > 1.0f) {
                        if (rectSourceSpriteAttackup.left == 224) //fino a dove arriva l'animazione nell'immagine
                            rectSourceSpriteAttackup.left = 128; //da dove deve partire
                        else {
                            rectSourceSpriteAttackup.left += 32;
                        }
                        characterS.setTextureRect(rectSourceSpriteAttackup);
                        clock.restart();
                    }
                } else if(lastBottomPush==1) { //riconosce quale è l'ultimo tasto direzionale pigiato (down)
                    if (exclock.getElapsedTime().asSeconds() > 1.0f) {
                        if (rectSourceSpriteAttackdown.left == 224) //fino a dove arriva l'animazione nell'immagine
                            rectSourceSpriteAttackdown.left = 128; //da dove deve partire
                        else {
                            rectSourceSpriteAttackdown.left += 32;
                        }
                        characterS.setTextureRect(rectSourceSpriteAttackdown);
                        clock.restart();
                    }
                }
            }

        }
        // Draw AttackStrategy del mago e dell'archer in movimento
        counter = 0;
        for (iter = projectileArray.begin(); iter != projectileArray.end(); iter++) {
            projectileArray[counter].updateAttackMove(); // Update Attack
            //spriteFireBall = projectileArray[counter].rect;
            AttackStrategyWA.spriteAttack.setPosition(projectileArray[counter].rectA.getPosition());
            //game.draw(projectileArray[counter].rectA);
            // AttackStrategyWA.spriteAttack.setTexture(textureFireBall[counterOfFireBall]);

            game.draw(projectileArray[counter].spriteAttack);
            //game.draw(AttackStrategyWA.spriteAttack);

            counter++;
            /*for(counterOfFireBall = 0; counterOfFireBall!= numberOfFireBall; counterOfFireBall ++){
            }*/
        }


        //MovementStrategy::updateMovement(sf::Sprite characterSprite)
        //MovementStrategy::updateMovement(enemySpriteS[counterEnemy]); //dovrebbe far muovere il nemico
        //yourEnemy->updateMovement(characterSE2);


// draw the map
        game.clear();
        game.draw(map);
        //game.draw(spriteFireBall);
        game.draw(AttackStrategyWA.spriteAttack);
        game.draw(characterS);// create a Texture of Character
        drawEnemies(game);
        game.display();

    }
};


void TileMap::drawEnemies(sf::RenderWindow &window)
{
    enemySprite[0].setPosition(1500, 35); // initial position of Character
    enemySprite[1].setPosition(450, 670); // initial position of Character
    enemySprite[2].setPosition(1000, 153); // initial position of Character
    enemySprite[3].setPosition(600, 980); // initial position of Character
    enemySprite[4].setPosition(35, 870); // initial position of Character
    enemySprite[5].setPosition(1546, 313); // initial position of Character
    enemySprite[6].setPosition(1350, 678); // initial position of Character
    enemySprite[7].setPosition(45, 789); // initial position of Character
    enemySprite[8].setPosition(1534, 900); // initial position of Character
    enemySprite[9].setPosition(464, 67); // initial position of Character

    for (iEnemy = 0; iEnemy < MAX_NUMBER_OF_ENEMIES; iEnemy++)
    {
        //enemySprite[iEnemy].setPosition(100+iEnemy*100/(iEnemy+1), 300+iEnemy*100); // initial position of Character
        window.draw(enemySprite[iEnemy]);

    }

}