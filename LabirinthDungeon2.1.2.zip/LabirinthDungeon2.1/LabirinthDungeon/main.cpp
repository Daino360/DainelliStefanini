#include "Hero.h"
#include "Enemy.h"
#include "memory" //serve per usare gli smart pointer unique_ptr, shared_ptr, weak_ptr


int main(int argc, char **argv) {
    //GameCharacter *yourHero = Hero::GetHero();//created by factory
    GameCharacter *yourEnemy = Enemy::GetEnemy();//created by factory
    //GameCharacter *yourHero = NULL;
    //for (int i=0;i<10;i++)
    TileMap *window = new TileMap();
    //window->renderMap(yourHero->getCharacterSprite(), yourEnemy->getCharacterSprite(), yourHero->getCharacterTexture());
    window->renderMap(yourEnemy->getCharacterSprite());
    return 0;
}