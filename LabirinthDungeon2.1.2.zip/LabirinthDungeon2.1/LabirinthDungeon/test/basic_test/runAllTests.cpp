#include "gtest/gtest.h"

/*int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}*/

TEST(runAllTests, test_eq){
    EXPECT_EQ(1,0);
}

TEST(runAllTests, test_neq){
    EXPECT_NE(1,0);
}
