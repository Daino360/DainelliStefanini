#include <gtest/gtest.h>
#include "../../TileMap.h"

//
// Created by daino on 06/06/18.
//


class TileMapFixture : public ::testing::Test {
public:
    TileMapFixture() {}

    virtual ~TileMapFixture() {}

protected:
    virtual void TearDown() {

    }

    virtual void SetUp() {
    }

};

TEST_F(TileMapFixture, absolute_check){
    EXPECT_NE(1, 0);
}

TEST_F(TileMapFixture, tileMap_check){
    //::sleep(3);
    EXPECT_EQ(0, 0);
}


