//
// Created by Stefano on 22/11/2017.
//

#include "Enemy.h"
#include "Die.h"
#include "Factory.h"

using namespace std;

GameCharacter *Enemy::GetEnemy() {

    GameCharacter *pEnemy = NULL;
    //for (int as=0;as<10;as++){
        //Casualità nemico
        Die::initRandom();
        //Die die(as/3+3);
    Die die(3);
        int result = die.roll(1);
        //result = die.roll(1);
        if (result == 0) {
            pEnemy = Factory::Create(goblin);
            cout << "Your Enemy is a Goblin\n";
        } else if (result == 1) {
            pEnemy = Factory::Create(ghoul);
            cout << "Your Enemy is a Ghoul\n";
        } else if (result == 2) {
            pEnemy = Factory::Create(orc);
            cout << "Your Enemy is a Orc\n";
        } else if (result == 3) {
            pEnemy = Factory::Create(troll);
            cout << "Your Enemy is a Troll\n";
        }
   // }
    return pEnemy;
}


/*
Enemy* Enemy::Create(enumTypeEnemy type, int idEnemy)
{
    switch (type)
    {
        case goblin:
        {
            Enemy * h = new Enemy(goblin,10,80,30,5);
            h->setUpSpriteEnemy("goblinsword.png", idEnemy);
            return h;
            break;
        }
        case ghoul:
        {
            Enemy * h = new Enemy(ghoul,10,80,30,5);
            h->setUpSpriteEnemy("ghoul3.png", idEnemy);
            return h;
            break;
        }
        case orc:
        {
            Enemy * h = new Enemy(orc,10,80,30,5);
            h->setUpSpriteEnemy("orc2.png", idEnemy);
            return h;
            break;
        }
        case troll:
        {
            Enemy * h = new Enemy(troll,10,80,30,5);
            h->setUpSpriteEnemy("troll2.png", idEnemy);
            return h;
            break;
        }
    }
}*/

