//
// Created by Stefano on 22/11/2017.
//

#ifndef PLATFORMDUNGEON_STRATEGY_H
#define PLATFORMDUNGEON_STRATEGY_H

#include <SFML/Graphics.hpp>
using namespace std;

#define MAX_NUMBER_OF_ENEMIES 10

class Strategy {
public:
    Strategy(float widthE, float heightE);
    ~Strategy();
    //virtual int getIncrease();
    //virtual int setIncrease();
    void drawEnemies(sf::RenderWindow &window);

private:
    sf::Sprite enemySprite[MAX_NUMBER_OF_ENEMIES];
    sf::Texture enemyTexture[MAX_NUMBER_OF_ENEMIES];
    int iEnemy;
    float widthEnemy;
    float heightEnemy;

};


#endif //PLATFORMDUNGEON_STRATEGY_H
