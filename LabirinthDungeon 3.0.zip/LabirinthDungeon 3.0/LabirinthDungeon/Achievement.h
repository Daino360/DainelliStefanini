//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_ACHIEVEMENT_H
#define PLATFORMDUNGEON_ACHIEVEMENT_H

#include <vector>
#include <algorithm>
#include <iostream>

#include "Subject.h"
#include "Observer.h"


//Una concreta implementazione della interfaccia Subject

class Achievement : public Subject {

    std::vector<Observer *> observers; // observer

public:

    void registerObserver(Observer *observer) override;

    void removeObserver(Observer *observer) override;

    void notifyObservers() override;

    void setState(int , std::string );

private:
    int kill = 0;
    std::string textAch;

};



#endif //PLATFORMDUNGEON_ACHIEVEMENT_H
