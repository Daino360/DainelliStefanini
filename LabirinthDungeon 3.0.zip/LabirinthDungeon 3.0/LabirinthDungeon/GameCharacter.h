//
// Created by Stefano on 25/10/2017.
//

#ifndef PLATFORMDUNGEON_GAMECHARACTER_H
#define PLATFORMDUNGEON_GAMECHARACTER_H

#include "Strategy.h"
#include "TileMap.h"
#include <iostream>
#include <list>


using namespace std;
namespace sf{}
using namespace sf;
class Strategy;
class GameCharacter {
public://DEVO FARE DEI COSTRUTTORI DI DEFAULT QUI NELL HEADER PER POTER SPECIFICARE OGNI ARMA AD OGNI PERSONAGGIO

    GameCharacter(int h, int d, int a, int df);
    //virtual ~GameCharacter(){}; //per renderlo puramaente virtuale dovrei mettere virtual ~GameCharacter()=0;
    virtual ~GameCharacter()=0; //distruttore puramente virtuale

    //h-hp, d-dexterity, a-attack, df-defense
    virtual void move(int x, int y);
    bool isFighting() const {
        return fighting;
    }
    void setFighting(bool fighting) {
        GameCharacter::fighting = fighting;
    }

    int fight(GameCharacter& enemy);
    int fightHero(GameCharacter& hero);

    //Getter and Setter attributes
    int getHp() const {
        return hp;
    }

    void setHp(int hp) {
        GameCharacter::hp = hp;
    }

    int getDexterity() const {
        return dexterity;
    }

    void setDexterity(int dexterity) {
        GameCharacter::dexterity = dexterity;
    }

    int getAttack() const {
        return attack;
    }

    void setAttack(int attack) {
        GameCharacter::attack = attack;
    }

    int getDefense() const {
        return defense;
    }

    void setDefense(int defense) {
        GameCharacter::defense = defense;
    }

    Strategy *getStrategy() const {
        return strategy;
    }

    void setStrategy(Strategy *strategy) {
        GameCharacter::strategy = strategy;
    }

    bool getAliveOrNot(){
        return alive;
    };
    void setAliveOrNot(bool aliveOrNot){
        GameCharacter::alive = aliveOrNot;
    };
    bool getSeenOrNot(){
        return alive;
    };
    void setSeenOrNot(bool seenOrNot){
        GameCharacter::seen = seenOrNot;
    };

    void setUpSprite(std::string textureFileName);
    void setUpSpriteEnemy(std::string textureFileName);

    sf::Sprite getCharacterSprite(){
        return characterSprite;
    }

    sf::Texture getCharacterTexture(){
        return tx;
    }

    void setFileName(string fn){
        textureFileNameEnemy = fn;
    }
    string getFileName(){
        return textureFileNameEnemy ;
    }

    void setCharacterRect(sf::RectangleShape rectCharacter){
        rect=rectCharacter;
    }
    sf::RectangleShape getCharacterRect(){
        return rect;
    }
    int getDirection(){
        return directionGameCharacter;
    }
    void setDirection(int directionGameCharacterS){
        directionGameCharacter = directionGameCharacterS;
    }
    void setCharacterSprite(sf::Sprite getCharacterSprite) {
        characterSprite=getCharacterSprite;
    }

    void moveGameCharacter(int directionGameCharacter, float movementSpeedGameCharacter, int tile, int level[], sf::Sprite spriteGC);
    void moveEnemy(int level[], int tileEnemy, sf::Sprite *cSprite, sf::RectangleShape *cRect, float movementSpeedEnemy, int *directionE);

    int getTileEnemy() const;
    void setTileEnemy(int tileEnemy);
    /*const int *getLevelEnemy() const;
    void setLevelEnemy(int levelEnemy[], int dimMax);*/

protected:
    bool fighting;
    int hp;
    int dexterity;
    int attack;
    int defense;
    int posX, posY;
    bool alive = true;
    bool seen = false;
    int directionGameCharacter;
    int counterWalkingGameCharacter;
    //////////////////////////////////
    double xPosGamaCharacter,yPosGamaCharacter;
    int newXGamaCharacter, newYGamaCharacter;
    int tileEnemy;
    //int levelEnemy[];

protected:
    //array of the map for the enemy];
    /////////////////////////////////
    /////////////////
    float movementSpeed = 1;
    int movementLength = 100;
    /////////////////
    sf::Sprite characterSprite;
    sf::Texture tx;
    sf::RectangleShape rect;
    //int numEnemy;
    string textureFileNameEnemy;

    Strategy* strategy;//Puntatore che serve per composizione
};


#endif //PLATFORMDUNGEON_GAMECHARACTER_H

