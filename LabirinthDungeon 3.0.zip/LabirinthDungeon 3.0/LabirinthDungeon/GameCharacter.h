//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_GAMECHARACTER_H
#define PLATFORMDUNGEON_GAMECHARACTER_H

#include <iostream>
#include <list>

#include "Strategy.h"
#include "TileMap.h"

using namespace std;
using namespace sf;
class Strategy;
class GameCharacter {
public:

    GameCharacter(int h, int d, int a, int df);    //h-hp, d-dexterity, a-attack, df-defense

    virtual ~GameCharacter()=0; //distruttore puramente virtuale

    //Getter and Setter degli attributi
    int getHp() const {
        return hp;
    }

    void setHp(int hp) {
        GameCharacter::hp = hp;
    }

    int getDexterity() const {
        return dexterity;
    }

    int getAttack() const {
        return attack;
    }

    void setAttack(int attack) {
        GameCharacter::attack = attack;
    }

    int getDefense() const {
        return defense;
    }

    Strategy *getStrategy() const {
        return strategy;
    }

    void setStrategy(Strategy *strategy) {
        GameCharacter::strategy = strategy;
    }

    bool getAliveOrNot(){
        return alive;
    };

    void setAliveOrNot(bool aliveOrNot){
        GameCharacter::alive = aliveOrNot;
    };

    void setSeenOrNot(bool seenOrNot){
        GameCharacter::seen = seenOrNot;
    };

    sf::Sprite getCharacterSprite(){
        return characterSprite;
    }

    int getDirection(){
        return directionGameCharacter;
    }

    void setDirection(int directionGameCharacterS){
        directionGameCharacter = directionGameCharacterS;
    }

    void setUpSprite(std::string textureFileName);

    void setUpSpriteEnemy(std::string textureFileName);

    void moveGameCharacter(int directionGameCharacter, float movementSpeedGameCharacter, int tile, int level[], sf::Sprite spriteGC);

    void moveEnemy(int level[], int tileEnemy, sf::Sprite *cSprite, sf::RectangleShape *cRect, float movementSpeedEnemy, int *directionE);

    void setTileEnemy(int tileEnemy);

protected:
    int hp;
    int dexterity;
    int attack;
    int defense;
    bool alive = true;
    bool seen = false;
    int directionGameCharacter;
    double xPosGamaCharacter,yPosGamaCharacter;
    int newXGamaCharacter, newYGamaCharacter;
    int tileEnemy;
    sf::Sprite characterSprite;
    sf::Texture tx;
    sf::RectangleShape rect;

    Strategy* strategy;//Puntatore che serve per composizione
};


#endif //PLATFORMDUNGEON_GAMECHARACTER_H

