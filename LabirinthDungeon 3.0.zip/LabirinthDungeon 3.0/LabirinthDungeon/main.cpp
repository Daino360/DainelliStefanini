#include "Hero.h"

int main(int argc, char **argv) {
    unique_ptr <TileMap> window(new TileMap ());
    window->renderMap();//yourEnemy->getCharacterSprite());
    return 0;
}