//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_CHOOSEHERO_H
#define PLATFORMDUNGEON_CHOOSEHERO_H


#include <SFML/Graphics.hpp>
#include "Menu.h"

class ChooseHero {

public:
    ChooseHero(float width, float height);
    ~ChooseHero();
    void draw(sf::RenderWindow &window);
    void MoveUp();
    void MoveDown();
    int GetPressedHero() { return selectedHeroIndex; }

private:
    int selectedHeroIndex;
    sf::Texture heroImage [MAX_NUMBER_OF_ITEMS];
    sf::Sprite heroImageS[MAX_NUMBER_OF_ITEMS];
    sf::Font fontHero;
    sf::Text textHero[MAX_NUMBER_OF_ITEMS];
    sf::Texture backgroundHero;
    sf::Sprite backgroundHeroS;
};


#endif //PLATFORMDUNGEON_CHOOSEHERO_H
