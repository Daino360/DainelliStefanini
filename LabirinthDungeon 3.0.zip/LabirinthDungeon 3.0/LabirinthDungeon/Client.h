//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_CLIENT_H
#define PLATFORMDUNGEON_CLIENT_H


#include <iostream>
#include "Observer.h"

/*
 * Classe che implementa l'interfaccia di Observer a client that implements the Observer interface
 */
class Client : public Observer {
public:

    const std::string &getTextAch() const;
    void setTextAch(const std::string &textAch);


    explicit Client(int id);

    virtual void update(int, std::string ) override;
private:
    std::string textAch;
    int id;
};

#endif //PLATFORMDUNGEON_CLIENT_H
