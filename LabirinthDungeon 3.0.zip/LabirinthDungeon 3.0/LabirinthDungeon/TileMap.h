//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_MAP_H
#define PLATFORMDUNGEON_MAP_H

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <SFML/Network.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Config.hpp>
#include <SFML/OpenGL.hpp>
#include <SFML/Main.hpp>
#include <string>

#include "GameCharacter.h"

using namespace std;

#define MAX_NUMBER_OF_ENEMIES 15

class TileMap : public sf::Drawable, public sf::Transformable{
public:
    TileMap(){}; // Qui lasciamo il costruttore di Default perchè TileMap non deriva da nessuna classe
    bool load(const std::string& tileset, sf::Vector2u tileSize, const int* tiles, unsigned int width, unsigned int height);
    int renderMap();
    int iEnemy;

//////////per il movimento dell'Enemy///////////
    int counterMoveEnemy[MAX_NUMBER_OF_ENEMIES];
    float movementSpeedEnemy [MAX_NUMBER_OF_ENEMIES];
    sf::RectangleShape rectEnemy[MAX_NUMBER_OF_ENEMIES];
    int directionEnemy[MAX_NUMBER_OF_ENEMIES];
    void drawEnemies(sf::RenderWindow &window);
    sf::Sprite enemySprite[MAX_NUMBER_OF_ENEMIES];

protected:
    bool contatoreKill[MAX_NUMBER_OF_ENEMIES];
    int kill;

    sf::Font fontLevel;
    sf::Text textLevel;
    sf::Text textLevel2;
    sf::Text textLevel3;
    sf::Text textWin;
    sf::Font font5kill;
    sf::Text text5kill;

    std::string stringAch;
    sf::Text textLost;
    int chooseMenu;
    float XEmenoXH;
    float YEmenoYH;

    sf::Sprite characterS;
    sf::RectangleShape rectAttack;

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const
    {
        // apply the transform
        states.transform *= getTransform();

        // apply the tileset texture
        states.texture = &m_tileset;

        // draw the vertex array
        target.draw(m_vertices, states);
    }
    sf::VertexArray m_vertices;
    sf::Texture m_tileset;

private:
    float widthEnemy;
    float heightEnemy;
};

#endif //PLATFORMDUNGEON_MAP_H
