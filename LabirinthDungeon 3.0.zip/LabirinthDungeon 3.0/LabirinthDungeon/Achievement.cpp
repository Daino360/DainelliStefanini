//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#include "Achievement.h"

void Achievement::registerObserver(Observer *observer) {
    observers.push_back(observer);
}

void Achievement::removeObserver(Observer *observer) {
    // find the observer
    auto iterator = std::find(observers.begin(), observers.end(), observer);

    if (iterator != observers.end()) { // observer trovato
        observers.erase(iterator); // rimuove l' observer
    }
}

void Achievement::notifyObservers() {
    for (Observer *observer : observers) { // notifica gli observer
        observer->update(kill, textAch);
    }
}

void Achievement::setState(int kill, std::string textAch) {
    this->kill = kill;
    this->textAch = textAch;
    std::cout << std::endl;
    notifyObservers();
}

