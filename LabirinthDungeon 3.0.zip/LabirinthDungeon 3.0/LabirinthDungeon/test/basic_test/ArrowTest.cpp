//
// Created by daino on 01/07/18.
//

#include <gtest/gtest.h>
#include "../../AttackStrategy.h"
//Test per vedere se finiscono i colpi
TEST(Arrows, EndOfArrows) {
    AttackStrategy nH;
    int i;
    nH.numberOfHit=0;
    for(i=0;i<=150;i++)
        nH.numberOfHit++;
    bool arrows = true;
    if (nH.numberOfHit>150){
        arrows = false;
    }
    ASSERT_FALSE(arrows);
}