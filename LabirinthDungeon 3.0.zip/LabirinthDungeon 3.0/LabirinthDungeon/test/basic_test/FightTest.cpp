//
// Created by daino on 01/07/18.
//

#include <gtest/gtest.h>
#include "../../Hero.h"
#include "../../Enemy.h"
//Nemico molto forte
TEST(Fight, FightHero) {
    unique_ptr<Hero> h(new Hero("TestHero",archer,23,34,45,56));
    unique_ptr<Enemy> e(new Enemy(goblin,1000,1000,1000,1000));
    h->setHp(h->getHp() - (e->getAttack() - h->getDefense()));
    if ( h->getHp()<0){
        h->setAliveOrNot(false);
    }
    ASSERT_FALSE(h->getAliveOrNot());

}
