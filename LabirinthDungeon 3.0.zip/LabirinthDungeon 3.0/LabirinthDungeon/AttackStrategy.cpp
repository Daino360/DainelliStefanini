//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#include <tgmath.h>
#include "AttackStrategy.h"

AttackStrategy::AttackStrategy()
{
    rectA.setPosition(0, 0);
    rectA.setFillColor(sf::Color::Green);
    spriteAttack.setPosition(0, 0);
    spriteAttack.setTextureRect(sf::IntRect(0, 0, 32, 32));
}

void AttackStrategy::updateAttackMove( int tile, int level[])
{
    if (direction == 0) {// Up
        xPosAttackStrategy = round((spriteAttack.getPosition().x/32));
        yPosAttackStrategy = round((spriteAttack.getPosition().y/32));
        newXAttackStrategy = xPosAttackStrategy;
        newYAttackStrategy = yPosAttackStrategy-1;
        tile = level[newXAttackStrategy + newYAttackStrategy*58];
        if (tile!=0) {
            spriteAttack.move(0, -movementSpeed);
        } else {
            destroy = true;
        }
    }
    if (direction == 1) {// Down
        xPosAttackStrategy = round((spriteAttack.getPosition().x/32));
        yPosAttackStrategy = round((spriteAttack.getPosition().y/32));
        newXAttackStrategy = xPosAttackStrategy;
        newYAttackStrategy = yPosAttackStrategy;
        tile = level[newXAttackStrategy + newYAttackStrategy*58];
        if (tile!=0) {
            spriteAttack.move(0, movementSpeed);
        } else {
            destroy = true;
        }

    }
    if (direction == 3) {// Left
        xPosAttackStrategy = round((spriteAttack.getPosition().x/32));
        yPosAttackStrategy = round((spriteAttack.getPosition().y/32));
        newXAttackStrategy = xPosAttackStrategy-1;
        newYAttackStrategy = yPosAttackStrategy;
        tile = level[newXAttackStrategy + newYAttackStrategy*58];
        if (tile!=0) {
            spriteAttack.move(-movementSpeed, 0);
        } else {
            destroy = true;
        }
    }
    if (direction == 2) { // Right
        xPosAttackStrategy = round((spriteAttack.getPosition().x/32));
        yPosAttackStrategy = round((spriteAttack.getPosition().y/32));
        newXAttackStrategy = xPosAttackStrategy;
        newYAttackStrategy = yPosAttackStrategy;
        tile = level[newXAttackStrategy + newYAttackStrategy*58];
        if (tile!=0) {
            spriteAttack.move(movementSpeed, 0);
        } else {
            destroy = true;
        }
    }
    counterLifetime++;
    if (counterLifetime >= lifeTime)
    {
        destroy = true;
    }
    // Rect set at Sprite
    rectA.setPosition(spriteAttack.getPosition());
}