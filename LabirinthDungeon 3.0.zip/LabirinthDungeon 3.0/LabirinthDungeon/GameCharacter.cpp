//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#include <tgmath.h>
#include "GameCharacter.h"

GameCharacter::~GameCharacter() {}

//attributi di eroi e nemici
GameCharacter::GameCharacter(int h, int d, int a, int df) {
    hp = h;
    dexterity = d;
    attack = a;
    defense=df;
}

void GameCharacter::setUpSprite(std::string textureFileName){
    if (!tx.loadFromFile(textureFileName)){
        std::cout << "Texture Error" << std::endl;
    }
    characterSprite.setTexture(tx);
    characterSprite.scale(1.0f, 1.0f); // riduce dimensione Character
    characterSprite.setPosition(64,64); // posizione iniziale Character
    characterSprite.setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell'hero
}
void GameCharacter::setUpSpriteEnemy(std::string textureFileName){
    if (!tx.loadFromFile(textureFileName)){
        std::cout << "Texture Error" << std::endl;
    }
    characterSprite.setTexture(tx);

    characterSprite.scale(1.0f, 1.0f);
}

void GameCharacter::moveEnemy(int level[] ,int tileEnemy, sf::Sprite *cSprite, sf::RectangleShape *cRect, float movementSpeedEnemy, int *directionE){
    if(this->strategy)
        this->strategy->updateMoveEnemy(this, level, tileEnemy, cSprite, cRect, movementSpeedEnemy, directionE);
}

void GameCharacter::moveGameCharacter(int directionGameCharacter, float movementSpeedGameCharacter, int tile, int level[], sf::Sprite spriteGC){ //sf::Sprite spriteGC,

    if (directionGameCharacter == 0) // Up funziona
    {
        xPosGamaCharacter = round((characterSprite.getPosition().x/32));
        yPosGamaCharacter = round((characterSprite.getPosition().y/32));
        newXGamaCharacter = xPosGamaCharacter;
        newYGamaCharacter = yPosGamaCharacter-1;
        tile = level[newXGamaCharacter + newYGamaCharacter*58];
        if (tile!=0) {
            characterSprite.move(0, -movementSpeedGameCharacter);
        }
    }
    else if (directionGameCharacter == 1) // Down funziona
    {

        xPosGamaCharacter = round((characterSprite.getPosition().x/32));
        yPosGamaCharacter = round((characterSprite.getPosition().y/32));
        newXGamaCharacter = xPosGamaCharacter;
        newYGamaCharacter = yPosGamaCharacter+1;
        tile = level[newXGamaCharacter + newYGamaCharacter*58];
        if (tile!=0) {
            characterSprite.move(0, movementSpeedGameCharacter);
        }
    }
    else if (directionGameCharacter == 3) // Left
    {
        xPosGamaCharacter = round((characterSprite.getPosition().x/32));
        yPosGamaCharacter = round((characterSprite.getPosition().y/32));
        newXGamaCharacter = xPosGamaCharacter-1;
        newYGamaCharacter = yPosGamaCharacter;
        tile = level[newXGamaCharacter + newYGamaCharacter*58];
        if (tile!=0) {
            characterSprite.move(-movementSpeedGameCharacter, 0);
        }
    }
    else if (directionGameCharacter == 2) // Right
    {
        xPosGamaCharacter = round((characterSprite.getPosition().x/32));
        yPosGamaCharacter = round((characterSprite.getPosition().y/32));
        newXGamaCharacter = xPosGamaCharacter+1;
        newYGamaCharacter = yPosGamaCharacter;
        tile = level[newXGamaCharacter + newYGamaCharacter*58];
        if (tile!=0){ //per il movimento
            characterSprite.move(movementSpeedGameCharacter, 0);
        }
    }
    rect.setPosition(characterSprite.getPosition());

}

void GameCharacter::setTileEnemy(int tileEnemy) {
    GameCharacter::tileEnemy = tileEnemy;
}
