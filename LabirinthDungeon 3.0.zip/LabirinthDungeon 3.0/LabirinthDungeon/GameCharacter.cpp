//
// Created by Stefano on 25/10/2017.
//

#include <tgmath.h>
#include "GameCharacter.h"

GameCharacter::~GameCharacter() {}

//attributi di eroi e nemici
GameCharacter::GameCharacter(int h, int d, int a, int df) {
    hp = h;
    dexterity = d;
    attack = a;
    defense=df;
}
//Movimento di eroi e nemici
void GameCharacter::move(int x, int y) {
    posX += x;
    if (posX <= 0)
        posX = 0;
    posY += y;
    if (posY <= 0)
        posY = 0;
}

void GameCharacter::setUpSprite(std::string textureFileName){
    if (!tx.loadFromFile(textureFileName)){
        std::cout << "Texture Error" << std::endl;
    }
    characterSprite.setTexture(tx);
    characterSprite.scale(1.0f, 1.0f); // reduce dimensions of Character (right dimensions: 0.1f)
    characterSprite.setPosition(64,64); // initial position of Character
    characterSprite.setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell'hero
    //characterSprite.setOrigin(10, 19);
}
void GameCharacter::setUpSpriteEnemy(std::string textureFileName){
    if (!tx.loadFromFile(textureFileName)){
        std::cout << "Texture Error" << std::endl;
    }
    characterSprite.setTexture(tx);

    characterSprite.scale(1.0f, 1.0f);
}

void GameCharacter::moveEnemy(int level[] ,int tileEnemy, sf::Sprite *cSprite, sf::RectangleShape *cRect, float movementSpeedEnemy, int *directionE){
    //Strategy *strategy = getStrategy();
    if(this->strategy)
        this->strategy->updateMoveEnemy(this, level, tileEnemy, cSprite, cRect, movementSpeedEnemy, directionE);
    //strategy->updateMoveEnemy(this, level, tileEnemy, cSprite, cRect, playerMovementSpeed, directionE);
    //cSprite.setPosition(this->getCharacterSprite().getPosition());
}

void GameCharacter::moveGameCharacter(int directionGameCharacter, float movementSpeedGameCharacter, int tile, int level[], sf::Sprite spriteGC){ //sf::Sprite spriteGC,

    if (directionGameCharacter == 0) // Up funziona
    {
        xPosGamaCharacter = round((characterSprite.getPosition().x/32));
        yPosGamaCharacter = round((characterSprite.getPosition().y/32));
        newXGamaCharacter = xPosGamaCharacter;
        newYGamaCharacter = yPosGamaCharacter-1;
        tile = level[newXGamaCharacter + newYGamaCharacter*58];
        if (tile!=0) {
            characterSprite.move(0, -movementSpeedGameCharacter);
            //characterSprite.setTextureRect(sf::IntRect((32* counterWalkingGameCharacter), 0, 32 , 32));
        }
    }
    else if (directionGameCharacter == 1) // Down funziona
    {

        xPosGamaCharacter = round((characterSprite.getPosition().x/32));
        yPosGamaCharacter = round((characterSprite.getPosition().y/32));
        newXGamaCharacter = xPosGamaCharacter;
        newYGamaCharacter = yPosGamaCharacter+1;
        tile = level[newXGamaCharacter + newYGamaCharacter*58];
        if (tile!=0) {
            characterSprite.move(0, movementSpeedGameCharacter);
            //characterSprite.setTextureRect(sf::IntRect((32 * counterWalkingGameCharacter), 64, 32, 32));
        }
        //rectEnemy[iEnemy].move(0, movementSpeedEnemy);
    }
    else if (directionGameCharacter == 3) // Left
    {
        xPosGamaCharacter = round((characterSprite.getPosition().x/32));
        yPosGamaCharacter = round((characterSprite.getPosition().y/32));
        newXGamaCharacter = xPosGamaCharacter-1;
        newYGamaCharacter = yPosGamaCharacter;
        tile = level[newXGamaCharacter + newYGamaCharacter*58];
        if (tile!=0) {
            characterSprite.move(-movementSpeedGameCharacter, 0);
            //characterSprite.setTextureRect(sf::IntRect((32 * counterWalkingGameCharacter), 32, 32, 32));
        }
        //rectEnemy[iEnemy].move(-movementSpeedEnemy, 0);
    }
    else if (directionGameCharacter == 2) // Right
    {
        xPosGamaCharacter = round((characterSprite.getPosition().x/32));
        yPosGamaCharacter = round((characterSprite.getPosition().y/32));
        newXGamaCharacter = xPosGamaCharacter+1;
        newYGamaCharacter = yPosGamaCharacter;
        tile = level[newXGamaCharacter + newYGamaCharacter*58];
        if (tile!=0){ //per il movimento
            characterSprite.move(movementSpeedGameCharacter, 0);
            //characterSprite.setTextureRect(sf::IntRect((32 * counterWalkingGameCharacter), 32, 32, 32));
        }
    }
    // Sprite set at Rect
    rect.setPosition(characterSprite.getPosition());
    //setCharacterSprite(characterSprite);

}

int GameCharacter::getTileEnemy() const {
    return tileEnemy;
}

void GameCharacter::setTileEnemy(int tileEnemy) {
    GameCharacter::tileEnemy = tileEnemy;
}
