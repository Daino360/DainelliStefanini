//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_ENUMFILE_H
#define PLATFORMDUNGEON_ENUMFILE_H

enum enumTypeHero : int {
    archer,
    warrior,
    wizard
};

enum enumTypeEnemy : int {//10,11,12,13 per evitare collisione con enumerazione eroi.
    goblin = 10,
    ghoul = 11,
    orc = 12,
    troll = 13
};

#endif //PLATFORMDUNGEON_ENUMFILE_H
