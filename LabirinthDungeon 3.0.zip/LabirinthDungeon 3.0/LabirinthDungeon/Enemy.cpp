//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#include "Enemy.h"
#include "Die.h"
#include "Factory.h"

using namespace std;

unique_ptr <GameCharacter> Enemy::GetEnemy(int result = -1) {

    unique_ptr <GameCharacter> pEnemy;
    //Casualità nemico
    Die::initRandom();
    for (int i=0; i<299999999; i++);
    Die die(4);
    if (result == -1)
        result = die.roll(1);
    if (result == 0) {
        pEnemy = Factory::Create(goblin);
        cout << "Your Enemy is a Goblin\n";
    } else if (result == 1) {
        pEnemy = Factory::Create(ghoul);
        cout << "Your Enemy is a Ghoul\n";
    } else if (result == 2) {
        pEnemy = Factory::Create(orc);
        cout << "Your Enemy is a Orc\n";
    } else if (result == 3) {
        pEnemy = Factory::Create(troll);
        cout << "Your Enemy is a Troll\n";
    }
    return pEnemy;
}