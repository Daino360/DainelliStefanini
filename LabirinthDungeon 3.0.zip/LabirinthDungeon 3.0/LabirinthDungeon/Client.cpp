//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#include "Client.h"
#include "TileMap.h"

void Client::update(int kill, std::string textAch ) {
// Stampa gli Achievement
    if (kill==5){
        textAch=("Good! You killed 5 Enemies!");
        setTextAch(textAch);
    } else if (kill==10){
        textAch = ("Fabulous! You killed 10 Enemies!");
        setTextAch(textAch);
    } else if (kill==14){
        textAch = ("Great! Remains only one enemy!");
        setTextAch(textAch);
    } else if (kill==20){
        textAch = ("Good Hero! You killed 20 Enemies!");
        setTextAch(textAch);
    } else if (kill==25){
        textAch = ("Great Hero! You killed 25 Enemies!");
        setTextAch(textAch);
    } else if (kill==29){
        textAch = ("Hero! Remains only one enemy!");
        setTextAch(textAch);
    } else if (kill==35){
        textAch = ("Good Legend! You killed 35 Enemies!");
        setTextAch(textAch);
    } else if (kill==40){
        textAch = ("Great Legend! You killed 40 Enemies!");
        setTextAch(textAch);
    } else if (kill==44){
        textAch = ("Legend! Remains only one enemy!");
        setTextAch(textAch);
    } else {
        textAch = ("");
        setTextAch(textAch);
    }
}

Client::Client(int id) {
    this->id = id;
}

const string &Client::getTextAch() const {
    return textAch;
}

void Client::setTextAch(const string &textAch) {
    Client::textAch = textAch;
}

