//
// Created by Giovanni Stefanini & Stefano Dainelli
// Università di Firenze
//

#ifndef PLATFORMDUNGEON_OBSERVER_H
#define PLATFORMDUNGEON_OBSERVER_H

class Observer {

public:

    /**
     * Aggiorna lo stato di questo observer
     * @param kill new kill
     */
    virtual void update(int, std::string) = 0;

};

#endif //PLATFORMDUNGEON_OBSERVER_H
