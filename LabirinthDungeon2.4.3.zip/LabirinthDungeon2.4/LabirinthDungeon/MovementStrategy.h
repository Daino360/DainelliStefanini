//
// Created by Stefano on 22/11/2017.
//

#ifndef PLATFORMDUNGEON_MOVEMENTSTRATEGY_H
#define PLATFORMDUNGEON_MOVEMENTSTRATEGY_H

#include "Strategy.h"
#include "Enemy.h"

class MovementStrategy : public Strategy{
public:
    //virtual ~MovementStrategy()=0; //Distruttore puramente virtuale che mi rende la classe astratta
    ~MovementStrategy() {};
    //MovementStrategy(float widthE, float heightE) : Strategy(widthE, heightE){}
    //metodi di questa classe devono essere tutti virtuali
    virtual int patrollingMovement();
    virtual int toHeroMovement();
    virtual Enemy *getEnemy() const {
        return enemy;
    }
    virtual void setEnemy(Enemy *enemy) {
        MovementStrategy::enemy = enemy;
    }

    int movementSpeed = 8;
    int movementLength = 100;
    int attackDamage = 5;
    int counterWalking = 0;
    int direction = 4; // 0 - up, 1 - down, 3 - left, 2 - right
    int counter = 0;

    sf::Sprite characterSprite;
    sf::Texture tx;
    sf::RectangleShape rect;

private:
    Enemy* enemy;
};

#endif //PLATFORMDUNGEON_MOVEMENTSTRATEGY_H
