//
// Created by giovanni on 29/06/18.
//

#include "Client.h"
#include "TileMap.h"

void Client::update(int kill, std::string textAch ) {
// print the changed values
    if (kill==5){
        textAch=("Hero---You killed 5 Enemies!");
        setTextAch(textAch);
    }

    if (kill==10){
        textAch = ("Fabulous---You killed 10 Enemies!");
        setTextAch(textAch);
    }

    if (kill==15){
        textAch = ("Legendary---You killed 15 Enemies!");
        setTextAch(textAch);
    }
}

Client::Client(int id) {
    this->id = id;
}

const string &Client::getTextAch() const {
    return textAch;
}

void Client::setTextAch(const string &textAch) {
    Client::textAch = textAch;
}

