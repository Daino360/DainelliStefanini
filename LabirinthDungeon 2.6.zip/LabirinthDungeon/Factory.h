//
// Created by daino on 30/05/18.
//

#ifndef PLATFORMDUNGEON_FACTORY_H
#define PLATFORMDUNGEON_FACTORY_H


#include "EnumFile.h"
#include "Hero.h"
#include "Enemy.h"

#define MAX_ENEMY_NAME 4
class Factory {
public:
    static unique_ptr <Hero>  Create(enumTypeHero type);
    static unique_ptr <Enemy> Create(enumTypeEnemy type);
    //static string fileNameEnemy;
};

#endif //PLATFORMDUNGEON_FACTORY_H
