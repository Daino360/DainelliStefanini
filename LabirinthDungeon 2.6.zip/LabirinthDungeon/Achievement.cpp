//
// Created by giovanni on 29/06/18.
//

#include "Achievement.h"
#include "Observer.h"

void Achievement::registerObserver(Observer *observer) {
    observers.push_back(observer);
}

void Achievement::removeObserver(Observer *observer) {
    // find the observer
    auto iterator = std::find(observers.begin(), observers.end(), observer);

    if (iterator != observers.end()) { // observer found
        observers.erase(iterator); // remove the observer
    }
}

void Achievement::notifyObservers() {
    for (Observer *observer : observers) { // notify all observers
        observer->update(kill, textAch);
    }
}

void Achievement::setState(int kill, std::string textAch) {
    this->kill = kill;
    this->textAch = textAch;
    std::cout << std::endl;
    notifyObservers();
}

