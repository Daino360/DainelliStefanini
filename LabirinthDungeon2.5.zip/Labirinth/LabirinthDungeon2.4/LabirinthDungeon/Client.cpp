//
// Created by daino on 28/06/18.
//

#include "Client.h"
#include "TileMap.h"

void Client::update(int kill, int killInARow, bool heroHit, string textAch ) {
// print the changed values
    if (kill==1){
        textAch=("Hero---You killed 5 Enemies");
    }

    if (kill==2)
        textAch = ("Fabulous---You killed 10 Enemies");

    if (kill==3)
        textAch = ("Legendary---You killed 15 Enemies");

    if (kill==5 & heroHit==false){
        textAch = ("Good Hero---You killed Enemies in a Row ");
    }

}

Client::Client(int id) {
    this->id = id;
}
