//
// Created by giovanni on 29/06/18.
//

#ifndef PLATFORMDUNGEON_CLIENT_H
#define PLATFORMDUNGEON_CLIENT_H


#include <iostream>
#include "Observer.h"

/**
 * a client that implements the Observer interface
 */
class Client : public Observer {

    int id;

public:
    Client(int id);

    virtual void update(int, int, bool, std::string ) override;
};

#endif //PLATFORMDUNGEON_CLIENT_H
