//
// Created by Stefano on 15/11/2017.
//

#include "Hero.h"
#include "Factory.h"

using namespace std;

void Hero::move(int x, int y) { //movimento dell' eroe
    // implementato in gameCharacter
}