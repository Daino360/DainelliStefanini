#include "gtest/gtest.h"

#include "../../GameCharacter.h"
/*
TEST(GameCharacter, DefaultConstructor) {
    GameCharacter c(23,34,45,56);
    ASSERT_EQ(0, c.getPosX());
    ASSERT_EQ(0, c.getPosY());
    ASSERT_FALSE(c.isFighting());
}


TEST(GameCharacter, TestFightingMove) {
    GameCharacter c(23,34,45,56);
    c.setFighting(true);
    c.move(1, 1);

    ASSERT_FALSE(c.isFighting());
}
*/
