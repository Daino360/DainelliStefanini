//
// Created by Stefano on 24/11/2017.
//

#include "TileMap.h"
#include "Hero.h"
#include "Die.h"
#include "Menu.h"
#include "ChooseHero.h"
#include "Factory.h"
#include "AttackStrategy.h"
#include "Strategy.h"
#include "memory" //serve per usare gli smart pointer unique_ptr, shared_ptr, weak_ptr
#include "MovementStrategy.h"
#include "Achievement.h"
#include "Client.h"
#include <fstream>
#include <list>
#include <tgmath.h>
#include <iostream>

bool TileMap::load(const std::string& tileset, sf::Vector2u tileSize, const int* tiles, unsigned int width, unsigned int height){
    // load the tileset texture
    if (!m_tileset.loadFromFile(tileset))
        return false;

    // resize the vertex array to fit the level size
    m_vertices.setPrimitiveType(sf::Quads);
    m_vertices.resize(width * height * 4);

    // populate the vertex array, with one quad per tile
    for (unsigned int i = 0; i < width; ++i)
        for (unsigned int j = 0; j < height; ++j)
        {
            // get the current tile number
            int tileNumber = tiles[i + j * width];

            // find its position in the tileset texture
            int tu = tileNumber % (m_tileset.getSize().x / tileSize.x);
            int tv = tileNumber / (m_tileset.getSize().x / tileSize.x);

            // get a pointer to the current tile's quad
            sf::Vertex* quad = &m_vertices[(i + j * width) * 4];

            // define its 4 corners
            quad[0].position = sf::Vector2f(i * tileSize.x, j * tileSize.y);
            quad[1].position = sf::Vector2f((i + 1) * tileSize.x, j * tileSize.y);
            quad[2].position = sf::Vector2f((i + 1) * tileSize.x, (j + 1) * tileSize.y);
            quad[3].position = sf::Vector2f(i * tileSize.x, (j + 1) * tileSize.y);

            // define its 4 texture coordinates
            quad[0].texCoords = sf::Vector2f(tu * tileSize.x, tv * tileSize.y);
            quad[1].texCoords = sf::Vector2f((tu + 1) * tileSize.x, tv * tileSize.y);
            quad[2].texCoords = sf::Vector2f((tu + 1) * tileSize.x, (tv + 1) * tileSize.y);
            quad[3].texCoords = sf::Vector2f(tu * tileSize.x, (tv + 1) * tileSize.y);
        }

    return true;
}


//int TileMap::renderMap( sf::Sprite characterSE, GameCharacter* uEnemy){
int TileMap::renderMap( ){//sf::Sprite characterSE){

    unique_ptr <GameCharacter> yourHero = NULL;

    unique_ptr <GameCharacter> arrayOfEnemy[MAX_NUMBER_OF_ENEMIES];
    for(iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){
        if (iEnemy < 4)
            arrayOfEnemy[iEnemy] = Enemy::GetEnemy(iEnemy);
        else
            arrayOfEnemy[iEnemy] = Enemy::GetEnemy(-1);
        enemySprite[iEnemy] = arrayOfEnemy[iEnemy]->getCharacterSprite();
        enemySprite[iEnemy].setTextureRect(IntRect(32,64,32,32));
        arrayOfEnemy[iEnemy]->getCharacterSprite().setTextureRect(IntRect(32,64,32,32));
    }

    // print the content of a text file.
    std::ifstream ifs;
    ifs.open("Mappetta.txt", std::ifstream::in); //open Mappetta.txt where is Map set
    char v = ifs.get();
    std::list<int> list = std::list<int>(); //list where will be insered all 0,1,2 of Mappetta.txt

    while (ifs.good()) {
        //std::cout << v;
        v = ifs.get();
        if(v=='0' || v=='1' || v=='2')
        {
            list.push_back((int)v);
        }
    }
    ifs.close();

    int tile;
    int tileEnemy;
    int levelEnemy[list.size()]; //array of the map for the enemy
    int level[list.size()]; //final array to create the Map
    int myarray[list.size()]; //Transiction array that change: 48 = 0, 49 = 1, 50 = 2 from ASCII tabels
// define the level with an array of tile indices
    for(int i=0;i<list.size()*list.size();i++)
    {
        myarray[i] = list.front();
        if (myarray[i] == 48) {
            level[i] = 0;
        } else if (myarray[i] == 49) {
            level[i] = 1;
        } else if (myarray[i] == 50) {
            level[i] = 2;
        } else {
            std::cout << "Texture Error" << std::endl;
        }
        list.pop_front();
    }

// Keep track of the frametime
    sf::Clock clock;
    bool updateFrame=true;
    float frameCounter = 0, switchFrame = 100, frameSpeed = 500;

// create the tilemap from the level definition
    TileMap map;
    Die die(5);
    int result = die.roll(1);
    if (result == 0) {
        if (!map.load("Tileset/Tileset1.png", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 1) {
        if (!map.load("Tileset/Tileset2.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 2) {
        if (!map.load("Tileset/Tileset3.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 3) {
        if (!map.load("Tileset/Tileset4.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    } else if (result == 4) {
        if (!map.load("Tileset/Tileset5.jpg", sf::Vector2u(32, 32), level, 58, 33)){
            std::cout << "Texture Error" << std::endl;}
    }

    //Characters Movements
    enum Direction {Down,Left,Right,Up};
    sf::Vector2i source(1, Down);

    //servono per il movimento dell'immagine mentre cammina
    sf::IntRect rectSourceSprite(32, 32, 32, 32); //for move dx sx
    sf::IntRect rectSourceSpriteup(32, 0, 32, 32); //per move up
    sf::IntRect rectSourceSpritedown(32, 64, 32, 32); //per move down
    sf::IntRect rectSourceSpriteAttack(160, 32, 32,32);//per move attack dx sx
    sf::IntRect rectSourceSpriteAttackup(160, 0, 32,32);//per move attack up
    sf::IntRect rectSourceSpriteAttackdown(160, 64, 32,32);//per move attack down
    sf::Clock exclock;

    characterS.setTextureRect(sf::IntRect(32,64,32,32)); //imposta la grandezza dello sprite dell'hero

    int lastBottomPush=0; //serve per vedere l'ultima direzione dell'omino per farlo attaccare

    // Contatori che servono per il movimento della freccia e della fire ball
    int counter = 0;
    int counter2 = 0;
    int counter3 = 0;
    sf::Clock clock1;
    sf::Clock clock2;
    sf::Clock clock3;

    // Load a music to play
    sf::Music music1;
    if (!music1.openFromFile("nice_music.ogg")) {
        return EXIT_FAILURE;
    }
    // Play the music
    music1.play();

    // Load a music to play
    sf::Music musicLoop;
    if (!musicLoop.openFromFile("music.ogg")) {
        return EXIT_FAILURE;
    }

    // Sound effects
    sf::SoundBuffer bufferShot;
    if (!bufferShot.loadFromFile("shot.ogg"))
        return  EXIT_FAILURE;
    sf::Sound soundShot;
    soundShot.setBuffer(bufferShot);

    sf::SoundBuffer bufferCollision;
    if (!bufferCollision.loadFromFile("collision.ogg"))
        return  EXIT_FAILURE;
    sf::Sound soundCollision;
    soundCollision.setBuffer(bufferCollision);

    sf::SoundBuffer bufferPlayerDamaged;
    if (!bufferPlayerDamaged.loadFromFile("playerhit.ogg"))
        return  EXIT_FAILURE;
    sf::Sound soundPlayerDamaged;
    soundPlayerDamaged.setBuffer(bufferPlayerDamaged);

// create the window
    sf::RenderWindow window(sf::VideoMode(1920, 1080), "Labirinth Dungeon"); //sf::Style::Fullscreen for fullscreen
    window.setVerticalSyncEnabled(true); // call it once, after creating the window
    window.setFramerateLimit(60); // call it once, after creating the window

    Menu menu(window.getSize().x, window.getSize().y);
    //run the MainMenu loop
    while (window.isOpen()) {
        // Get delta time for frame-rate depended movement
        //float dt = frametime.restart().asSeconds();

        //handle events
        sf::Event event;
        while (window.pollEvent(event)) {
            switch (event.type) {
                case sf::Event::KeyPressed:
                    switch (event.key.code)
                    {
                        case sf::Keyboard::Up:
                            menu.MoveUp();
                            break;

                        case sf::Keyboard::Down:
                            menu.MoveDown();
                            break;

                        case sf::Keyboard::Return:
                            switch (menu.GetPressedItem())
                            {
                                case 0:
                                    chooseMenu=1;
                                    std::cout << "Play button has been pressed" << std::endl;
                                    window.close();
                                    break;
                                case 1:
                                    std::cout << "Option button has been pressed" << std::endl;
                                    break;
                                case 2:
                                    window.close();
                                    break;
                            }
                            break;
                    }
                    /*case sf::Event::Closed:
                        window.close();
                        break;*/
            }
        }

// draw the map
        window.clear();
        menu.draw(window);
        window.display();
    }

    sf::RenderWindow windowHero(sf::VideoMode(1920, 1080), "Labirinth Dungeon"); //sf::Style::Fullscreen for fullscreen
    windowHero.setVerticalSyncEnabled(true); // call it once, after creating the window
    windowHero.setFramerateLimit(60); // call it once, after creating the window

    sf::Texture textureFireBall;//texture attaccobase
    sf::Texture textureSword;//texture per quando finiscono i colpi
    //carica la texture della fireball
    if (!textureSword.loadFromFile("sword.png")){
        std::cout << "Texture Error" << std::endl;
    }
    // Projectile Vector Array
    vector<AttackStrategy>::const_iterator iter;
    vector<AttackStrategy> projectileArray;

    // Projectile Object (serve per la palla di fuoco)
    AttackStrategy AttackStrategyWA;//crea un oggetto attack strategy del wizzard e dell'archer

   // AttackStrategyWA.spriteAttack.setTexture(textureFireBall);
    ChooseHero choose(windowHero.getSize().x, windowHero.getSize().y);

    if (chooseMenu==1){
        while (windowHero.isOpen()) {
            // Get delta time for frame-rate depended movement
            //float dt = frametime.restart().asSeconds();

            //handle events
            sf::Event event;
            while (windowHero.pollEvent(event)) {
                /*if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                    chooseMenu=1;
                    std::cout << "Play button has been pressed" << std::endl;
                    // get global mouse position
                    //sf::Vector2i position = sf::Mouse::getPosition();
                    // set mouse position relative to a window
                    //sf::Mouse::setPosition(sf::Vector2i(100, 200), window);
                }*/

                switch (event.type) {
                    case sf::Event::KeyPressed:
                        switch (event.key.code) {
                            case sf::Keyboard::Up:
                                choose.MoveUp();
                                break;

                            case sf::Keyboard::Down:
                                choose.MoveDown();
                                break;

                            case sf::Keyboard::Return:
                                switch (choose.GetPressedHero()) {
                                    case 0:
                                        yourHero=Factory::Create(archer);
                                        //carica la texture della freccia
                                        if (!textureFireBall.loadFromFile("arrow.png")){
                                            std::cout << "Texture Error" << std::endl;
                                        }
                                        AttackStrategyWA.spriteAttack.setTexture(textureFireBall);
                                        AttackStrategyWA.spriteAttack.setScale(0.8,0.8);
                                        AttackStrategyWA.lifeTime = 1000; //imposta la durata dell'immagine dell'attacco mentre si muove (vedi AttackStrategy::updateAttackMove())
                                        AttackStrategyWA.numberOfHit=150;
                                        AttackStrategyWA.movementSpeed = 64;
                                        break;
                                    case 1:
                                        yourHero=Factory::Create(warrior);
                                        //carica la texture della fireball
                                        if (!textureFireBall.loadFromFile("sword.png")){
                                            std::cout << "Texture Error" << std::endl;
                                        }
                                        AttackStrategyWA.spriteAttack.setTexture(textureFireBall);
                                        AttackStrategyWA.spriteAttack.setScale(0.8,0.8);
                                        AttackStrategyWA.lifeTime = 6; //imposta la durata dell'immagine dell'attacco mentre si muove (vedi AttackStrategy::updateAttackMove())
                                        AttackStrategyWA.movementSpeed = 8;
                                        break;
                                    case 2:
                                        yourHero=Factory::Create(wizard);
                                        //carica la texture della fireball
                                        if (!textureFireBall.loadFromFile("fireball.png")){
                                            std::cout << "Texture Error" << std::endl;
                                        }
                                        AttackStrategyWA.spriteAttack.setTexture(textureFireBall);
                                        AttackStrategyWA.spriteAttack.setScale(0.8,0.8);
                                        AttackStrategyWA.lifeTime = 1000; //imposta la durata dell'immagine dell'attacco mentre si muove (vedi AttackStrategy::updateAttackMove())
                                        AttackStrategyWA.numberOfHit=100;
                                        AttackStrategyWA.movementSpeed = 32;
                                        break;
                                }
                                windowHero.close();
                                break;
                        }
                        break;
                }
            }

// draw the map
            windowHero.clear();
            if (chooseMenu == 1)
                choose.draw(windowHero);
            windowHero.display();
        }
    }

    sf::RenderWindow game(sf::VideoMode(1920, 1080), "Labirinth Dungeon"); //sf::Style::Fullscreen for fullscreen
    game.setVerticalSyncEnabled(true); // call it once, after creating the window
    game.setFramerateLimit(60); // call it once, after creating the window

    int button; //serve per cambiare ciò che deve essere disegnato nel gioco (level1, il gioco che scorre, la morte, etc..)

    characterS = yourHero->getCharacterSprite();//imposta characterS = allo sprite dell'Hero

//carica il font del testo per i livelli!
    if (!fontLevel.loadFromFile("DungeonFont.ttf"))
    {
        std::cout << "Font Level Error" << std::endl;
    }
    textLevel.setFont(fontLevel);
    textLevel.setString("Level 1 - Click Space to start");
    textLevel.setPosition(500, 500);
    textLevel.setScale(1.5f, 1.5f);
    textLevel2.setFont(fontLevel);
    textLevel2.setString("Level 2 - Click Space to start");
    textLevel2.setPosition(500, 500);
    textLevel2.setScale(1.5f, 1.5f);
    textLevel2.setColor(sf::Color::Yellow);
    textLevel3.setFont(fontLevel);
    textLevel3.setString("Level 3 - Click Space to start");
    textLevel3.setPosition(500, 500);
    textLevel3.setScale(1.5f, 1.5f);
    textLevel3.setColor(sf::Color::Magenta);

//carica il font del testo se perdi e se vinci
    textLost.setFont(fontLevel);
    textLost.setString("YOU LOST");
    textLost.setPosition(500, 400);
    textLost.setScale(4.0f, 4.0f);
    textWin.setFont(fontLevel);
    textWin.setString("YOU WIN");
    textWin.setPosition(500, 400);
    textWin.setScale(4.0f, 4.0f);
    textWin.setColor(sf::Color::Red);

//carica la texture larghezza e altezza per i vari nemici
    widthEnemy=game.getSize().x;
    heightEnemy=game.getSize().y;

//setta la posizione dei nemici
    //devono essere multipli di 32
    enemySprite[0].setPosition(1504, 64); arrayOfEnemy[0]->getCharacterSprite().setPosition(1504, 64); // initial position of Enemy
    enemySprite[1].setPosition(448, 672); arrayOfEnemy[1]->getCharacterSprite().setPosition(448, 672); // initial position of Enemy
    enemySprite[2].setPosition(992, 256); arrayOfEnemy[2]->getCharacterSprite().setPosition(992, 256); // initial position of Enemy
    enemySprite[3].setPosition(608, 960); arrayOfEnemy[3]->getCharacterSprite().setPosition(608, 960); // initial position of Enemy
    enemySprite[4].setPosition(64, 896); arrayOfEnemy[4]->getCharacterSprite().setPosition(64, 896); // initial position of Enemy
    enemySprite[5].setPosition(1536, 256); arrayOfEnemy[5]->getCharacterSprite().setPosition(1536, 256); // initial position of Enemy
    enemySprite[6].setPosition(1344, 672); arrayOfEnemy[6]->getCharacterSprite().setPosition(1344, 672); // initial position of Enemy
    enemySprite[7].setPosition(64, 736); arrayOfEnemy[7]->getCharacterSprite().setPosition(1536, 896); // initial position of Enemy
    enemySprite[8].setPosition(1536, 896); arrayOfEnemy[8]->getCharacterSprite().setPosition(1536, 896); // initial position of Enemy
    enemySprite[9].setPosition(480, 96); arrayOfEnemy[9]->getCharacterSprite().setPosition(480, 96); // initial position of Enemy
    enemySprite[10].setPosition(128, 288); arrayOfEnemy[10]->getCharacterSprite().setPosition(128, 288); // initial position of Enemy
    enemySprite[11].setPosition(192, 448); arrayOfEnemy[11]->getCharacterSprite().setPosition(192, 448); // initial position of Enemy
    enemySprite[12].setPosition(768, 480); arrayOfEnemy[12]->getCharacterSprite().setPosition(768, 480); // initial position of Enemy
    enemySprite[13].setPosition(1312, 448); arrayOfEnemy[13]->getCharacterSprite().setPosition(1312, 448); // initial position of Enemy
    enemySprite[14].setPosition(928, 768); arrayOfEnemy[14]->getCharacterSprite().setPosition(928, 768); // initial position of Enemy

    NormalMove normalMove;
    ToHeroMove toHeroMove;

    for (iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){
        counterMoveEnemy[iEnemy]=0;//inizializzazione a zero del contatore del massimo movimento dei nemici
        arrayOfEnemy[iEnemy]->setStrategy(&normalMove); //inizializzazione del tipo di movimento dei nemici
        arrayOfEnemy[iEnemy]->setTileEnemy(tile); //inizializzazione tileEnemy =tile
    }

//servono per la previsione del muro per i nemici
    tileEnemy =tile;
    for(int i=0;i<list.size()*list.size();i++)
    {
        levelEnemy[i] = level[i];
    }

    int counterOfFireball=0; //contatore degli attacchi a distanza

    AttackStrategyWA.spriteAttack.setPosition(30000, 30000);

    sf::Time time = clock.getElapsedTime();

    float playerMovementSpeed = yourHero->getDexterity()/(16); //setta la velocità di movimento alla velocità ottimale dell'eroe
    for (iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){ //setta la velocità di movimento alla velocità ottimale dei nemici
        movementSpeedEnemy[iEnemy] = (arrayOfEnemy[iEnemy]->getDexterity()/(2*16));
    }
    // Play the music
    musicLoop.play();
    musicLoop.setLoop(true);

    int counterWalkingGameCharacter;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    bool enemyAliveOrNotI[MAX_NUMBER_OF_ENEMIES];
    bool enemySeenI[MAX_NUMBER_OF_ENEMIES];
    int enemyAttackI[MAX_NUMBER_OF_ENEMIES];
    int enemyHpI[MAX_NUMBER_OF_ENEMIES];
    for (iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){
        enemyAliveOrNotI[iEnemy] = true;
        enemySeenI[iEnemy] = false;
        enemyAttackI[iEnemy] = arrayOfEnemy[iEnemy]->getAttack();
        enemyHpI[iEnemy] = arrayOfEnemy[iEnemy]->getHp();
    }
    int movementSpeedI = AttackStrategyWA.movementSpeed;
    int lifeTimeI = AttackStrategyWA.lifeTime;
    int numberOfHitI = AttackStrategyWA.numberOfHit;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//per l'utilizzo dell'Observer
    Achievement achievement;
    Client one(1); //, two(2), three(3);
    achievement.registerObserver(&one);
    achievement.setState(kill, stringAch);

    if (!font5kill.loadFromFile("DUNGRG__.TTF")) {
        std::cout << "Font Kill Error" << std::endl;
    }
    text5kill.setFont(font5kill);
    text5kill.setPosition(1500, 30);
    text5kill.setScale(1.0f, 1.0f);
    text5kill.setString(stringAch);
    text5kill.setColor(sf::Color::Cyan);

    // run the main loop (GAME LOOP)
    while (game.isOpen()) {
        // Clock
        sf::Time elapsed1 = clock1.getElapsedTime();
        sf::Time elapsed2 = clock2.getElapsedTime();
        sf::Time elapsed3 = clock3.getElapsedTime();

        //handle events
        sf::Event eventGame;
        while (game.pollEvent(eventGame)) {


            switch (eventGame.type) {

                case sf::Event::KeyPressed:
                    switch (eventGame.key.code) {

                        case sf::Keyboard::W:
                            source.y = Up;

                            yourHero->setDirection(0); //imposta UP=0
                            //yourHero->setCharacterSprite(characterS);
                            counterWalkingGameCharacter++;
                            if (counterWalkingGameCharacter == 4)
                            {
                                counterWalkingGameCharacter = 0;
                            }
                            characterS.setTextureRect(sf::IntRect((32* counterWalkingGameCharacter), 0, 32 , 32));

                            yourHero->moveGameCharacter(yourHero->getDirection(), playerMovementSpeed, tile, level, characterS);

                            lastBottomPush=0; //0 = up
                            break;

                        case sf::Keyboard::S:
                            source.y = Down;

                            yourHero->setDirection(1); //imposta DOWN=1
                            //yourHero->setCharacterSprite(characterS);
                            counterWalkingGameCharacter++;
                            if (counterWalkingGameCharacter == 4)
                            {
                                counterWalkingGameCharacter = 0;
                            }
                            characterS.setTextureRect(sf::IntRect((32 * counterWalkingGameCharacter), 64, 32, 32));

                            yourHero->moveGameCharacter(yourHero->getDirection(), playerMovementSpeed, tile, level, characterS);

                            lastBottomPush=1; //1 = down
                            break;

                        case sf::Keyboard::D:
                            source.x = Right;

                            yourHero->setDirection(2); //imposta Right=0
                            //yourHero->setCharacterSprite(characterS);
                            counterWalkingGameCharacter++;
                            if (counterWalkingGameCharacter == 4)
                            {
                                counterWalkingGameCharacter = 0;
                            }
                            //servono per la rotazione dell'immagine che passa da right a left
                            characterS.setOrigin({ 0, 0 });
                            characterS.setScale({ 1.0f, 1.0f });
                            characterS.setTextureRect(sf::IntRect((32 * counterWalkingGameCharacter), 32, 32, 32));

                            yourHero->moveGameCharacter(yourHero->getDirection(), playerMovementSpeed, tile, level, characterS);

                            lastBottomPush=2; //2 = right
                            break;

                        case sf::Keyboard::A:
                            source.x = Left;

                            yourHero->setDirection(3); //imposta Left=0
                            //yourHero->setCharacterSprite(characterS);
                            counterWalkingGameCharacter++;
                            if (counterWalkingGameCharacter == 4)
                            {
                                counterWalkingGameCharacter = 0;
                            }
                            //servono per la rotazione dell'immagine che passa da right a left
                            characterS.setOrigin({ characterS.getLocalBounds().width, 0 });
                            characterS.setScale({ -1.0f, 1.0f });
                            characterS.setTextureRect(sf::IntRect((32 * counterWalkingGameCharacter), 32, 32, 32));

                            yourHero->moveGameCharacter(yourHero->getDirection(), playerMovementSpeed, tile, level, characterS);

                            lastBottomPush=3; //3 = left
                            break;

                        case sf::Keyboard::Escape:
                            game.close();
                            break;

                    }
                    break;
            }

            if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {

                if (yourHero->getAliveOrNot() == true){ //solo se è vivo l'eroe suona l'attacco
                    soundShot.play(); //suona la musica del colpo lanciato
                }

                counterOfFireball ++;
                //fire fireball

                AttackStrategyWA.spriteAttack.setPosition(characterS.getPosition().x +16, characterS.getPosition().y +16);
                AttackStrategyWA.direction = lastBottomPush;
                projectileArray.push_back(AttackStrategyWA);

                std::cout << "fire" << endl;

                //per il movimento dell'immagine mentre attacca
                if(lastBottomPush==2 or lastBottomPush==3) { //riconosce quale è l'ultimo tasto direzionale pigiato (dx e sx)
                    if (exclock.getElapsedTime().asSeconds() > 1.0f) {
                        if (rectSourceSpriteAttack.left == 224) //fino a dove arriva l'animazione nell'immagine
                            rectSourceSpriteAttack.left = 128; //da dove deve partire
                        else {
                            rectSourceSpriteAttack.left += 32;
                        }
                        characterS.setTextureRect(rectSourceSpriteAttack);
                        clock.restart();
                    }
                } else if(lastBottomPush==0){ //riconosce quale è l'ultimo tasto direzionale pigiato (up)
                    if (exclock.getElapsedTime().asSeconds() > 1.0f) {
                        if (rectSourceSpriteAttackup.left == 224) //fino a dove arriva l'animazione nell'immagine
                            rectSourceSpriteAttackup.left = 128; //da dove deve partire
                        else {
                            rectSourceSpriteAttackup.left += 32;
                        }
                        characterS.setTextureRect(rectSourceSpriteAttackup);
                        clock.restart();
                    }
                } else if(lastBottomPush==1) { //riconosce quale è l'ultimo tasto direzionale pigiato (down)
                    if (exclock.getElapsedTime().asSeconds() > 1.0f) {
                        if (rectSourceSpriteAttackdown.left == 224) //fino a dove arriva l'animazione nell'immagine
                            rectSourceSpriteAttackdown.left = 128; //da dove deve partire
                        else {
                            rectSourceSpriteAttackdown.left += 32;
                        }
                        characterS.setTextureRect(rectSourceSpriteAttackdown);
                        clock.restart();
                    }
                }
            }

        }

//Se l'eroe muore ruota lo sprite dell'eroe e setta la morte
        if (yourHero->getHp() < 0) { //se l'enemy è "alive" =true allora lo disegna
            /*characterS.setTextureRect(sf::IntRect(352,32,32,32)); //se il eroe è morto
            characterS.setRotation(90);
            characterS.setColor(Color::Red);
            yourHero->setDexterity(0);
             playerMovementSpeed = 0; //se l'eroe è morto non si muove più (è settato a 0 la velocità)*/
            yourHero->setAliveOrNot(false);
            playerMovementSpeed = 0; //se l'eroe è morto non si muove più (è settato a 0 la velocità)
            std::cout << "YOU LOST" << endl;
            button=666;
        }

// Draw AttackStrategy del mago e dell'archer in movimento
        counter = 0;
        for (iter = projectileArray.begin(); iter != projectileArray.end(); iter++) {
            //ruota la freccia o la palla di fuoco nel senso in cui deve andare
            if (AttackStrategyWA.direction == 0) {// Up
                AttackStrategyWA.spriteAttack.setRotation(45);
            }
            if (AttackStrategyWA.direction == 1) {// Down
                AttackStrategyWA.spriteAttack.setRotation(-135);
            }
            if (AttackStrategyWA.direction == 3) {// Left
                AttackStrategyWA.spriteAttack.setRotation(-45);
            }
            if (AttackStrategyWA.direction == 2) { // Right
                AttackStrategyWA.spriteAttack.setRotation(135);
            }

            if (projectileArray[counter].destroy == false)
            {
                projectileArray[counter].updateAttackMove(tile, level); // Update Attack sposta la freccia
                AttackStrategyWA.spriteAttack.setPosition(projectileArray[counter].spriteAttack.getPosition()); //prende la posizione dello sprite mentre si muove (disegna il movimento)
                //game.draw(projectileArray[counter].rectA);
                AttackStrategyWA.spriteAttack.setTextureRect(sf::IntRect(0,0,32,32));//rispristina la texture dell'attacco
                game.draw(projectileArray[counter].spriteAttack);
                //game.draw(AttackStrategyWA.spriteAttack);
            }
            else {
                AttackStrategyWA.spriteAttack.setTextureRect(sf::IntRect(0,0,0,0));//rimuove la texture
            }
            counter++;
        }

//muove i nemici se sono vivi
        for (iEnemy = 0; iEnemy < MAX_NUMBER_OF_ENEMIES; iEnemy++)
        {
            if (arrayOfEnemy[iEnemy]->getAliveOrNot() == true) { //se l'enemy è "alive" =true allora lo disegna
                arrayOfEnemy[iEnemy]->getStrategy();
                arrayOfEnemy[iEnemy]->getStrategy()->setComponentX(characterS.getPosition().x); //potrebbe servire per il movimento del nemico verso l'eroe
                arrayOfEnemy[iEnemy]->getStrategy()->setComponentY(characterS.getPosition().y); //potrebbe servire per il movimento del nemico verso l'eroe
                arrayOfEnemy[iEnemy]->moveEnemy(levelEnemy, tileEnemy, &enemySprite[iEnemy], &rectEnemy[iEnemy], movementSpeedEnemy[iEnemy], &directionEnemy[iEnemy]);
            } else {
                enemySprite[iEnemy].setTextureRect(sf::IntRect(352,32,32,32)); //se il nemico è morto
                enemySprite[iEnemy].setRotation(90);
                enemySprite[iEnemy].setColor(Color::Red);
                arrayOfEnemy[iEnemy]->setAttack(0); //se il nemico è morto il suo attacco è settato a 0
                //conta i nemici che sono morti
                if( contato[iEnemy] == false) {
                    kill++;
                    std::cout << kill << endl;
                }
                contato[iEnemy] = true;
            }
        }

//se il nemico interseca l'eroe, quest'ultimo subisce danno
        if (elapsed2.asSeconds() >= 0.5)
        {
            clock2.restart();
            // Enemy Collides with Player (Player takes damage)
            counter = 0;
            for (iEnemy = 0; iEnemy < MAX_NUMBER_OF_ENEMIES; iEnemy++){

                if (characterS.getGlobalBounds().intersects(enemySprite[counter].getGlobalBounds())) //finchè si intersecano il nemico "cazzotta" l'eore
                {
                    if (directionEnemy[iEnemy] == 0) // Up funziona
                    {
                        for(int contador = 5; contador<7; contador++){
                            enemySprite[iEnemy].setTextureRect(sf::IntRect((32* contador), 0, 32 , 32)); //muove l'immagine dell'enemy che attacca
                        }
                    }
                    else if (directionEnemy[iEnemy] == 1) // Down funziona
                    {
                        for(int contador = 5; contador<7; contador++) {
                            enemySprite[iEnemy].setTextureRect(sf::IntRect((32 * contador), 64, 32, 32)); //muove l'immagine dell'enemy che attacca
                        }
                    }
                    else if (directionEnemy[iEnemy] == 3) // Left
                    {
                        for(int contador = 5; contador<7; contador++) {
                            enemySprite[iEnemy].setTextureRect(sf::IntRect((32 * contador), 32, 32, 32)); //muove l'immagine dell'enemy che attacca
                        }
                    }
                    else if (directionEnemy[iEnemy] == 2) // Right
                    {
                        for(int contador = 5; contador<7; contador++) {
                            enemySprite[iEnemy].setTextureRect(sf::IntRect((32 * contador), 32, 32, 32)); //muove l'immagine dell'enemy che attacca
                        }
                    } else { //se non si muove ti cazzotta o dx o sx
                        for(int contador = 5; contador<7; contador++) {
                            enemySprite[iEnemy].setTextureRect(sf::IntRect((32 * contador), 32, 32, 32)); //muove l'immagine dell'enemy che attacca
                        }
                    }

                    yourHero->setHp(yourHero->getHp() - (arrayOfEnemy[counter]->getAttack() - yourHero->getDefense())); //leva vita all'Hero quando viene colpito dl nemico
                    cout << "vite dell'eroe:" << endl;
                    cout << yourHero->getHp() << endl;
                }

                counter++;
            }
        }

// Projectile Collides (cioè la palla di fuoco) with Enemy e gli toglie vita
        counter = 0;
        for (iter = projectileArray.begin(); iter != projectileArray.end(); iter++)
        {
            counter2 = 0;
            int counterE2;
            for (counterE2 = 0; counterE2 < MAX_NUMBER_OF_ENEMIES; counterE2++)
            {
                if (projectileArray[counter].spriteAttack.getGlobalBounds().intersects(enemySprite[counter2].getGlobalBounds()))
                {
                    if (yourHero->getAliveOrNot() == true){ //solo se è vivo l'eroe suona l'attacco
                        soundCollision.play(); //suona la musica del nemico colpito
                    }

                    projectileArray[counter].attackDamage = yourHero->getAttack(); //setta il danno dell'attacco all'attacco dell'eroe
                    projectileArray[counter].destroy = true;

                    arrayOfEnemy[counter2]->setHp(arrayOfEnemy[counter2]->getHp()-(projectileArray[counter].attackDamage - arrayOfEnemy[counter2]->getDefense())); //toglie vite al nemico [ HPnemico - (ATKeroe - DEFnemico)]
                    if (arrayOfEnemy[counter2]->getHp() <= 0)
                    {
                        arrayOfEnemy[counter2]->setAliveOrNot(false); //rende il nemico "not alive"
                        //enemySprite[counter2].setTextureRect(sf::IntRect(0,0,0,0)); // (provvisorio) imposta la texture del nemico a (0,0,0,0) in modo che non si veda//cancella lo sprite solo finchè non si muove
                    }
                    AttackStrategyWA.spriteAttack.setTextureRect(sf::IntRect(0,0,0,0));//leva la texture dell'attacco
                    projectileArray[counter].spriteAttack.setTextureRect(sf::IntRect(0,0,0,0));//ritaglio della texture diventa 0
                    cout << "colpito! nemico n*" << counter2 <<endl;
                    cout <<  arrayOfEnemy[counter2]->getHp() <<endl;
                }
                counter2++;
            }
            counter++;
        }

// Nemico che "vede" l'eroe (DA FINIRE)
        counter = 0;
        for (iEnemy = 0; iEnemy < MAX_NUMBER_OF_ENEMIES; iEnemy++) {
            XEmenoXH = (enemySprite[iEnemy].getPosition().x) - (characterS.getPosition().x);
            YEmenoYH = ((enemySprite[iEnemy].getPosition().y) - (characterS.getPosition().y)); //+58
            if(YEmenoYH>0){
                YEmenoYH = YEmenoYH +58;
            }else{
                YEmenoYH = YEmenoYH -58;
            }
            if ( (XEmenoXH > -3 && XEmenoXH < 3) || (YEmenoYH > -(2*58) && YEmenoYH < 2*58) )//area in cui i nemici vedono l'eroev(da perfezionare)
            {
                arrayOfEnemy[counter]->setSeenOrNot(true); //leva vita all'Hero quando viene colpito dl nemico
                cout << "nemico n* "<< counter <<" ha visto l'eroe" << endl;
                arrayOfEnemy[counter]->setStrategy(&toHeroMove); // setta lo strategy to Hero
            }
            counter++;
        }

// Delete Projectile (cioè le palle di fuoco)
        counter = 0;
        for (iter = projectileArray.begin(); iter != projectileArray.end(); iter++)
        {
            if (projectileArray[counter].destroy == true)
            {
                projectileArray.erase(iter);
                projectileArray[counter].rectA.setTextureRect(sf::IntRect(0,0,0,0));//ritaglio della texture diventa 0
                projectileArray[counter].spriteAttack.setTextureRect(sf::IntRect(0,0,0,0));//ritaglio della texture diventa 0
                AttackStrategyWA.spriteAttack.setTextureRect(sf::IntRect(0,0,0,0));//ritaglio della texture diventa 0
                break;
            } else {
                AttackStrategyWA.spriteAttack.setTextureRect(sf::IntRect(0,0,32,32));//rispristina la texture dell'attacco
            }
            counter++;
        }

        characterS.setPosition(yourHero->getCharacterSprite().getPosition());

//controlla se i colpi a distanza (per archer e wizard) sono finiti
        if(counterOfFireball > AttackStrategyWA.numberOfHit){
            AttackStrategyWA.spriteAttack.setTexture(textureSword);
            AttackStrategyWA.spriteAttack.setScale(0.8,0.8);
            AttackStrategyWA.lifeTime = 6;
            AttackStrategyWA.movementSpeed = 8;
        }

// Observer per gli Achivement
        achievement.registerObserver(&one);
        achievement.setState(kill, stringAch);
        text5kill.setString(one.getTextAch());

// draw the map and his elements
        game.clear();
        game.draw(textLevel);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space) && yourHero->getAliveOrNot() == true ){
            button=1;
        }
        //disegna level 1
        if (button==1){
            game.draw(map);
            game.draw(characterS);// create a Texture of Character
            drawEnemies(game);
            game.draw(AttackStrategyWA.spriteAttack);
            game.draw(text5kill);
            if (kill == 15) {
                game.draw(textLevel2);
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space) && yourHero->getAliveOrNot() == true ){
                    //ripristina l'inizializzazione
                    for (iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){
                        arrayOfEnemy[iEnemy]->setAliveOrNot(enemyAliveOrNotI[iEnemy]);
                        arrayOfEnemy[iEnemy]->setSeenOrNot(enemySeenI[iEnemy]);
                        arrayOfEnemy[iEnemy]->setAttack(enemyAttackI[iEnemy]+10); //aumenta la forza del nemico al lv 2
                        arrayOfEnemy[iEnemy]->setHp(enemyHpI[iEnemy]+10);  //aumenta la vita del nemico al lv 2
                        arrayOfEnemy[iEnemy]->setStrategy(&normalMove);
                        enemySprite[iEnemy].setColor(sf::Color::Transparent);
                        enemySprite[iEnemy].setTextureRect(sf::IntRect(32, 32, 32, 32));
                        enemySprite[iEnemy].setRotation(-90);
                        contato[iEnemy] = false;
                        //yourHero->getCharacterSprite().setPosition(64,64);
                        //characterS.setPosition(64,64);
                    }
                    AttackStrategyWA.lifeTime = lifeTimeI;
                    AttackStrategyWA.movementSpeed = movementSpeedI;
                    AttackStrategyWA.numberOfHit = numberOfHitI;
                    button=2;
                }
            }
        }
        //disegna quando perdi
        if (button==666){
            musicLoop.pause();
            musicLoop.setLoop(false);
            game.clear();
            game.draw(textLost);
        }
        //disegna level 2
        if (button==2){
            game.draw(map);
            game.draw(characterS);// create a Texture of Character
            drawEnemies(game);
            game.draw(AttackStrategyWA.spriteAttack);
            game.draw(text5kill);
            if (kill == 30) {
                game.draw(textLevel3);
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space) && yourHero->getAliveOrNot() == true ){
                    //ripristina l'inizializzazione
                    for (iEnemy=0; iEnemy<MAX_NUMBER_OF_ENEMIES; iEnemy++){
                        arrayOfEnemy[iEnemy]->setAliveOrNot(enemyAliveOrNotI[iEnemy]);
                        arrayOfEnemy[iEnemy]->setSeenOrNot(enemySeenI[iEnemy]);
                        arrayOfEnemy[iEnemy]->setAttack(enemyAttackI[iEnemy]+10); //aumenta la forza del nemico al lv 2
                        arrayOfEnemy[iEnemy]->setHp(enemyHpI[iEnemy]+10);  //aumenta la vita del nemico al lv 2
                        arrayOfEnemy[iEnemy]->setStrategy(&normalMove);
                        enemySprite[iEnemy].setColor(sf::Color::Transparent);
                        enemySprite[iEnemy].setTextureRect(sf::IntRect(32, 32, 32, 32));
                        enemySprite[iEnemy].setRotation(-90);
                        contato[iEnemy] = false;
                        //yourHero->getCharacterSprite().setPosition(64,64);
                        //characterS.setPosition(64,64);
                    }
                    AttackStrategyWA.lifeTime = lifeTimeI;
                    AttackStrategyWA.movementSpeed = movementSpeedI;
                    AttackStrategyWA.numberOfHit = numberOfHitI;
                    button=3;
                }
            }
        }
        //disegna level 3
        if (button==3){
            game.draw(map);
            game.draw(characterS);// create a Texture of Character
            drawEnemies(game);
            game.draw(AttackStrategyWA.spriteAttack);
            game.draw(text5kill);
            if (kill == 45) {
                button = 999;
                game.draw(textWin);
            }
        }
        //disegna Win
        if (button==999){
            game.draw(textWin);
        }

        game.display();                                                                                                                                                                                                                                           //ester egg
                                                                                                                                                                                                                                                                  if (sf::Keyboard::isKeyPressed(sf::Keyboard::Y)) { if (!textureFireBall.loadFromFile("demonsword.png")){ std::cout << "Texture Error" << std::endl; }AttackStrategyWA.spriteAttack.setTexture(textureFireBall);AttackStrategyWA.attackDamage =10000; }
    }
};

//draw Enemy array
void TileMap::drawEnemies(sf::RenderWindow &window)
{
    for (iEnemy = 0; iEnemy < MAX_NUMBER_OF_ENEMIES; iEnemy++)
    {
        window.draw(enemySprite[iEnemy]);
    }
}