#include <iostream>
#include "Hero.h"
#include "Enemy.h"
#include "Factory.h"
#include "Die.h"
#include "EnumFile.h"
#include "TileMap.h"
#include <fstream>
#include <list>


int main(int argc, char **argv) {


    GameCharacter *Giovanni = Hero::GetHero();//created by factory
    GameCharacter *Stefano = Enemy::GetEnemy(); //created by factory
    TileMap *Fabrizio = new TileMap();
    Fabrizio->renderMap();
    /*
    // print the content of a text file.
    std::ifstream ifs;
    ifs.open("Mappetta.txt", std::ifstream::in); //apre la Mappetta.txt dove c'è il set della Mappa
    char v = ifs.get();

    std::list<int> list = std::list<int>(); //lista in cui verranno inseriti tutti gli 0,1,2 del set mappa

    while (ifs.good()) {
        //std::cout << v;
        v = ifs.get();
        if(v=='0' || v=='1' || v=='2')
        {
            list.push_back((int)v);
        }
    }
    ifs.close();

// 48=0 , 49=1 , 50=2 dato dalle tabelle ASCII
    int level[list.size()]; //array finale che serve per creare effettivamente la mappa
    int myarray[list.size()]; //array di transizione che prende 48 come 0, 49 come 1, 50 come 2.
// define the level with an array of tile indices
    for(int i=0;i<list.size()*list.size();i++)
    {
        myarray[i] = list.front();
        if (myarray[i] == 48) {
            level[i] = 0;
        } else if (myarray[i] == 49) {
            level[i] = 1;
        } else if (myarray[i] == 50) {
            level[i] = 2;
        } else {
            std::cout << "Texture Error" << std::endl;
        }
        list.pop_front();
    }
    //int tile = (int)level;
// Keep track of the frametime
    sf::Clock frametime;

// create the window
    //sf::RenderWindow aa(sf::VideoMode(1920,1080),"Labirinth Dungeon");
    sf::RenderWindow window(sf::VideoMode(1920, 1080), "Labirinth Dungeon", sf::Style::Fullscreen); //sf::Style::Fullscreen da agg e mette lo schermo intero
    window.setVerticalSyncEnabled(true); // call it once, after creating the window
    window.setFramerateLimit(60); // call it once, after creating the window

// create the tilemap from the level definition
    TileMap map;
    if (!map.load("Tile2.jpeg", sf::Vector2u(32, 32), level, 58, 33))
        std::cout << "Texture Error" << std::endl;

    //servono per lo spostamento del Gallo
    enum Direction {Down,Left,Right,Up};
    sf::Vector2i source(1,Down);

    sf::Texture gallo;
    //const char* aa = Giovanni->getHeroTexture();
   if (Giovanni->getNumberSprite()==0){
        gallo.loadFromFile("archer.jpg");
    }else if (Giovanni->getNumberSprite()==1){
        gallo.loadFromFile("warrior.jpg");
    }else if (Giovanni->getNumberSprite()==2){
        gallo.loadFromFile("wizard.jpg");
    }
    sf::Sprite gallos;
    gallos.setTexture(gallo); // fa diventare una texture uno sprite
    gallos.scale(0.1f, 0.1f); // riduce le dimensioni del Gallo (dimensioni giuste 0.1f)
    gallos.setPosition(790, 10); // posizione iniziale del Gallo



// run the main loop (GAME LOOP)
    while (window.isOpen())
    {
        // Get delta time for frame-rate depended movement
        //float dt = frametime.restart().asSeconds();

        //handle events
        sf::Event event;
        while (window.pollEvent(event))
        {
            switch(event.type) {
                case sf::Event::KeyPressed:
                    switch (event.key.code) {

                        case sf::Keyboard::Up:
                            source.y = Up;
                            gallos.move(0, -5);
                            break;
                        case sf::Keyboard::Down:
                            source.y = Down;
                            gallos.move(0, 5);
                            break;
                        case sf::Keyboard::Right:
                            source.x = Right;
                            gallos.move(5, 0);
                            //gallos->setRotation(90); //ruota l'immagine del gallo di 90 gradi
                            break;
                        case sf::Keyboard::Left:
                            source.x = Left;
                            gallos.move(-5, 0);
                            //gallos->setRotation(0); //ruota l'immagine del gallo di 0 gradi
                            break;
                        case sf::Keyboard::Escape:
                            window.close();
                            break;

                    }
                    break;
                case sf::Event::Closed:
                    window.close();
                    break;
            }
        }
// draw the map
        window.clear();
        window.draw(map);
        window.draw(gallos);// create a Texture a forma di Gallo
        window.display();

    }

*/

    //sf::Sprite heroSpriteTrue=Giovanni->getSprite();
/*
    cout << "\n" << "Your Hero fights against Enemy";
    int damoHero = 0;
    int damoEnemy = 0;

    int done = 0;
    int c = 0;



    for (int hit = 0; hit < Stefano->getHp() || hit < Giovanni->getHp(); hit++) {

        do {
            c = getchar();
            putchar(c);
        } while (c != ' ');

        damoHero = Giovanni->fight(*Stefano);
        damoEnemy = Stefano->fightHero(*Giovanni);

        if (damoHero)
            std::cout <<" Enemy hit: " << damoHero << std::endl;
        if (Stefano->getHp() > 0)
            std::cout << "Healty Point of Enemy"<< Stefano->getHp() << std::endl;
        else {
            std::cout << "Healty Point of Enemy"<<": "<< 0 << std::endl;
        }
        if (Stefano->getHp() <= 0) {
            std::cout << "\n"<<"Enemy is dead" << std::endl;
            return 0;
        }

        if (damoEnemy && done == 0)
            std::cout << "Hero hit: " << damoEnemy << std::endl;
        if (Giovanni->getHp() > 0 && done == 0)
            std::cout << "Healty Point of Your Hero " << Giovanni->getHp()<< std::endl;
        else if (done == 0) {
            std::cout << "Healty Point of Your Hero " << 0 << std::endl;
            std::cout << "\nYour Hero is dead" << std::endl;
            return 0;
        }
    }*/
    return 0;
}