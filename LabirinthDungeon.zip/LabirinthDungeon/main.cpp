#include <iostream>
#include "Hero.h"
#include "Enemy.h"
#include "Factory.h"
#include "Die.h"
#include "EnumFile.h"
#include "TileMap.h"
#include <fstream>
#include <list>


int main(int argc, char **argv) {
    GameCharacter *Giovanni = Hero::GetHero();//created by factory
    GameCharacter *Stefano = Enemy::GetEnemy(); //created by factory
    TileMap *Fabrizio = new TileMap();
    Fabrizio->renderMap(Giovanni->getCharacterSprite());
    return 0;
}