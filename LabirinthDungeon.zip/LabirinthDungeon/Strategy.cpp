//
// Created by Stefano on 22/11/2017.
//

#include <iostream>
#include <tgmath.h>
#include "Strategy.h"
#include "Die.h"


Strategy::~Strategy() {}

void PatrollingMove::updateMoveEnemy(GameCharacter *whoMove, int levelEnemy [], sf::Sprite enemySprite, float movementSpeedEnemy) {

    whoMove->getCharacterRect().setPosition(whoMove->getCharacterSprite().getPosition());
    //whoMove->getCharacterRect().setPosition(enemySprite.getPosition());
    //rectEnemy.setPosition(enemySprite.getPosition()); //imposta il rect dove si trova il nemico

    if (whoMove->getDirection() == 0) // Up funziona
    {
        xPosEnemy = round((whoMove->getCharacterRect().getPosition().x/32));
        yPosEnemy = round((whoMove->getCharacterRect().getPosition().y/32));
        newXEnemy = xPosEnemy;
        newYEnemy = yPosEnemy-1;
        whoMove->setTileEnemy(levelEnemy[newXEnemy + newYEnemy*58]);
        if (whoMove->getTileEnemy()!=0) {
            whoMove->getCharacterRect().move(0, -movementSpeedEnemy);
            whoMove->getCharacterSprite().setTextureRect(sf::IntRect((32* counterWalkingEnemy), 0, 32 , 32));
            enemySprite.setTextureRect(sf::IntRect((32* counterWalkingEnemy), 0, 32 , 32));
        } else {
            counterMoveEnemy=movementLengthMax;
        }
    }
    else if (whoMove->getDirection() == 1) // Down funziona
    {
        xPosEnemy = round((whoMove->getCharacterRect().getPosition().x/32));
        yPosEnemy = round((whoMove->getCharacterRect().getPosition().y/32));
        newXEnemy = xPosEnemy;
        newYEnemy = yPosEnemy+1;
        whoMove->setTileEnemy(levelEnemy[newXEnemy + newYEnemy*58]);
        if (whoMove->getTileEnemy()!=0) {
            whoMove->getCharacterRect().move(0, movementSpeedEnemy);
            whoMove->getCharacterSprite().setTextureRect(sf::IntRect((32 * counterWalkingEnemy), 64, 32, 32));
            enemySprite.setTextureRect(sf::IntRect((32 * counterWalkingEnemy), 64, 32, 32));
        } else {
            counterMoveEnemy=movementLengthMax;
        }
    }
    else if (whoMove->getDirection() == 3) // Left
    {
        //servono per la rotazione dell'immagine che passa da right a left
        enemySprite.setOrigin({ enemySprite.getLocalBounds().width, 0 });
        enemySprite.setScale({ -1.0f, 1.0f });

        xPosEnemy = round((whoMove->getCharacterRect().getPosition().x/32));
        yPosEnemy = round((whoMove->getCharacterRect().getPosition().y/32));
        newXEnemy = xPosEnemy-1;
        newYEnemy = yPosEnemy;
        whoMove->setTileEnemy(levelEnemy[newXEnemy + newYEnemy*58]);
        if (whoMove->getTileEnemy()!=0) {
            whoMove->getCharacterRect().move(-movementSpeedEnemy, 0);
            whoMove->getCharacterSprite().setTextureRect(sf::IntRect((32 * counterWalkingEnemy), 32, 32, 32));
            enemySprite.setTextureRect(sf::IntRect((32 * counterWalkingEnemy), 32, 32, 32));
        } else {
            counterMoveEnemy=movementLengthMax;
        }
    }
    else if (whoMove->getDirection() == 2) // Right
    {
        //servono per la rotazione dell'immagine che passa da right a left
        enemySprite.setOrigin({ 0, 0 });
        enemySprite.setScale({ 1.0f, 1.0f });

        xPosEnemy = round((whoMove->getCharacterRect().getPosition().x/32));
        yPosEnemy = round((whoMove->getCharacterRect().getPosition().y/32));
        newXEnemy = xPosEnemy+1;
        newYEnemy = yPosEnemy;
        whoMove->setTileEnemy(levelEnemy[newXEnemy + newYEnemy*58]);
        if (whoMove->getTileEnemy()!=0){ //per il movimento
            whoMove->getCharacterRect().move(movementSpeedEnemy, 0);
            whoMove->getCharacterSprite().setTextureRect(sf::IntRect((32 * counterWalkingEnemy), 32, 32, 32));
            //enemySprite.move(movementSpeedEnemy, 0);
            enemySprite.setTextureRect(sf::IntRect((32 * counterWalkingEnemy), 32, 32, 32));
        } else {
            counterMoveEnemy=movementLengthMax;
        }
    }
    else {
        //non si muove
    }

    // Sprite set at Rect
    enemySprite.setPosition(whoMove->getCharacterRect().getPosition());
    whoMove->getCharacterSprite().setPosition(whoMove->getCharacterRect().getPosition());

    counterWalkingEnemy++;
    if (counterWalkingEnemy == 3)
    {
        counterWalkingEnemy = 0;
    }

    counterMoveEnemy++;
    if (counterMoveEnemy >= movementLengthMax)
    {
        //lancia un dado a 8 facce per la casualita del nemico
        whoMove->setDirection(Die::generateRandom(8)-1);//(probabilità che si muova 4/8 che NON si muova 4/8
        counterMoveEnemy = 0;
    }
    std::cout<< "movimento del nemico casuale"<< endl;
}

void ToHeroMove::updateMoveEnemy(GameCharacter *whoMove, int levelEnemy [], sf::Sprite enemySprite, float movementSpeedEnemy) {
    //TODO complete
    std::cout<< "movimento del nemico verso l'eroe"<< endl;
}