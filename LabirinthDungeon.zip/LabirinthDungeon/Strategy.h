//
// Created by Stefano on 22/11/2017.
//

#ifndef PLATFORMDUNGEON_STRATEGY_H
#define PLATFORMDUNGEON_STRATEGY_H

#include <SFML/Graphics.hpp>
#include "GameCharacter.h"

using namespace std;

class GameCharacter;

class Strategy {
public:

    virtual ~Strategy()=0; //distruttore puramente virtuale che mi rende la classe astratta

    virtual void updateMoveEnemy (GameCharacter* whoMove, int levelEnemy [], sf::Sprite enemySprite, float movementSpeedEnemy) =0;
    /*virtual GameCharacter *getGameCharacter() const {
        return gamecharacter;
    }
    virtual void setGameCharacter(GameCharacter *gamecharacter) {
        Strategy::gamecharacter = gamecharacter;
    }*/
    //Strategy();

protected:
    int counterMoveEnemy;
    int counterWalkingEnemy;
    int movementLengthMax = 32; //32 se si usa il dado per la direction casuale

    double xPosEnemy,yPosEnemy;
    int newXEnemy, newYEnemy;

    GameCharacter* gamecharacter;
};

class PatrollingMove : public Strategy {
public:
    void updateMoveEnemy (GameCharacter* whoMove, int levelEnemy [], sf::Sprite enemySprite, float movementSpeedEnemy);
};

class ToHeroMove : public Strategy {
public:
    void updateMoveEnemy (GameCharacter* whoMove, int levelEnemy [], sf::Sprite enemySprite, float movementSpeedEnemy);
};

#endif //PLATFORMDUNGEON_STRATEGY_H
