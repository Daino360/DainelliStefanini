//
// Created by daino on 28/06/18.
//

#ifndef PLATFORMDUNGEON_ACHIEVEMENT_H
#define PLATFORMDUNGEON_ACHIEVEMENT_H


#include <vector>
#include <algorithm>
#include <iostream>

#include "Subject.h"
#include "Observer.h"

/**
 * A concrete implementation of the Subject interface
 */
class Achievement : public Subject {
    std::vector<Observer *> observers; // observers

    int kill = 0;
    int killInARow = 0;
    bool heroHit = true;

public:

    void registerObserver(Observer *observer) override;

    void removeObserver(Observer *observer) override;

    void notifyObservers() override;

    /**
     * Set the new state of the weather station
     * @param temp new temperature
     * @param humidity new humidity
     * @param pressure new pressure
     */
    void setState(int , int, bool );

};

#endif //PLATFORMDUNGEON_ACHIEVEMENT_H
