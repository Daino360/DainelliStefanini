//
// Created by Stefano on 15/11/2017.
//

#include "Hero.h"
#include "Factory.h"
#include "EnumFile.h"

using namespace std;

void Hero::move(int x, int y) { //movimento dell' eroe
    // TODO complete
}

using namespace std;

GameCharacter *Hero::GetHero() {

    char chooseName[11];
    cout << "Choose name of your Hero!\n";
    cin >> chooseName;
    chooseName[10] = 0;
    printf("Your hero's name is %s\n", chooseName);

    GameCharacter *pHero = NULL;
    int chooseTypeHero=80;

    cout << "Choose type of your Hero, between: select 0 for archer , select 1 for warrior , select 2 for wizard\n";
    cin >> chooseTypeHero;

    //enumTypeHero tHero = (enumTypeHero) chooseTypeHero;

    if (chooseTypeHero == 0) {
        pHero = Factory::Get()->CreateCharacter(chooseTypeHero);
        cout << "Your Hero is a Archer\n";
        //GameCharacter * sprite=new GameCharacter();
        //sf::Texture spriteT = getTexture("archer.jpg");
        pHero->getSprite("archer.jpg");

        //heroTexture = (char *)"archer.jpg";
    } else if (chooseTypeHero == 1) {
        pHero = Factory::Get()->CreateCharacter(chooseTypeHero);
        cout << "Your Hero is a Warrior\n";
        //Character * sprite=new Character();
        //sf::Texture spriteT = getTexture("archer.jpg");
        pHero->getSprite("archer.jpg");

        //heroTexture = (char *)"warrior.jpg";
    } else if (chooseTypeHero == 2) {
        pHero = Factory::Get()->CreateCharacter(chooseTypeHero);
        cout << "Your Hero is a Wizard\n";
        //Character * sprite=new Character();
        //sf::Texture spriteT = getTexture("archer.jpg");
        pHero->getSprite("archer.jpg");

        //heroTexture = (char *)"wizard.jpg";
    } else {
        cout << "hai sbagliato a scegliere!\n";
        return 0;
    }
    return pHero;
}

Hero* Hero::Create(enumTypeHero type)
{
    switch (type)
    {
        case archer:
        {
            return new Hero("Legolas",archer,100,200,150,50);
            break;
        }
        case warrior:
        {
            return new Hero("Aragon", warrior, 150, 50, 100, 200);
            break;
        }
        case wizard:
        {
            return new Hero("Gandalf", wizard, 90, 150, 200, 50);
            break;
        }
    }
}