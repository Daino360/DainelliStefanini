//
// Created by Stefano on 24/11/2017.
//

#include "TileMap.h"
#include "Hero.h"
#include <fstream>
#include <list>
#include <iostream>

int TileMap::renderMap(sf::Sprite characterS){
    //Hero * sprite=new Hero();
    //sf::Sprite spriteT = sprite->getSprite();


    // print the content of a text file.
    std::ifstream ifs;
    ifs.open("Mappetta.txt", std::ifstream::in); //open Mappetta.txt where is Map set
    char v = ifs.get();

    std::list<int> list = std::list<int>(); //list where will be insered all 0,1,2 of Mappetta.txt

    while (ifs.good()) {
        //std::cout << v;
        v = ifs.get();
        if(v=='0' || v=='1' || v=='2')
        {
            list.push_back((int)v);
        }
    }
    ifs.close();

    int level[list.size()]; //final array to create the Map
    int myarray[list.size()]; //Transiction array that change: 48 = 0, 49 = 1, 50 = 2 from ASCII tabels
// define the level with an array of tile indices
    for(int i=0;i<list.size()*list.size();i++)
    {
        myarray[i] = list.front();
        if (myarray[i] == 48) {
            level[i] = 0;
        } else if (myarray[i] == 49) {
            level[i] = 1;
        } else if (myarray[i] == 50) {
            level[i] = 2;
        } else {
            std::cout << "Texture Error" << std::endl;
        }
        list.pop_front();
    }
    //int tile = (int)level;
// Keep track of the frametime
    sf::Clock frametime;

// create the window
    //sf::RenderWindow aa(sf::VideoMode(1920,1080),"Labirinth Dungeon");
    sf::RenderWindow window(sf::VideoMode(1920, 1080), "Labirinth Dungeon", sf::Style::Fullscreen); //sf::Style::Fullscreen for fullscreen
    window.setVerticalSyncEnabled(true); // call it once, after creating the window
    window.setFramerateLimit(60); // call it once, after creating the window

// create the tilemap from the level definition
    TileMap map;
    if (!map.load("Tile2.jpeg", sf::Vector2u(32, 32), level, 58, 33))
        std::cout << "Texture Error" << std::endl;

    //Characters Movements
    enum Direction {Down,Left,Right,Up};
    sf::Vector2i source(1,Down);

    /*sf::Texture character;
    if (! character.loadFromFile("archer.jpg"))
        std::cout << "Texture Error" << std::endl;
    sf::Sprite characters;
    characters.setTexture(character); // this change texture to sprite
    characters.scale(0.1f, 0.1f); // reduce dimensions of Character (right dimensions: 0.1f)
    characters.setPosition(790, 10); // initial position of Character*/



// run the main loop (GAME LOOP)
    while (window.isOpen())
    {
        // Get delta time for frame-rate depended movement
        //float dt = frametime.restart().asSeconds();

        //handle events
        sf::Event event;
        while (window.pollEvent(event))
        {
            switch(event.type) {
                case sf::Event::KeyPressed:
                    switch (event.key.code) {

                        case sf::Keyboard::Up:
                            source.y = Up;
                            characterS.move(0, -5);
                            break;
                        case sf::Keyboard::Down:
                            source.y = Down;
                            characterS.move(0, 5);
                            break;
                        case sf::Keyboard::Right:
                            source.x = Right;
                            characterS.move(5, 0);
                            //characters->setRotation(90); //rotates image of Characther of 90°degrees
                            break;
                        case sf::Keyboard::Left:
                            source.x = Left;
                            characterS.move(-5, 0);
                            //characters->setRotation(0); //rotates image of Characther of 0°degrees
                            break;
                        case sf::Keyboard::Escape:
                            window.close();
                            break;

                    }
                    break;
                case sf::Event::Closed:
                    window.close();
                    break;
            }
        }
// draw the map
        window.clear();
        window.draw(map);
        window.draw(characterS);// create a Texture of Character
        window.display();

    }
};
                    /*case sf::Event::MouseButtonPressed: {
                    sf::Texture aa;
                    if (!aa.loadFromFile("warrior.jpg"))
                        std::cout << "Texture Error" << std::endl;
                    sf::Sprite aas;
                    aas.setTexture(character); // fa diventare una texture uno sprite
                    aas.scale(1.0f, 1.0f);
                    window.draw(map);
                    window.draw(aas);
                }
                    break;*/ //per fare la palla di fuoco o il colpo di freccia
