//
// Created by Stefano on 24/11/2017.
//

#include "TileMap.h"
#include <fstream>
#include <list>
#include <iostream>

int TileMap::renderMap(){

    // print the content of a text file.
    std::ifstream ifs;
    ifs.open("Mappetta.txt", std::ifstream::in); //apre la Mappetta.txt dove c'è il set della Mappa
    char v = ifs.get();

    std::list<int> list = std::list<int>(); //lista in cui verranno inseriti tutti gli 0,1,2 del set mappa

    while (ifs.good()) {
        //std::cout << v;
        v = ifs.get();
        if(v=='0' || v=='1' || v=='2')
        {
            list.push_back((int)v);
        }
    }
    ifs.close();

// 48=0 , 49=1 , 50=2 dato dalle tabelle ASCII
    int level[list.size()]; //array finale che serve per creare effettivamente la mappa
    int myarray[list.size()]; //array di transizione che prende 48 come 0, 49 come 1, 50 come 2.
// define the level with an array of tile indices
    for(int i=0;i<list.size()*list.size();i++)
    {
        myarray[i] = list.front();
        if (myarray[i] == 48) {
            level[i] = 0;
        } else if (myarray[i] == 49) {
            level[i] = 1;
        } else if (myarray[i] == 50) {
            level[i] = 2;
        } else {
            std::cout << "Texture Error" << std::endl;
        }
        list.pop_front();
    }
    //int tile = (int)level;
// Keep track of the frametime
    sf::Clock frametime;

// create the window
    //sf::RenderWindow aa(sf::VideoMode(1920,1080),"Labirinth Dungeon");
    sf::RenderWindow window(sf::VideoMode(1920, 1080), "Labirinth Dungeon", sf::Style::Fullscreen); //sf::Style::Fullscreen da agg e mette lo schermo intero
    window.setVerticalSyncEnabled(true); // call it once, after creating the window
    window.setFramerateLimit(60); // call it once, after creating the window

// create the tilemap from the level definition
    TileMap map;
    if (!map.load("Tile2.jpeg", sf::Vector2u(32, 32), level, 58, 33))
        std::cout << "Texture Error" << std::endl;

    //servono per lo spostamento del Gallo
    enum Direction {Down,Left,Right,Up};
    sf::Vector2i source(1,Down);

    sf::Texture gallo;
    //const char* aa = Giovanni->getHeroTexture();
    /*if (Giovanni->getNumberSprite()==0){
        gallo.loadFromFile("archer.jpg");
    }else if (Giovanni->getNumberSprite()==1){
        gallo.loadFromFile("warrior.jpg");
    }else if (Giovanni->getNumberSprite()==2){
        gallo.loadFromFile("wizard.jpg");
    }*/
    if (! gallo.loadFromFile("archer.jpg"))
        std::cout << "Texture Error" << std::endl;
    sf::Sprite gallos;
    gallos.setTexture(gallo); // fa diventare una texture uno sprite
    gallos.scale(0.1f, 0.1f); // riduce le dimensioni del Gallo (dimensioni giuste 0.1f)
    gallos.setPosition(790, 10); // posizione iniziale del Gallo



// run the main loop (GAME LOOP)
    while (window.isOpen())
    {
        // Get delta time for frame-rate depended movement
        //float dt = frametime.restart().asSeconds();

        //handle events
        sf::Event event;
        while (window.pollEvent(event))
        {
            switch(event.type) {
                case sf::Event::KeyPressed:
                    switch (event.key.code) {

                        case sf::Keyboard::Up:
                            source.y = Up;
                            gallos.move(0, -5);
                            if (! gallo.loadFromFile("warrior.jpg"))
                                std::cout << "Texture Error" << std::endl;
                            break;
                        case sf::Keyboard::Down:
                            source.y = Down;
                            gallos.move(0, 5);
                            if (! gallo.loadFromFile("wizard.jpg"))
                                std::cout << "Texture Error" << std::endl;
                            break;
                        case sf::Keyboard::Right:
                            source.x = Right;
                            gallos.move(5, 0);
                            if (! gallo.loadFromFile("archer.jpg"))
                                std::cout << "Texture Error" << std::endl;

                            //gallos->setRotation(90); //ruota l'immagine del gallo di 90 gradi
                            break;
                        case sf::Keyboard::Left:
                            source.x = Left;
                            gallos.move(-5, 0);
                            if (! gallo.loadFromFile("wizard.jpg"))
                                std::cout << "Texture Error" << std::endl;
                            //gallos->setRotation(0); //ruota l'immagine del gallo di 0 gradi
                            break;
                        case sf::Keyboard::Escape:
                            window.close();
                            break;

                    }
                    break;
                case sf::Event::Closed:
                    window.close();
                    break;
            }
        }
// draw the map
        window.clear();
        window.draw(map);
        window.draw(gallos);// create a Texture a forma di Gallo
        window.display();

    }
};
                    /*case sf::Event::MouseButtonPressed: {
                    sf::Texture aa;
                    if (!aa.loadFromFile("warrior.jpg"))
                        std::cout << "Texture Error" << std::endl;
                    sf::Sprite aas;
                    aas.setTexture(gallo); // fa diventare una texture uno sprite
                    aas.scale(1.0f, 1.0f);
                    window.draw(map);
                    window.draw(aas);
                }
                    break;*/ //per fare la palla di fuoco o il colpo di freccia
