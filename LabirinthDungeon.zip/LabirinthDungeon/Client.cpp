//
// Created by daino on 28/06/18.
//

#include "Client.h"
void Client::update(int kill, int killInARow, bool heroHit) {
// print the changed values
}

Client::Client(int id) {
    this->id = id;
}
