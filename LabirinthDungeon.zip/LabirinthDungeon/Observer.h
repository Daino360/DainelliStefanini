//
// Created by daino on 28/06/18.
//

#ifndef PLATFORMDUNGEON_OBSERVER_H
#define PLATFORMDUNGEON_OBSERVER_H


class Observer {

public:

    /**
     * Update the state of this observer
     * @param kill new kill
     * @param killInARow new killInARow
     */
    virtual void update(int, int, bool) = 0;

};


#endif //PLATFORMDUNGEON_OBSERVER_H
