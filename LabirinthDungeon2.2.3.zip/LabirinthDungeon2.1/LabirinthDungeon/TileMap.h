//
// Created by Stefano on 24/11/2017.
//

#ifndef PLATFORMDUNGEON_MAP_H
#define PLATFORMDUNGEON_MAP_H


#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <SFML/Network.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Config.hpp>
#include <SFML/OpenGL.hpp>
#include <SFML/Main.hpp>
#include <string>
#include "GameCharacter.h"
#include "Store.h"
//#include "MovementStrategy.h"

using namespace std;

#define MAX_NUMBER_OF_ENEMIES 10
#define MAX_NUMBER_OF_FIREBALLS 1000

class TileMap : public sf::Drawable, public sf::Transformable{
public:
    TileMap(){}; // here we leave constructor because Map doesn't derive from any classes
    int removeCharacter();
    bool load(const std::string& tileset, sf::Vector2u tileSize, const int* tiles, unsigned int width, unsigned int height);
    //int renderMap(sf::Sprite, GameCharacter*);
    int renderMap();//sf::Sprite);

    //DrawnEnemy(float widthE, float heightE);
    int iEnemy;

    int directionAttack = 4; // 0 - up, 1 - down, 2 - right, 3 - left
    int iFireball;
    int movementSpeedAttack = 16;
    void updateAttackMove();
    /*struct fireball{
        int directionAttack = 4; // 0 - up, 1 - down, 2 - right, 3 - left
        int iFireball;
    };*/

    //sf::Sprite eSprite[MAX_NUMBER_OF_FIREBALLS];
//////////per il movimento dell'Enemy///////////
    //int directionEnemy = 1;
    int counterMoveEnemy[MAX_NUMBER_OF_ENEMIES];
    int counterWalkingEnemy[MAX_NUMBER_OF_ENEMIES];
    int movementLengthMax = 32; //32 se si usa il dado per la direction casuale
    float movementSpeedEnemy = 4;
    void updateMoveEnemy(int tileEnemy, int levelEnemy []);
    sf::RectangleShape rectEnemy[MAX_NUMBER_OF_ENEMIES];
    int directionEnemy[MAX_NUMBER_OF_ENEMIES];
//////////////////////////////////////////////
    void drawEnemies(sf::RenderWindow &window);
    sf::Sprite enemySprite[MAX_NUMBER_OF_ENEMIES];
    sf::Texture enemyTexture[MAX_NUMBER_OF_ENEMIES];


    void drawFireball(sf::RenderWindow &window);
    sf::Texture textureAttackFireball[MAX_NUMBER_OF_FIREBALLS];
    sf::Sprite spriteAttackFireball[MAX_NUMBER_OF_FIREBALLS];
protected:
    int chooseMenu;
    double xPos,yPos;
    int newX, newY;
////////////////////////////////
    double xPosEnemy[MAX_NUMBER_OF_ENEMIES],yPosEnemy[MAX_NUMBER_OF_ENEMIES];
    int newXEnemy[MAX_NUMBER_OF_ENEMIES], newYEnemy[MAX_NUMBER_OF_ENEMIES];
////////////////////////////////
    sf::Sprite characterS;
    sf::RectangleShape rectAttack;

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const
    {
        // apply the transform
        states.transform *= getTransform();

        // apply the tileset texture
        states.texture = &m_tileset;

        // draw the vertex array
        target.draw(m_vertices, states);
    }
    sf::VertexArray m_vertices;
    sf::Texture m_tileset;
private:
    float widthEnemy;
    float heightEnemy;
};

/*
class MyTileMap : public  TileMap{
public:
    MyTileMap(){};

};*/

#endif //PLATFORMDUNGEON_MAP_H
