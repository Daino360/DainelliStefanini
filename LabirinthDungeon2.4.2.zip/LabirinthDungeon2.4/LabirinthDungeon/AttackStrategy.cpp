//
// Created by Stefano on 22/11/2017.
//

#include <tgmath.h>
#include "AttackStrategy.h"

//AttackStrategy::~AttackStrategy() {}

AttackStrategy::AttackStrategy()
{
    //rectA.setSize(sf::Vector2f(32, 32));
    rectA.setPosition(0, 0);
    rectA.setFillColor(sf::Color::Green);

    /* sf::Texture textureFireBall;
     if (!textureFireBall.loadFromFile("fireball.png")){
         std::cout << "Texture Error" << std::endl;
     }*/
    //spriteAttack.setTexture(textureFireBall);
    spriteAttack.setPosition(0, 0);
    spriteAttack.setTextureRect(sf::IntRect(0, 0, 32, 32));
}

void AttackStrategy::updateAttackMove( int tile, int level[])
{
    if (direction == 0) {// Up
        xPosAttackStrategy = round((spriteAttack.getPosition().x/32));
        yPosAttackStrategy = round((spriteAttack.getPosition().y/32));
        newXAttackStrategy = xPosAttackStrategy;
        newYAttackStrategy = yPosAttackStrategy-1;
        tile = level[newXAttackStrategy + newYAttackStrategy*58];
        if (tile!=0) {
            spriteAttack.move(0, -movementSpeed);
        } else {
            destroy = true;
        }
       // spriteAttack.setRotation(90);
    }
    if (direction == 1) {// Down
        xPosAttackStrategy = round((spriteAttack.getPosition().x/32));
        yPosAttackStrategy = round((spriteAttack.getPosition().y/32));
        newXAttackStrategy = xPosAttackStrategy;
        newYAttackStrategy = yPosAttackStrategy;
        tile = level[newXAttackStrategy + newYAttackStrategy*58];
        if (tile!=0) {
            spriteAttack.move(0, movementSpeed);
        } else {
            destroy = true;
        }

        //spriteAttack.setRotation(-90);
    }
    if (direction == 3) {// Left
        xPosAttackStrategy = round((spriteAttack.getPosition().x/32));
        yPosAttackStrategy = round((spriteAttack.getPosition().y/32));
        newXAttackStrategy = xPosAttackStrategy-1;
        newYAttackStrategy = yPosAttackStrategy;
        tile = level[newXAttackStrategy + newYAttackStrategy*58];
        if (tile!=0) {
            spriteAttack.move(-movementSpeed, 0);
        } else {
            destroy = true;
        }
        //spriteAttack.setRotation(180);
    }
    if (direction == 2) { // Right
        xPosAttackStrategy = round((spriteAttack.getPosition().x/32));
        yPosAttackStrategy = round((spriteAttack.getPosition().y/32));
        newXAttackStrategy = xPosAttackStrategy;
        newYAttackStrategy = yPosAttackStrategy;
        tile = level[newXAttackStrategy + newYAttackStrategy*58];
        if (tile!=0) {
            spriteAttack.move(movementSpeed, 0);
        } else {
            destroy = true;
        }
    }
    counterLifetime++;
    if (counterLifetime >= lifeTime)
    {
        destroy = true;
    }
    // Rect set at Sprite
    rectA.setPosition(spriteAttack.getPosition());
}