//
// Created by daino on 10/01/18.
//

#include "Factory.h"

using namespace std;


/* Enemy factory constructor.
Private, called by the singleton accessor on first call.
Register the types of enemies here.
*/
Factory::Factory()
{
    Register("Troll", &Troll::Create);
    Register("Goblin", &Goblin::Create);
    Register("Ghoul", &Ghoul::Create);
    Register("Orc", &Orc::Create);
    RegisterH(archer, &Archer::Create);
    RegisterH(warrior, &Warrior::Create);
    RegisterH(wizard, &Wizard::Create);

}

void Factory::Register(const string &enemyName, CreateEnemyFn pfnCreate)
{
    m_FactoryMap[enemyName] = pfnCreate;
}

void Factory::RegisterH(const int &chooseTypeHero, CreateHeroFn pfnCreate)
{
    m_FactoryMapH[chooseTypeHero] = pfnCreate;
}