//
// Created by giovanni on 08/06/18.
//

#ifndef PLATFORMDUNGEON_TEXTDISPLAY_H
#define PLATFORMDUNGEON_TEXTDISPLAY_H

#include "TileMap.h"
#include "Die.h"
#include <iostream>



using namespace std;

class TextDisplay
{
public:
    float movementSpeed = 2;
    string myString = "Default";
    int counter = 0;
    int lifeTime = 100;
    bool destroy = false;

    sf::Sprite sprite;
    sf::Text text;
    sf::RectangleShape rect;

    TextDisplay();
    void update();
    //void updateMovement();
};


#endif //PLATFORMDUNGEON_TEXTDISPLAY_H
