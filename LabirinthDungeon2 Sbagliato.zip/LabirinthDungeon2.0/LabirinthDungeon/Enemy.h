//
// Created by Stefano on 22/11/2017.
//

#ifndef PLATFORMDUNGEON_ENEMY_H
#define PLATFORMDUNGEON_ENEMY_H

#include "GameCharacter.h"

#include "Die.h"
#include <string>
#include <map>
#include <iostream>

using namespace std;

class Enemy : public GameCharacter { // Enemy eredita da GameCharacter
public:
    Enemy(enumTypeEnemy tEnemy, int h, int d, int a, int df) : GameCharacter(h, d, a, df){ //Abbiamo tolto i costruttore di efault e messo la dipendenza dagli attributi di GameCharacter
        typeEnemy = tEnemy;

    }

    static GameCharacter *GetEnemy();
    //static Enemy * Create(enumTypeEnemy type, int);

    //servono per il movimento
    /*
    int movementSpeed = 8;
    int movementLength = 100;
    int attackDamage = 5;
    int counterWalking = 0;
    int direction = 0; // 1 - up, 2 - down, 3 - left, 4 - right
    int counter = 0;
     */
    /*sf::Sprite characterSprite;
    sf::Texture tx;
    sf::RectangleShape rect;*/
    //void update();
    //void updateMovement(sf::Sprite characterSprite);

private:
    enumTypeEnemy typeEnemy;

};

#endif //PLATFORMDUNGEON_ENEMY_H
