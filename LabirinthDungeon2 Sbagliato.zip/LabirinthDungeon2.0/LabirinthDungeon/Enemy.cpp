//
// Created by Stefano on 22/11/2017.
//

#include "Enemy.h"
#include "Die.h"
#include "Factory.h"

using namespace std;

GameCharacter *Enemy::GetEnemy() {

    GameCharacter *pEnemy = NULL;
    int enemyName;
    //for (int as=1;as<10;as++){
        //Casualità nemico
        Die::initRandom();
        Die die(4);
        int result = die.roll(1);
        if (result == 0) {
            enemyName = goblin;
            pEnemy = Factory::Create(goblin, result);
            cout << "Your Enemy is a Goblin\n";
        } else if (result == 1) {
            enemyName = ghoul;
            pEnemy = Factory::Create(ghoul, result);
            cout << "Your Enemy is a Ghoul\n";
        } else if (result == 2) {
            enemyName = orc;
            pEnemy = Factory::Create(orc, result);
            cout << "Your Enemy is a Orc\n";
        } else if (result == 3) {
            enemyName = troll;
            pEnemy = Factory::Create(troll, result);
            cout << "Your Enemy is a Troll\n";
        }
    //}
    return pEnemy;
}
/*void Enemy::update()
{
    characterSprite.setPosition(rect.getPosition());
}*/

/*
void Enemy::updateMovement(sf::Sprite characterSprite)
{
    if (direction == 1) // Up
    {
        rect.move(0,-movementSpeed);
        characterSprite.setTextureRect(sf::IntRect((32* counterWalking), 0, 32 , 32));
    }
    else if (direction == 2) // Down
    {
        rect.move(0,movementSpeed);
        characterSprite.setTextureRect(sf::IntRect((32 * counterWalking), 64, 32, 32));
    }
    else if (direction == 3) // Left
    {
        rect.move(-movementSpeed,0);
        characterSprite.setTextureRect(sf::IntRect((32 * counterWalking), 32, 32, 32));
    }
    else if (direction == 4) // Right
    {
        rect.move(movementSpeed,0);
        characterSprite.setTextureRect(sf::IntRect((32 * counterWalking), 32, 32, 32));
    }
    else
    {
        // No movement
    }

    counterWalking++;
    if (counterWalking == 3)
    {
        counterWalking = 0;
    }

    counter++;
    if (counter >= movementLength)
    {
        direction = Die::generateRandom(10);
        counter = 0;
    }
}*/

/*
Enemy* Enemy::Create(enumTypeEnemy type, int idEnemy)
{
    switch (type)
    {
        case goblin:
        {
            Enemy * h = new Enemy(goblin,10,80,30,5);
            h->setUpSpriteEnemy("goblinsword.png", idEnemy);
            return h;
            break;
        }
        case ghoul:
        {
            Enemy * h = new Enemy(ghoul,10,80,30,5);
            h->setUpSpriteEnemy("ghoul3.png", idEnemy);
            return h;
            break;
        }
        case orc:
        {
            Enemy * h = new Enemy(orc,10,80,30,5);
            h->setUpSpriteEnemy("orc2.png", idEnemy);
            return h;
            break;
        }
        case troll:
        {
            Enemy * h = new Enemy(troll,10,80,30,5);
            h->setUpSpriteEnemy("troll2.png", idEnemy);
            return h;
            break;
        }
    }
}*/

