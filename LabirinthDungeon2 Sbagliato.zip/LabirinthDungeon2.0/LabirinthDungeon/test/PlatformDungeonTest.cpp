#include "gtest/gtest.h"
#include "../GameCharacter.h"

/*TEST(GameCharacter, DefaultConstructor) {
    GameCharacter c;
    ASSERT_EQ(0, c.getXPos());
    ASSERT_EQ(0, c.getXPos());
    ASSERT_FALSE(c.isFighting());
}


TEST(GameCharacter, TestFightingMove) {
    GameCharacter c;
    c.setFighting(true);
    c.move(1, 1);

    ASSERT_FALSE(c.isFighting());
}*/
/*
TEST(GameCharacterTest, getCharacterSpriteTest){
    GameCharacter pg (100, 100, 100, 100);
    EXPECT_EQ (0, pg );
}
 */