//
// Created by daino on 30/05/18.
//

#ifndef PLATFORMDUNGEON_FACTORY_H
#define PLATFORMDUNGEON_FACTORY_H


#include "EnumFile.h"
#include "Hero.h"
#include "Enemy.h"

class Factory {
public:
    static Hero * Create(enumTypeHero type);
    static Enemy * Create(enumTypeEnemy type, int);

};

#endif //PLATFORMDUNGEON_FACTORY_H
