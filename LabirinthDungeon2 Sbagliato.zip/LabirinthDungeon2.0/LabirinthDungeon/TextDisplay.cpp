//
// Created by giovanni on 08/06/18.
//

#include "TextDisplay.h"

TextDisplay::TextDisplay()
{
    text.setColor(sf::Color::Red);
    text.setCharacterSize(30);
    text.setString(myString);
}

void TextDisplay::update()
{
    text.move(0,-movementSpeed);

    counter++;
    if (counter >= lifeTime)
    {
        destroy = true;
    }
}
