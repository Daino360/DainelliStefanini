//
// Created by Stefano on 15/11/2017.
//

#ifndef PLATFORMDUNGEON_HERO_H
#define PLATFORMDUNGEON_HERO_H

#include "GameCharacter.h"
#include "Equipment.h"
#include "Weapon.h"
#include <string>
#include "EnumFile.h"
#include <map>
#include <iostream>

using namespace std;

class Hero : public GameCharacter {
public:
    explicit Hero(std::string nameHero, enumTypeHero tHero, int health, int dex, int atk, int def) :
            GameCharacter(health, dex, atk, def), name(nameHero), typeHero(tHero) {
        typeHero = tHero;
    }
    void move(int x, int y) override;//Mettiamo L override perchè stiamo usando un metodo di Gamecharacter

    //static GameCharacter *GetHero();

    //static Hero * Create(enumTypeHero type);

    string name;


private:
    enumTypeHero typeHero;
};


#endif //PLATFORMDUNGEON_HERO_H
