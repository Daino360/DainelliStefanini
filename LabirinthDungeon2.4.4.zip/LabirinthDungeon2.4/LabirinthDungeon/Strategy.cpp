//
// Created by Stefano on 22/11/2017.
//

#include <iostream>
#include <tgmath.h>
#include "Strategy.h"
#include "Die.h"


Strategy::~Strategy() {}

void NormalMove::updateMoveEnemy(GameCharacter *whoMove, int levelEnemy [], int tileEnemy, sf::Sprite *enemySprite, sf::RectangleShape *eRect, float movementSpeedEnemy, int *dirE) {

    eRect->setPosition(enemySprite->getPosition());
    tmpSprite=whoMove->getCharacterSprite();

    if (*dirE == 0) // Up funziona
    {
        xPosEnemy = round((eRect->getPosition().x/32));
        yPosEnemy = round((eRect->getPosition().y/32));
        newXEnemy = xPosEnemy;
        newYEnemy = yPosEnemy-1;

        tileEnemy =levelEnemy[newXEnemy + newYEnemy*58];
        if (tileEnemy!=0) {
            eRect->move(0, -movementSpeedEnemy);
            tmpSprite.setTextureRect(sf::IntRect((32* (counterWalkingEnemy)), 0, 32 , 32));
            *enemySprite = tmpSprite;

        } else {
            counterMoveEnemy=movementLengthMax;
        }
    }
    else if (*dirE == 1) // Down funziona
    {
        xPosEnemy = round((eRect->getPosition().x/32));
        yPosEnemy = round((eRect->getPosition().y/32));
        newXEnemy = xPosEnemy;
        newYEnemy = yPosEnemy+1;
        tileEnemy =levelEnemy[newXEnemy + newYEnemy*58];
        if (tileEnemy!=0) {
            eRect->move(0, movementSpeedEnemy);
            tmpSprite.setTextureRect(sf::IntRect((32 * (counterWalkingEnemy)), 64, 32, 32));
            *enemySprite = tmpSprite;
        } else {
            counterMoveEnemy=movementLengthMax;
        }
    }
    else if (*dirE == 3) // Left
    {
        //servono per la rotazione dell'immagine che passa da left a right
        tmpSprite.setOrigin({ enemySprite->getLocalBounds().width, 0 });
        tmpSprite.setScale({ -1.0f, 1.0f });

        xPosEnemy = round((eRect->getPosition().x/32));
        yPosEnemy = round((eRect->getPosition().y/32));
        newXEnemy = xPosEnemy-1;
        newYEnemy = yPosEnemy;
        tileEnemy =levelEnemy[newXEnemy + newYEnemy*58];
        if (tileEnemy!=0) {
            eRect->move(-movementSpeedEnemy, 0);
            tmpSprite.setTextureRect(sf::IntRect((32 * (counterWalkingEnemy)), 32, 32, 32));
            *enemySprite = tmpSprite;
        } else {
            counterMoveEnemy=movementLengthMax;
        }
    }
    else if (*dirE == 2)//whoMove->getDirection() == 2) // Right
    {
        //servono per la rotazione dell'immagine che passa da right a lefts
        tmpSprite.setOrigin({ 0, 0 });
        tmpSprite.setScale({ 1.0f, 1.0f });

        xPosEnemy = round((eRect->getPosition().x/32));
        yPosEnemy = round((eRect->getPosition().y/32));
        newXEnemy = xPosEnemy+1;
        newYEnemy = yPosEnemy;
        tileEnemy =levelEnemy[newXEnemy + newYEnemy*58];
        if (tileEnemy!=0){ //per il movimento
            eRect->move(movementSpeedEnemy, 0);
            tmpSprite.setTextureRect(sf::IntRect((32 * (counterWalkingEnemy)), 32, 32, 32));
            *enemySprite = tmpSprite;
        } else {
            counterMoveEnemy=movementLengthMax;
        }
    }
    else {
        //non si muove
    }

    // Sprite set at Rect
    enemySprite->setPosition(eRect->getPosition());

    counterWalkingEnemy++;
    if (counterWalkingEnemy == 3)
    {
        counterWalkingEnemy = 0;
    }

    counterMoveEnemy++;
    if (counterMoveEnemy >= movementLengthMax)
    {
        //lancia un dado a 8 facce per la casualita del nemico
        *dirE = Die::generateRandom(8)-1;//(probabilità che si muova 4/8 che NON si muova 4/8
        counterMoveEnemy = 0;
    }
}

void ToHeroMove::updateMoveEnemy(GameCharacter *whoMove, int levelEnemy [], int tileEnemy, sf::Sprite *enemySprite, sf::RectangleShape *eRect, float movementSpeedEnemy, int *dirE) {
    //TODO complete
    std::cout<< "nemico verso l'eroe"<< endl;
}