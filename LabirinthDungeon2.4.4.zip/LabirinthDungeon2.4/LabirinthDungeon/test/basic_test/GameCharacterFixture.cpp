#include "gtest/gtest.h"

#include "../../GameCharacter.h"

/*
class GameCharacterSuite : public ::testing::Test {

protected:
    virtual void SetUp() {
        c.setPosX(10);
        c.setPosY(10);
        c.setFighting(true);
    }

    GameCharacter c;
};


TEST_F(GameCharacterSuite, TestMove) {
    c.move(12, 14);

    ASSERT_EQ(22, c.getPosX());
    ASSERT_EQ(24, c.getPosY());
}
*/
