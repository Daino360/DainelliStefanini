//
// Created by Stefano on 22/11/2017.
//

#include "AttackStrategy.h"

AttackStrategy::AttackStrategy()
{
    rectA.setSize(sf::Vector2f(32, 32));
    rectA.setPosition(0, 0);
    rectA.setFillColor(sf::Color::Green);
    spriteAttack.setTextureRect(sf::IntRect(0, 0, 32, 32));
}
void AttackStrategy::AttackStrategyWizard(){
    rectA.setSize(sf::Vector2f(32, 32));
    rectA.setPosition(0, 0);
    rectA.setFillColor(sf::Color::Green);
    spriteAttack.setTextureRect(sf::IntRect(0, 0, 32, 32));
    //andrebbe messo qui il caricamento della palla di fuoco e non nel tilemap.cpp
    //sprite.setTextureRect(sf::IntRect(0, 0, 32, 32));
    /*sf::Texture textureFireBall;
    if (!textureFireBall.loadFromFile("fireball.jpg")){
        std::cout << "Texture Error" << std::endl;
    }
    sf::Sprite spriteFireBall;
    spriteFireBall.setTexture(textureFireBall);*/
}
void AttackStrategy::updateAttackMove()
{
    if (direction == 0) {// Up
        rectA.move(0, -movementSpeed);
    }
    if (direction == 1) {// Down
        rectA.move(0, movementSpeed);
    }
    if (direction == 3) {// Left
        rectA.move(-movementSpeed, 0);
    }
    if (direction == 2) { // Right
        rectA.move(movementSpeed, 0);
    }
    /*counterLifetime++;
    if (counterLifetime >= lifeTime)
    {
        destroy = true;
    }*/
    // Sprite set at Rect
    spriteAttack.setPosition(rectA.getPosition());
}