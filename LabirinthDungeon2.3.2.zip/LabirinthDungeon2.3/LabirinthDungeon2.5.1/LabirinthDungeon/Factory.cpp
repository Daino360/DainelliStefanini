//
// Created by daino on 30/05/18.
//

#include "Factory.h"
#include "memory" //serve per usare gli smart pointer unique_ptr, shared_ptr, weak_ptr

unique_ptr <Hero> Factory::Create(enumTypeHero type) {
   //GameCharacter *yourHero = NULL;
    switch (type) {
        case archer: {
            unique_ptr <Hero> h(new Hero ("Legolas", archer, 100, 200, 150, 50));
            //Hero *h = new Hero("Legolas", archer, 100, 200, 150, 50);
            h->setUpSprite("Sprites/HeroSprite/archers.png");
            std::cout << "Your Hero is an Archer" << std::endl;
            return h;
            break;
        }
        case warrior: {
            unique_ptr <Hero> h(new Hero ("Aragon", warrior, 150, 50, 100, 200));
            //Hero *h = new Hero("Aragon", warrior, 150, 50, 100, 200);
            h->setUpSprite("Sprites/HeroSprite/warriors.png");
            std::cout << "Your Hero is a Warrior" << std::endl;
            return h;
            break;
        }
        case wizard: {
            unique_ptr <Hero> h(new Hero ("Gandalf", wizard, 90, 150, 200, 50));
            //Hero *h = new Hero("Gandalf", wizard, 90, 150, 200, 50);
            h->setUpSprite("Sprites/HeroSprite/wizards.png");
            std::cout << "Your Hero is a Wizard" << std::endl;
            return h;
            break;
        }
    }
}

unique_ptr <Enemy> Factory::Create(enumTypeEnemy type)
{
    switch (type) {
        case goblin: {
            unique_ptr <Enemy> h(new Enemy (goblin, 10, 80, 30, 5));
            //Enemy *h = new Enemy(goblin, 10, 80, 30, 5);
            h->setUpSpriteEnemy("Sprites/EnemySprite/goblins.png");
            return h;
            break;
        }
        case ghoul: {
            unique_ptr <Enemy> h(new Enemy (ghoul, 10, 80, 30, 5));
            //Enemy *h = new Enemy(ghoul, 10, 80, 30, 5);
            h->setUpSpriteEnemy("Sprites/EnemySprite/ghouls.png");
            return h;
            break;
        }
        case orc: {
            unique_ptr <Enemy> h(new Enemy (orc, 10, 80, 30, 5));
            //Enemy *h = new Enemy(orc, 10, 80, 30, 5);
            h->setUpSpriteEnemy("Sprites/EnemySprite/orcs.png");
            return h;
            break;
        }
        case troll: {
            unique_ptr <Enemy> h(new Enemy (goblin, 10, 80, 30, 5));
            //Enemy *h = new Enemy(troll, 10, 80, 30, 5);
            h->setUpSpriteEnemy("Sprites/EnemySprite/trolls.png");
            return h;
            break;
        }
    }
}
