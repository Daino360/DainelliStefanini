#include <iostream>
#include "Hero.h"
#include "Enemy.h"
#include "Factory.h"
#include "Die.h"
#include "EnumFile.h"
#include <fstream>
#include <list>


int main(int argc, char **argv) {

// print the content of a text file.
    std::ifstream ifs;
    ifs.open("Mappetta.txt", std::ifstream::in); //apre la Mappetta.txt dove c'è il set della Mappa
    char v = ifs.get();

    std::list<int> list = std::list<int>(); //lista in cui verranno inseriti tutti gli 0,1,2 del set mappa

    while (ifs.good()) {
        //std::cout << v;
        v = ifs.get();
        if(v=='0' || v=='1' || v=='2')
        {
            list.push_back((int)v);
        }
    }
    ifs.close();

// 48=0 , 49=1 , 50=2
    int level[list.size()]; //array finale che serve per creare effettivamente la mappa
    int myarray[list.size()]; //array di transizione che prende 48 come 0, 49 come 1, 50 come 2.
// define the level with an array of tile indices
    for(int i=0;i<list.size()*list.size();i++)
    {
            myarray[i] = list.front();
            if (myarray[i] == 48) {
                level[i] = 0;
            } else if (myarray[i] == 49) {
                level[i] = 1;
            } else if (myarray[i] == 50) {
                level[i] = 2;
            } else {
                std::cout << "Texture Error" << std::endl;
            }
        //printf("%d\n", list.front()); //serve per contollare gli elementi dentro la lista che ha letto Mappetta.txt
        //printf("%d\n", level[i]); //serve per contollare gli elementi dentro l'array level
        //printf("%d\n", myarray[i]); //serve per contollare gli elementi dentro l'array myarray
        list.pop_front();
    }

// create the window
    sf::RenderWindow window(sf::VideoMode(1920, 1080), "Labirinth Dungeon");
// create the tilemap from the level definition
    TileMap map;
    if (!map.load("Tile2.jpeg", sf::Vector2u(32, 32), level, 58, 33))
        std::cout << "Texture Error" << std::endl;

// run the main loop
    while (window.isOpen())
    {
// handle events
        sf::Event event;
        while (window.pollEvent(event))
        {
            if(event.type == sf::Event::Closed)
                window.close();
        }

// draw the map
        window.clear();
        window.draw(map);
        window.display();
    }

    Hero *Giovanni = Hero::GetHero();//created by factoryH

    //crere un ciclo che crea nemici fincè non muore l'eroe

    Enemy *Stefano = Enemy::GetEnemy(); //created by factory

    cout << "\n" << "Your Hero fights against Enemy";
    int damoHero = 0;
    int damoEnemy = 0;

    int done = 0;
    int c = 0;


    for (int hit = 0; hit < Stefano->getHp() || hit < Giovanni->getHp(); hit++) {

        do {
            c = getchar();
            putchar(c);
        } while (c != ' ');

        damoHero = Giovanni->fight(*Stefano);
        damoEnemy = Stefano->fightHero(*Giovanni);

        if (damoHero)
            std::cout <<" Enemy hit: " << damoHero << std::endl;
        if (Stefano->getHp() > 0)
            std::cout << "Healty Point of Enemy"<< Stefano->getHp() << std::endl;
        else {
            std::cout << "Healty Point of Enemy"<<": "<< 0 << std::endl;
        }
        if (Stefano->getHp() <= 0) {
            std::cout << "\n"<<"Enemy is dead" << std::endl;
            return 0;
        }

        if (damoEnemy && done == 0)
            std::cout << "Hero hit: " << damoEnemy << std::endl;
        if (Giovanni->getHp() > 0 && done == 0)
            std::cout << "Healty Point of Your Hero " << Giovanni->getHp()<< std::endl;
        else if (done == 0) {
            std::cout << "Healty Point of Your Hero " << 0 << std::endl;
            std::cout << "\nYour Hero is dead" << std::endl;
            return 0;
        }
    }
    return 0;
}
